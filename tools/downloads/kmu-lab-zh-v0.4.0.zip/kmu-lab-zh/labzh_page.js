// 中文檢驗報告：體系病歷「檢驗」頁（/WEB/MRN/InspectionReport）。跑在頁面主環境（world: MAIN），才讀得到院內表格每列的資料（jQuery data）。
// 只讀：只送院內頁面本來就會送的明細查詢（同一個登入），不改任何東西、不連院外、不存檔。
// 病人資料只放在預覽框的記憶體裡，關掉預覽就清掉；身分證字號（院內查詢參數 Patient_ID）只用在查詢，不會出現在報告上。
(function () {
  "use strict";
  if (window.top !== window) return;
  if (!/\/mrn\/inspectionreport\/?$/i.test(location.pathname)) return;
  const Z = window.LABZH;
  if (!Z || window.__labzhLoaded) return;
  window.__labzhLoaded = true;
  const DICT = Z.compileDict(window.LABZH_DICT || []);
  const DETAIL = "/WEB/MRN/InspectionReport/GetInspectionReportDetail";
  const LOGIN = /高醫體系資訊系統入口網|資訊系統入口網|AuthServer|\/Account\/Login/i;
  const $ = (s, r) => (r || document).querySelector(s);
  const el = (tag, attrs, ...kids) => {
    const e = document.createElement(tag);
    for (const [k, v] of Object.entries(attrs || {})) { if (k === "text") e.textContent = v; else if (k === "style") e.style.cssText = v; else if (k.startsWith("on")) e.addEventListener(k.slice(2), v); else e.setAttribute(k, v); }
    for (const k of kids) if (k != null) e.append(k);
    return e;
  };

  // ---------- 小提示 ----------
  let toastEl = null, toastT = 0;
  function toast(msg, ms) {
    if (!toastEl) { toastEl = el("div", { id: "labzh-toast", style: "position:fixed;right:16px;bottom:16px;z-index:2147483600;max-width:440px;padding:10px 14px;border-radius:8px;background:#1d2b3a;color:#fff;font:14px/1.5 'Microsoft JhengHei',sans-serif;box-shadow:0 4px 16px rgba(0,0,0,.3)" }); document.body.append(toastEl); }
    toastEl.textContent = msg; toastEl.style.display = "block";
    clearTimeout(toastT); if (ms) toastT = setTimeout(() => { toastEl.style.display = "none"; }, ms);
  }

  // ---------- 讀頁面 ----------
  const inputByLabel = (re) => {
    const g = [...document.querySelectorAll(".input-group")].find((x) => re.test(((x.querySelector(".input-group-text") || {}).textContent || "").replace(/\s+/g, "")));
    const i = g && g.querySelector("input");
    return i ? String(i.value || i.getAttribute("value") || "").trim() : "";
  };
  // 病歷號、姓名要讀得到才印（讀不到寧可不印）
  function patient() {
    const c = $("#CurrentChartno");
    const chart = c ? String(c.value || c.getAttribute("value") || "").trim() : "";
    const name = inputByLabel(/^姓名$/);
    if (!/^[A-Za-z0-9]{4,12}$/.test(chart) || !name) throw new Error("讀不到這一頁的病歷號或姓名，為避免印錯人，這次不產生報告。");
    const idEl = $("#inPATIENT_ID_NO");
    const pid = idEl ? String(idEl.value || idEl.getAttribute("value") || "").trim().toUpperCase() : "";
    // eGFR 要年齡與性別（老闆 msg900）：生日讀頁面上的病人資料表（病歷號要對得上才用）；性別只在記憶體由身分證第 2 碼判斷，不顯示、不存
    return { chart, name, pid, birth: birthOnPage(chart), sex: Z.sexFromId(pid) };
  }
  function birthOnPage(chart) {
    const key = (v) => String(v || "").replace(/\D/g, "").replace(/^0+/, "");
    for (const th of document.querySelectorAll('th[data-field="BIRTH_DATE"]')) {
      const table = th.closest("table"), ths = table ? [...table.querySelectorAll("thead th")] : [];
      const bi = ths.indexOf(th), ci = ths.findIndex((t) => t.getAttribute("data-field") === "CHART_NO");
      const rows = table ? [...table.querySelectorAll("tbody tr")].filter((tr) => tr.cells.length > Math.max(bi, ci)) : [];
      if (bi < 0 || ci < 0 || rows.length !== 1) continue;   // 剛好一列才用
      if (key(rows[0].cells[ci].textContent) !== key(chart)) continue;
      const b = String(rows[0].cells[bi].textContent || "").trim();
      if (Z.birthKey(b)) return b;
    }
    return "";
  }
  function formDates() {
    try { if (typeof window.GetInspectionReportFormParameter === "function") { const p = window.GetInspectionReportFormParameter(); return { startdate: p.startdate, enddate: p.enddate }; } } catch (e) { /* 退回自己讀 */ }
    const f = $("#inspectionReportForm"), d = {};
    if (f) for (const [k, v] of new FormData(f).entries()) d[k] = String(v);
    if (d.CustromDate && d.CustromDate.includes(",")) { const p = d.CustromDate.split(","); return { startdate: p[0], enddate: p[1] }; }
    return { startdate: d.NQuery_startdate, enddate: d.NQuery_enddate };
  }
  const parse = (v) => { if (v && typeof v === "object") return v; try { return JSON.parse(v || "[]"); } catch (e) { return []; } };
  // 目前這一天報告清單的每一列：優先用院內表格每列的 rowData；沒有 jQuery 時照順序對回左邊選中日期的 data-report（院內 loadRptTable 依序建表）
  function reportRows() {
    const trs = [...document.querySelectorAll("#InspectionReportTable tbody tr")];
    const act = $("#home .date-item.active") || $(".date-item.active");
    const fallback = act ? parse(act.getAttribute("data-report")) : [];
    return trs.map((tr, i) => {
      let row = null;
      try { if (window.jQuery) row = window.jQuery(tr).data("rowData") || null; } catch (e) { row = null; }
      if (!row && Array.isArray(fallback) && fallback.length === trs.length) row = fallback[i];
      const chk = tr.querySelector(".row-check");
      return { row, checked: !!(chk && chk.checked), disabled: !!(chk && chk.disabled) };
    }).filter((x) => x.row && x.row.HOSP_CODE !== "CloudEMR");
  }
  // 每筆報告的 Patient_ID 要和頁面上的身分證一致（兩邊都有時才比；不一致就不查，B 審 s2）
  function samePatient(rows, pt) {
    if (!pt.pid) return;
    for (const r of rows) { const id = String((r && r.Patient_ID) || "").trim().toUpperCase(); if (id && id !== pt.pid) throw new Error("報告清單和這一頁的病人對不上，為避免印錯人，這次不產生報告。請重新整理檢驗頁再試。"); }
  }
  function detailBody(row, fd, mode) {
    let ctl = row.CHARGE_TIME_LIST;
    if (typeof ctl === "string") { try { ctl = JSON.parse(ctl); } catch (e) { ctl = []; } }
    return { in_HospCode: row.HOSP_CODE, in_ChargeDate: row.charge_date, in_ChargeTimeList: ctl || [], in_PatientID: row.Patient_ID, in_CKNO: row.ckno,
      in_RequestCode: row.request_code, in_kind: row["報告類別"] || "", in_BeginDate: fd.startdate, in_EndDate: fd.enddate, in_TableStatus: mode };
  }
  async function post(body) {
    const r = await fetch(DETAIL, { method: "POST", credentials: "include", headers: { "Content-Type": "application/json; charset=utf-8" }, body: JSON.stringify(body),
      signal: AbortSignal.timeout ? AbortSignal.timeout(20000) : undefined });
    if (r.status !== 200) throw new Error("院內回應 " + r.status);
    const t = await r.text();
    if (/<html/i.test(t.slice(0, 500)) && LOGIN.test(t.slice(0, 3000))) throw new Error("院內登入已逾時，請重新登入後再試。");
    try { return JSON.parse(t); } catch (e) { throw new Error("院內回應格式不對"); }
  }
  const nowText = () => { const d = new Date(), p = (n) => String(n).padStart(2, "0"); return `${d.getFullYear()}/${p(d.getMonth() + 1)}/${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}`; };

  // ---------- 預覽框（關掉就整個移除） ----------
  let overlay = null;
  function closeOverlay() { if (overlay) { overlay.remove(); overlay = null; } document.removeEventListener("keydown", onKey, true); }
  function onKey(e) { if (e.key === "Escape" && overlay) { e.stopPropagation(); closeOverlay(); } }
  function shell(title) {
    closeOverlay();
    const body = el("div", { class: "labzh-body", style: "flex:1;min-height:0;display:flex;flex-direction:column" });
    const bar = el("div", { class: "labzh-bar", style: "display:flex;gap:8px;align-items:center;padding:8px 12px;border-bottom:1px solid #ccc;background:#f6f7f9" },
      el("b", { text: title, style: "font-size:16px;margin-right:auto" }));
    const box = el("div", { style: "position:absolute;inset:3vh 4vw;background:#fff;border-radius:8px;display:flex;flex-direction:column;overflow:hidden;box-shadow:0 8px 40px rgba(0,0,0,.4)" }, bar, body);
    overlay = el("div", { id: "labzh-overlay", style: "position:fixed;inset:0;z-index:2147483500;background:rgba(0,0,0,.45);font:14px/1.5 'Microsoft JhengHei',sans-serif;color:#111" }, box);
    document.body.append(overlay);
    document.addEventListener("keydown", onKey, true);
    return { bar, body };
  }
  const btn = (text, onclick, primary) => el("button", { type: "button", text, onclick, style: `padding:5px 14px;font-size:14px;border-radius:5px;cursor:pointer;border:1px solid ${primary ? "#0b6e4f" : "#888"};background:${primary ? "#0b6e4f" : "#fff"};color:${primary ? "#fff" : "#111"}` });
  // 一年 eGFR／UACR 折線圖開關（v0.4.0，老闆 msg1013）：存在這個院內網頁的 localStorage（外掛沒有 storage 權限）
  const RT_KEY = "labzh-renal-trend";
  const renalTrendOn = () => { try { return localStorage.getItem(RT_KEY) === "1"; } catch (e) { return false; } };
  function trendToggle() {
    const cb = el("input", { type: "checkbox", id: "labzh-rt" });
    cb.checked = renalTrendOn();
    cb.addEventListener("change", () => { try { localStorage.setItem(RT_KEY, cb.checked ? "1" : "0"); } catch (e) { /* 存不了就只這次 */ } closeOverlay(); onDay(); });
    return el("label", { style: "display:flex;align-items:center;gap:4px;color:#333;cursor:pointer", title: "勾選後，中文版後面附查詢區間內（建議先把院內查詢區間改成 1 年）的 eGFR、UACR 折線圖；少於 2 次不畫" }, cb, "附一年 eGFR／UACR 折線圖");
  }
  function preview(title, html, extra) {
    const { bar, body } = shell(title);
    const fr = el("iframe", { id: "labzh-frame", title: "預覽", sandbox: "allow-same-origin allow-modals", style: "flex:1;border:0;width:100%;background:#fff" });
    body.append(fr);
    const d = fr.contentDocument; d.open(); d.write(html); d.close();
    bar.append(...(extra ? [extra] : []), el("span", { text: "確認內容後再按列印", style: "color:#555" }), btn("🖨 列印", () => fr.contentWindow.print(), true), btn("關閉", closeOverlay));
  }

  // ---------- ① 某一天的中文版 ----------
  let busy = false;
  async function onDay() {
    if (busy) return; busy = true;
    try {
      const pt = patient();
      const all = reportRows();
      if (!all.length) throw new Error("請先在左邊點一個抽血日期，等報告清單出來再按。");
      // 沒勾就是當天全部，含其他院區（老闆 msg810、msg823；院內勾選框只開放本院區，所以有勾就只印勾的那幾份）
      const picked = all.some((x) => x.checked) ? all.filter((x) => x.checked) : all;
      samePatient(picked.map((x) => x.row), pt);
      toast(`正在讀取 ${picked.length} 份報告…`);
      const fd = formDates(), reports = [];
      for (const x of picked) {
        const kind = String(x.row["報告類別"] || "");
        const res = await post(detailBody(x.row, fd, "Single"));
        reports.push({ kind, hosp: String(x.row["院區"] || ""), rows: Z.parseDetail(res, kind) });
      }
      const m = Z.buildReport({ dict: DICT, patient: pt, reports, now: nowText(), renal: { birth: pt.birth, sex: pt.sex } });
      if (!m.count) throw new Error("這幾份報告沒有讀到檢驗項目。");
      // v0.4.0（老闆 msg1013）：可選附一年 eGFR、UACR 折線圖（預設關；設定記在這台電腦的瀏覽器）
      if (renalTrendOn()) {
        try {
          const sp = span(fd), items = await loadMix(pt, fd);
          const lines = Z.renalTrend({ dict: DICT, items, birth: pt.birth, sex: pt.sex })
            .filter((L) => (L.zh === Z.RENAL_EPI || L.zh === Z.RENAL_UACR) && L.points.length >= 2);
          if (lines.length) {
            m.trend = Z.buildTrend({ dict: DICT, patient: pt, items: lines, from: sp.a, to: sp.b, now: nowText() });
            m.trend.short = !!(sp.days && sp.days < 360);
          }
        } catch (e) { /* 讀不到一年資料就只印當天報告 */ }
      }
      toast(`共 ${m.count} 項` + (m.multi ? `（${m.hosp}）` : "") + (m.unknown ? `，其中 ${m.unknown} 項沒有中文對照（保留英文）` : ""), 7000);
      preview("檢驗報告（中文說明版）・預覽", Z.renderHTML(m), trendToggle());
    } catch (e) { toast(String((e && e.message) || e), 9000); }
    finally { busy = false; }
  }

  // ---------- ② 多項目一年變化 ----------
  const span = (fd) => {
    const a = Z.dayKey(fd.startdate), b = Z.dayKey(fd.enddate);
    if (!a || !b) return { a, b, days: 0 };
    const t = (k) => Date.UTC(+k.slice(0, 4), +k.slice(4, 6) - 1, +k.slice(6, 8));
    return { a, b, days: Math.round((t(b) - t(a)) / 86400000) };
  };
  // 查詢區間內的「整合」資料（多院區），補上單位、參考範圍（v0.4.0 從 onTrend 抽出來，中文版附折線圖也用）
  async function loadMix(pt, fd) {
    // 每個院區的每種報告類別，各取查詢區間內最新那筆，用院內「整合」模式查一次就是跨日期的表（多院區一起查，老闆 msg823）
    const byKind = new Map(), older = new Map();
    const dates = [...document.querySelectorAll(".date-item[data-datekey]")].map((e) => ({ key: String(e.getAttribute("data-datekey") || ""), reports: parse(e.getAttribute("data-report")) }))
      .filter((d) => /^\d{8}$/.test(d.key) && Array.isArray(d.reports)).sort((a, b) => (a.key < b.key ? 1 : -1));
    for (const d of dates) for (const r of d.reports) {
      const k = String((r && r["報告類別"]) || "");
      if (!k || r.HOSP_CODE === "CloudEMR" || Z.NO_TREND.test(k)) continue;
      const kk = String(r.HOSP_CODE || "") + "|" + k;
      if (!byKind.has(kk)) byKind.set(kk, r); else { if (!older.has(kk)) older.set(kk, []); older.get(kk).push(r); }
    }
    if (!byKind.size) throw new Error("查詢區間內沒有可以畫變化的檢驗。");
    samePatient([...byKind.values()], pt);
    toast("正在讀取查詢區間內的檢驗…");
    const results = [], latest = new Map();
    const hName = (r) => String(r["院區"] || r.HOSP_CODE || "").trim();
    // 單位、參考範圍：各院區分開記（同一項目各院區可能不同，B 審 msg823 第 2 點）
    const keyOf = (hosp, x) => hosp + "|" + x.name + "@" + (Z.isUrine(x) ? "U" : "B");
    const learn = (hosp, res, kind) => { for (const x of Z.parseDetail(res, kind)) { const k = keyOf(hosp, x); if (!latest.has(k)) latest.set(k, x); } };
    for (const [kk, r] of byKind) {
      const kind = kk.slice(kk.indexOf("|") + 1), hosp = hName(r);
      results.push({ kind, hosp, res: await post(detailBody(r, fd, "Mix")) });
      learn(hosp, await post(detailBody(r, fd, "Single")), kind);
    }
    const items = Z.mixMerge(results);
    if (!items.length) throw new Error("院內沒有回傳可以畫變化的資料。");
    // 最新一份沒有這項時，往前同院區同類別再找最多 3 份補單位和參考範圍（B 審 m3）
    for (const [kk, list] of older) {
      const kind = kk.slice(kk.indexOf("|") + 1), hosp = hName(list[0]);
      for (const r of list.slice(0, 3)) {
        if (!items.some((it) => it.hosp === hosp && it.kind === kind && !latest.has(keyOf(hosp, it)))) break;
        learn(hosp, await post(detailBody(r, fd, "Single")), kind);
      }
    }
    for (const it of items) { const s = latest.get(keyOf(it.hosp, it)); it.unit = s ? s.unit : ""; it.ref = s ? s.ref : ""; it.code = s ? s.code : ""; }
    return items;
  }
  async function onTrend() {
    if (busy) return; busy = true;
    try {
      const pt = patient(), fd = formDates(), sp = span(fd);
      const items = await loadMix(pt, fd);
      toast("", 1);
      picker(pt, Z.combineHosp(items).concat(Z.renalTrend({ dict: DICT, items, birth: pt.birth, sex: pt.sex }), Z.metabTrend({ dict: DICT, items, birth: pt.birth })), sp);
    } catch (e) { toast(String((e && e.message) || e), 9000); }
    finally { busy = false; }
  }
  function picker(pt, items, sp) {
    const { bar, body } = shell("檢驗數值變化・選項目");
    const groups = new Map();
    for (const it of items) {
      const e = it.calc ? { zh: it.zh, cat: it.cat } : Z.lookup(DICT, it), cat = e ? e.cat : Z.UNKNOWN_CAT;
      it.label = (e ? e.zh + (!it.calc && Z.isUrine(it) && e.cat !== "尿液" ? "（尿）" : "") + "　" : "") + it.name;
      it.n = it.points.length;
      if (!groups.has(cat)) groups.set(cat, []);
      groups.get(cat).push(it);
    }
    const short = sp.days && sp.days < 360;
    const multi = new Set(items.flatMap((it) => it.hosps)).size > 1;
    const head = el("div", { style: "padding:8px 14px;border-bottom:1px solid #eee" },
      el("div", { text: `查詢區間：${Z.fmtDay(sp.a)}～${Z.fmtDay(sp.b)}　勾選要印的項目（可多選），每項會有一張折線圖和數值表。` }),
      short ? el("div", { style: "color:#b00020;font-weight:700", text: "目前查詢區間不到一年。要看一年內的變化，請先關掉這個視窗，把院內「查詢區間」改成 1 年，再按一次「📈 多項變化」。" }) : null);
    const list = el("div", { style: "flex:1;overflow:auto;padding:6px 14px;columns:2 320px;column-gap:24px" });
    for (const cat of [...Z.CAT_ORDER, Z.UNKNOWN_CAT].filter((c) => groups.has(c))) {
      list.append(el("div", { style: "break-inside:avoid;margin:8px 0 2px;font-weight:700;border-bottom:1px solid #ddd", text: cat }));
      for (const it of groups.get(cat)) {
        const cb = el("input", { type: "checkbox", "data-id": it.id });
        list.append(el("label", { style: "display:block;break-inside:avoid;padding:2px 0;cursor:pointer" }, cb, " " + it.label, el("span", { style: "color:#777", text: `（${it.n} 次` + (multi ? "・" + it.hosps.join("、") : "") + (multi && it.unit ? "・" + it.unit : "") + "）" })));
      }
    }
    body.append(head, list);
    const go = () => {
      const ids = new Set([...list.querySelectorAll("input:checked")].map((c) => c.getAttribute("data-id")));
      const chosen = items.filter((it) => ids.has(it.id));
      if (!chosen.length) return toast("請至少勾一個項目。", 4000);
      const m = Z.buildTrend({ dict: DICT, patient: pt, items: chosen, from: sp.a, to: sp.b, now: nowText() });
      preview("檢驗數值變化（中文說明版）・預覽", Z.renderTrendHTML(m));
    };
    bar.append(btn("產生報告", go, true), btn("關閉", closeOverlay));
  }

  // ---------- 按鈕：放在院內「列印」鈕旁邊 ----------
  function addButtons() {
    if ($("#labzh-day")) return true;
    const anchor = $("#printReport");
    if (!anchor) return false;
    const mk = (id, text, title, fn) => el("button", { type: "button", id, class: "btn btn-sm", title, text, onclick: (e) => { e.preventDefault(); fn(); },
      style: "margin-left:6px;padding:2px 10px;border:1px solid #0b6e4f;border-radius:4px;background:#e9f6f0;color:#0b4f3a;cursor:pointer;white-space:nowrap" });
    const b2 = mk("labzh-trend", "📈 多項變化", "勾選多個項目，印出查詢區間內每次的數值與折線圖（中文說明版）", onTrend);
    const b1 = mk("labzh-day", "🖨 中文版", "把這一天的檢驗報告整理成中文說明版（沒勾就是當天全部）", onDay);
    anchor.insertAdjacentElement("afterend", b2);
    anchor.insertAdjacentElement("afterend", b1);
    return true;
  }
  if (!addButtons()) {
    const mo = new MutationObserver(() => { if (addButtons()) mo.disconnect(); });
    mo.observe(document.documentElement, { childList: true, subtree: true });
    setTimeout(() => mo.disconnect(), 30000);
  }
})();
