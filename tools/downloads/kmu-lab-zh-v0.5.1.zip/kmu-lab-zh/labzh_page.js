// 中文檢驗報告：體系病歷「檢驗」頁（/WEB/MRN/InspectionReport）。跑在頁面主環境（world: MAIN），才讀得到院內表格每列的資料（jQuery data）。
// 只讀：只送院內頁面本來就會送的明細查詢（同一個登入），不改任何東西、不連院外、不存檔。
// 病人資料只放在預覽框的記憶體裡，關掉預覽就清掉；身分證字號（院內查詢參數 Patient_ID）只用在查詢，不會出現在報告上。
(function () {
  "use strict";
  if (window.top !== window) return;
  if (!/\/mrn\/inspectionreport\/?$/i.test(location.pathname)) return;
  const Z = window.LABZH;
  if (!Z || window.__labzhLoaded) return;
  window.__labzhLoaded = true;
  const DICT = Z.compileDict(window.LABZH_DICT || []);
  const DETAIL = "/WEB/MRN/InspectionReport/GetInspectionReportDetail";
  const LOGIN = /高醫體系資訊系統入口網|資訊系統入口網|AuthServer|\/Account\/Login/i;
  const $ = (s, r) => (r || document).querySelector(s);
  const el = (tag, attrs, ...kids) => {
    const e = document.createElement(tag);
    for (const [k, v] of Object.entries(attrs || {})) { if (k === "text") e.textContent = v; else if (k === "style") e.style.cssText = v; else if (k.startsWith("on")) e.addEventListener(k.slice(2), v); else e.setAttribute(k, v); }
    for (const k of kids) if (k != null) e.append(k);
    return e;
  };

  // ---------- 小提示 ----------
  let toastEl = null, toastT = 0;
  function toast(msg, ms) {
    if (!toastEl) { toastEl = el("div", { id: "labzh-toast", style: "position:fixed;right:16px;bottom:16px;z-index:2147483600;max-width:440px;padding:10px 14px;border-radius:8px;background:#1d2b3a;color:#fff;font:14px/1.5 'Microsoft JhengHei',sans-serif;box-shadow:0 4px 16px rgba(0,0,0,.3)" }); document.body.append(toastEl); }
    toastEl.textContent = msg; toastEl.style.display = "block";
    clearTimeout(toastT); if (ms) toastT = setTimeout(() => { toastEl.style.display = "none"; }, ms);
  }

  // ---------- 讀頁面 ----------
  const inputByLabel = (re) => {
    const g = [...document.querySelectorAll(".input-group")].find((x) => re.test(((x.querySelector(".input-group-text") || {}).textContent || "").replace(/\s+/g, "")));
    const i = g && g.querySelector("input");
    return i ? String(i.value || i.getAttribute("value") || "").trim() : "";
  };
  // 病歷號、姓名要讀得到才印（讀不到寧可不印）
  function patient() {
    const c = $("#CurrentChartno");
    const chart = c ? String(c.value || c.getAttribute("value") || "").trim() : "";
    const name = inputByLabel(/^姓名$/);
    if (!/^[A-Za-z0-9]{4,12}$/.test(chart) || !name) throw new Error("讀不到這一頁的病歷號或姓名，為避免印錯人，這次不產生報告。");
    const idEl = $("#inPATIENT_ID_NO");
    const pid = idEl ? String(idEl.value || idEl.getAttribute("value") || "").trim().toUpperCase() : "";
    // eGFR 要年齡與性別（老闆 msg900）：生日讀頁面上的病人資料表（病歷號要對得上才用）；性別只在記憶體由身分證第 2 碼判斷，不顯示、不存
    return { chart, name, pid, birth: birthOnPage(chart), sex: Z.sexFromId(pid) };
  }
  function birthOnPage(chart) {
    const key = (v) => String(v || "").replace(/\D/g, "").replace(/^0+/, "");
    for (const th of document.querySelectorAll('th[data-field="BIRTH_DATE"]')) {
      const table = th.closest("table"), ths = table ? [...table.querySelectorAll("thead th")] : [];
      const bi = ths.indexOf(th), ci = ths.findIndex((t) => t.getAttribute("data-field") === "CHART_NO");
      const rows = table ? [...table.querySelectorAll("tbody tr")].filter((tr) => tr.cells.length > Math.max(bi, ci)) : [];
      if (bi < 0 || ci < 0 || rows.length !== 1) continue;   // 剛好一列才用
      if (key(rows[0].cells[ci].textContent) !== key(chart)) continue;
      const b = String(rows[0].cells[bi].textContent || "").trim();
      if (Z.birthKey(b)) return b;
    }
    return "";
  }
  function formDates() {
    try { if (typeof window.GetInspectionReportFormParameter === "function") { const p = window.GetInspectionReportFormParameter(); return { startdate: p.startdate, enddate: p.enddate }; } } catch (e) { /* 退回自己讀 */ }
    const f = $("#inspectionReportForm"), d = {};
    if (f) for (const [k, v] of new FormData(f).entries()) d[k] = String(v);
    if (d.CustromDate && d.CustromDate.includes(",")) { const p = d.CustromDate.split(","); return { startdate: p[0], enddate: p[1] }; }
    return { startdate: d.NQuery_startdate, enddate: d.NQuery_enddate };
  }
  const parse = (v) => { if (v && typeof v === "object") return v; try { return JSON.parse(v || "[]"); } catch (e) { return []; } };
  // 目前這一天報告清單的每一列：優先用院內表格每列的 rowData；沒有 jQuery 時照順序對回左邊選中日期的 data-report（院內 loadRptTable 依序建表）
  function reportRows() {
    const trs = [...document.querySelectorAll("#InspectionReportTable tbody tr")];
    const act = $("#home .date-item.active") || $(".date-item.active");
    const fallback = act ? parse(act.getAttribute("data-report")) : [];
    return trs.map((tr, i) => {
      let row = null;
      try { if (window.jQuery) row = window.jQuery(tr).data("rowData") || null; } catch (e) { row = null; }
      if (!row && Array.isArray(fallback) && fallback.length === trs.length) row = fallback[i];
      const chk = tr.querySelector(".row-check");
      return { row, checked: !!(chk && chk.checked), disabled: !!(chk && chk.disabled) };
    }).filter((x) => x.row && x.row.HOSP_CODE !== "CloudEMR");
  }
  // 每筆報告的 Patient_ID 要和頁面上的身分證一致（兩邊都有時才比；不一致就不查，B 審 s2）
  function samePatient(rows, pt) {
    if (!pt.pid) return;
    for (const r of rows) { const id = String((r && r.Patient_ID) || "").trim().toUpperCase(); if (id && id !== pt.pid) throw new Error("報告清單和這一頁的病人對不上，為避免印錯人，這次不產生報告。請重新整理檢驗頁再試。"); }
  }
  function detailBody(row, fd, mode) {
    let ctl = row.CHARGE_TIME_LIST;
    if (typeof ctl === "string") { try { ctl = JSON.parse(ctl); } catch (e) { ctl = []; } }
    return { in_HospCode: row.HOSP_CODE, in_ChargeDate: row.charge_date, in_ChargeTimeList: ctl || [], in_PatientID: row.Patient_ID, in_CKNO: row.ckno,
      in_RequestCode: row.request_code, in_kind: row["報告類別"] || "", in_BeginDate: fd.startdate, in_EndDate: fd.enddate, in_TableStatus: mode };
  }
  async function post(body) {
    const r = await fetch(DETAIL, { method: "POST", credentials: "include", headers: { "Content-Type": "application/json; charset=utf-8" }, body: JSON.stringify(body),
      signal: AbortSignal.timeout ? AbortSignal.timeout(20000) : undefined });
    if (r.status !== 200) throw new Error("院內回應 " + r.status);
    const t = await r.text();
    if (/<html/i.test(t.slice(0, 500)) && LOGIN.test(t.slice(0, 3000))) throw new Error("院內登入已逾時，請重新登入後再試。");
    try { return JSON.parse(t); } catch (e) { throw new Error("院內回應格式不對"); }
  }
  const nowText = () => { const d = new Date(), p = (n) => String(n).padStart(2, "0"); return `${d.getFullYear()}/${p(d.getMonth() + 1)}/${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}`; };

  // ---------- 預覽框（關掉就整個移除） ----------
  // v0.5.1（老闆 msg1095）：不再蓋全頁黑底；改成可拖曳（拖標題列）、可縮放（右下角）、可縮小的浮動視窗，後面的院內網頁照樣能點、能捲。
  // 位置與大小記在這個院內網頁的 localStorage（只記座標，不記任何資料；外掛沒有 storage 權限）。
  let overlay = null, onResize = null;
  function closeOverlay() {
    if (overlay) { overlay.remove(); overlay = null; }
    document.removeEventListener("keydown", onKey, true);
    if (onResize) { window.removeEventListener("resize", onResize); onResize = null; }
  }
  function onKey(e) { if (e.key === "Escape" && overlay) { e.stopPropagation(); closeOverlay(); } }
  const POS_KEY = "labzh-pos-";
  const clampBox = (b) => {
    const W = window.innerWidth, H = window.innerHeight;
    const w = Math.max(320, Math.min(b.w, W)), h = Math.max(160, Math.min(b.h, H));
    return { x: Math.max(0, Math.min(b.x, W - w)), y: Math.max(0, Math.min(b.y, H - h)), w, h };
  };
  function shell(title, opts) {
    closeOverlay();
    opts = opts || {};
    const W = window.innerWidth, H = window.innerHeight;
    // 預設：計算機靠右、寬 560；預覽（要看整頁報告）維持大視窗
    const def = opts.narrow ? { w: Math.min(560, W - 24), h: Math.round(H * 0.9), x: W - Math.min(560, W - 24) - 12, y: Math.round(H * 0.05) }
      : { w: Math.round(W * 0.92), h: Math.round(H * 0.94), x: Math.round(W * 0.04), y: Math.round(H * 0.03) };
    let saved = null;
    try { const v = JSON.parse(localStorage.getItem(POS_KEY + (opts.key || "main")) || "null"); if (v && [v.x, v.y, v.w, v.h].every(Number.isFinite)) saved = v; } catch (e) { /* 讀不到就用預設 */ }
    let box = clampBox(saved || def);
    const body = el("div", { class: "labzh-body", style: "flex:1;min-height:0;display:flex;flex-direction:column" });
    const mini = el("button", { type: "button", id: "labzh-min", title: "縮小／展開", text: "－", style: "padding:2px 10px;font-size:14px;border-radius:5px;cursor:pointer;border:1px solid #888;background:#fff;color:#111" });
    const bar = el("div", { class: "labzh-bar", style: "display:flex;flex-wrap:wrap;gap:8px;align-items:center;padding:8px 12px;border-bottom:1px solid #ccc;background:#f6f7f9;cursor:move;user-select:none;touch-action:none" },
      el("b", { text: title, title: "按住這一列可以拖曳視窗", style: "font-size:16px;margin-right:auto" }), mini);
    overlay = el("div", { id: "labzh-overlay", role: "dialog", "aria-label": title,
      style: "position:fixed;z-index:2147483500;background:#fff;border-radius:8px;display:flex;flex-direction:column;overflow:hidden;resize:both;" +
        "min-width:320px;min-height:160px;box-shadow:0 8px 40px rgba(0,0,0,.4);font:14px/1.5 'Microsoft JhengHei',sans-serif;color:#111" }, bar, body);
    const place = () => { Object.assign(overlay.style, { left: box.x + "px", top: box.y + "px", width: box.w + "px", height: box.h + "px" }); };
    const save = () => { try { localStorage.setItem(POS_KEY + (opts.key || "main"), JSON.stringify({ x: box.x, y: box.y, w: box.w, h: box.h })); } catch (e) { /* 存不了就只這次 */ } };
    place();
    let small = false, fullH = box.h;
    mini.addEventListener("click", () => {
      small = !small;
      body.style.display = small ? "none" : "flex";
      overlay.style.resize = small ? "none" : "both"; overlay.style.minHeight = small ? "0" : "160px";
      if (small) { fullH = box.h; overlay.style.height = "auto"; } else { box = clampBox(Object.assign(box, { h: fullH })); place(); }
      mini.textContent = small ? "＋" : "－";
    });
    // 拖曳：按住標題列（按鈕、勾選框除外）。拖曳時 iframe 不收滑鼠事件，不然游標移進 iframe 就斷掉（B 審）
    let drag = null;
    const frames = (on) => overlay.querySelectorAll("iframe").forEach((f) => { f.style.pointerEvents = on ? "" : "none"; });
    bar.addEventListener("pointerdown", (e) => {
      if (e.button !== 0 || e.target.closest("button,input,label,select,a,textarea")) return;
      const r = overlay.getBoundingClientRect();
      drag = { id: e.pointerId, dx: e.clientX - r.left, dy: e.clientY - r.top };
      bar.setPointerCapture(e.pointerId); frames(false); e.preventDefault();
    });
    bar.addEventListener("pointermove", (e) => {
      if (!drag || e.pointerId !== drag.id) return;
      const r = overlay.getBoundingClientRect();
      box = clampBox({ x: e.clientX - drag.dx, y: e.clientY - drag.dy, w: r.width, h: small ? fullH : r.height });
      overlay.style.left = box.x + "px"; overlay.style.top = box.y + "px";
    });
    const end = (e) => { if (!drag || e.pointerId !== drag.id) return; drag = null; frames(true); save(); };
    bar.addEventListener("pointerup", end); bar.addEventListener("pointercancel", end);
    // 右下角拉大小：放開後記下來（ResizeObserver 只在使用者改了大小時存）
    if (window.ResizeObserver) {
      const ro = new ResizeObserver(() => { if (!overlay || small || drag) return; const r = overlay.getBoundingClientRect(); if (Math.abs(r.width - box.w) > 1 || Math.abs(r.height - box.h) > 1) { box = Object.assign(box, { w: r.width, h: r.height }); save(); } });
      ro.observe(overlay);
    }
    onResize = () => { if (!overlay) return; box = clampBox(box); if (!small) place(); else { overlay.style.left = box.x + "px"; overlay.style.top = box.y + "px"; } };
    window.addEventListener("resize", onResize);
    document.body.append(overlay);
    document.addEventListener("keydown", onKey, true);
    return { bar, body };
  }
  const btn = (text, onclick, primary) => el("button", { type: "button", text, onclick, style: `padding:5px 14px;font-size:14px;border-radius:5px;cursor:pointer;border:1px solid ${primary ? "#0b6e4f" : "#888"};background:${primary ? "#0b6e4f" : "#fff"};color:${primary ? "#fff" : "#111"}` });
  // 一年折線圖開關（v0.4.1，老闆 msg1022：五項各自開關）：存在這個院內網頁的 localStorage（外掛沒有 storage 權限）
  const TS_KEY = "labzh-trend-sel", OLD_KEY = "labzh-renal-trend";
  function trendSel() {
    try {
      const v = JSON.parse(localStorage.getItem(TS_KEY) || "null");
      if (v && typeof v === "object") return v;
      if (localStorage.getItem(OLD_KEY) === "1") return { egfr: true, uacr: true };   // v0.4.0 勾過的照舊
    } catch (e) { /* 讀不到就全關 */ }
    return {};
  }
  function trendToggle() {
    const cur = trendSel(), boxes = [];
    const wrap = el("span", { style: "display:flex;flex-wrap:wrap;align-items:center;gap:6px;color:#333", title: "勾選的項目會附在中文版後面：查詢區間內的折線圖（建議先把院內查詢區間改成 1 年）；少於 2 次不畫" },
      el("span", { text: "附一年折線圖：" }));
    for (const [k, label] of Z.TREND_KEYS) {
      const cb = el("input", { type: "checkbox", id: "labzh-ts-" + k });
      cb.checked = !!cur[k];
      cb.addEventListener("change", () => {
        const v = {}; for (const [kk] of Z.TREND_KEYS) v[kk] = !!document.getElementById("labzh-ts-" + kk).checked;
        try { localStorage.setItem(TS_KEY, JSON.stringify(v)); localStorage.removeItem(OLD_KEY); } catch (e) { /* 存不了就只這次 */ }
        closeOverlay(); onDay();
      });
      boxes.push(cb);
      wrap.append(el("label", { style: "display:flex;align-items:center;gap:2px;cursor:pointer" }, cb, label));
    }
    return wrap;
  }
  function preview(title, html, extra) {
    const { bar, body } = shell(title);
    const fr = el("iframe", { id: "labzh-frame", title: "預覽", sandbox: "allow-same-origin allow-modals", style: "flex:1;border:0;width:100%;background:#fff" });
    body.append(fr);
    const d = fr.contentDocument; d.open(); d.write(html); d.close();
    bar.append(...(extra ? [extra] : []), el("span", { text: "確認內容後再按列印", style: "color:#555" }), btn("🖨 列印", () => fr.contentWindow.print(), true), btn("關閉", closeOverlay));
  }

  // ---------- ① 某一天的中文版 ----------
  let busy = false;
  async function onDay() {
    if (busy) return; busy = true;
    try {
      const pt = patient();
      const all = reportRows();
      if (!all.length) throw new Error("請先在左邊點一個抽血日期，等報告清單出來再按。");
      // 沒勾就是當天全部，含其他院區（老闆 msg810、msg823；院內勾選框只開放本院區，所以有勾就只印勾的那幾份）
      const picked = all.some((x) => x.checked) ? all.filter((x) => x.checked) : all;
      samePatient(picked.map((x) => x.row), pt);
      toast(`正在讀取 ${picked.length} 份報告…`);
      const fd = formDates(), reports = [];
      for (const x of picked) {
        const kind = String(x.row["報告類別"] || "");
        const res = await post(detailBody(x.row, fd, "Single"));
        reports.push({ kind, hosp: String(x.row["院區"] || ""), rows: Z.parseDetail(res, kind) });
      }
      const m = Z.buildReport({ dict: DICT, patient: pt, reports, now: nowText(), renal: { birth: pt.birth, sex: pt.sex } });
      if (!m.count) throw new Error("這幾份報告沒有讀到檢驗項目。");
      // v0.4.1（老闆 msg1013／1022）：可選附一年折線圖，eGFR、UACR、UPCR、HbA1c、空腹血糖各自開關（預設都關；記在這台電腦的瀏覽器）
      const on = trendSel();
      if (Object.values(on).some(Boolean)) {
        try {
          const sp = span(fd), items = await loadMix(pt, fd);
          const lines = Z.trendPick({ dict: DICT, items, birth: pt.birth, sex: pt.sex, on });
          if (lines.length) {
            m.trend = Z.buildTrend({ dict: DICT, patient: pt, items: lines, from: sp.a, to: sp.b, now: nowText() });
            m.trend.short = !!(sp.days && sp.days < 360);
          }
        } catch (e) { /* 讀不到一年資料就只印當天報告 */ }
      }
      toast(`共 ${m.count} 項` + (m.multi ? `（${m.hosp}）` : "") + (m.unknown ? `，其中 ${m.unknown} 項沒有中文對照（保留英文）` : ""), 7000);
      preview("檢驗報告（中文說明版）・預覽", Z.renderHTML(m), trendToggle());
    } catch (e) { toast(String((e && e.message) || e), 9000); }
    finally { busy = false; }
  }

  // ---------- ② 多項目一年變化 ----------
  const span = (fd) => {
    const a = Z.dayKey(fd.startdate), b = Z.dayKey(fd.enddate);
    if (!a || !b) return { a, b, days: 0 };
    const t = (k) => Date.UTC(+k.slice(0, 4), +k.slice(4, 6) - 1, +k.slice(6, 8));
    return { a, b, days: Math.round((t(b) - t(a)) / 86400000) };
  };
  // 查詢區間內的「整合」資料（多院區），補上單位、參考範圍（v0.4.0 從 onTrend 抽出來，中文版附折線圖也用）
  async function loadMix(pt, fd) {
    // 每個院區的每種報告類別，各取查詢區間內最新那筆，用院內「整合」模式查一次就是跨日期的表（多院區一起查，老闆 msg823）
    const byKind = new Map(), older = new Map();
    const dates = [...document.querySelectorAll(".date-item[data-datekey]")].map((e) => ({ key: String(e.getAttribute("data-datekey") || ""), reports: parse(e.getAttribute("data-report")) }))
      .filter((d) => /^\d{8}$/.test(d.key) && Array.isArray(d.reports)).sort((a, b) => (a.key < b.key ? 1 : -1));
    for (const d of dates) for (const r of d.reports) {
      const k = String((r && r["報告類別"]) || "");
      if (!k || r.HOSP_CODE === "CloudEMR" || Z.NO_TREND.test(k)) continue;
      const kk = String(r.HOSP_CODE || "") + "|" + k;
      if (!byKind.has(kk)) byKind.set(kk, r); else { if (!older.has(kk)) older.set(kk, []); older.get(kk).push(r); }
    }
    if (!byKind.size) throw new Error("查詢區間內沒有可以畫變化的檢驗。");
    samePatient([...byKind.values()], pt);
    toast("正在讀取查詢區間內的檢驗…");
    const results = [], latest = new Map();
    const hName = (r) => String(r["院區"] || r.HOSP_CODE || "").trim();
    // 單位、參考範圍：各院區分開記（同一項目各院區可能不同，B 審 msg823 第 2 點）
    const keyOf = (hosp, x) => hosp + "|" + x.name + "@" + (Z.isUrine(x) ? "U" : "B");
    const learn = (hosp, res, kind) => { for (const x of Z.parseDetail(res, kind)) { const k = keyOf(hosp, x); if (!latest.has(k)) latest.set(k, x); } };
    for (const [kk, r] of byKind) {
      const kind = kk.slice(kk.indexOf("|") + 1), hosp = hName(r);
      results.push({ kind, hosp, res: await post(detailBody(r, fd, "Mix")) });
      learn(hosp, await post(detailBody(r, fd, "Single")), kind);
    }
    const items = Z.mixMerge(results);
    if (!items.length) throw new Error("院內沒有回傳可以畫變化的資料。");
    // 最新一份沒有這項時，往前同院區同類別再找最多 3 份補單位和參考範圍（B 審 m3）
    for (const [kk, list] of older) {
      const kind = kk.slice(kk.indexOf("|") + 1), hosp = hName(list[0]);
      for (const r of list.slice(0, 3)) {
        if (!items.some((it) => it.hosp === hosp && it.kind === kind && !latest.has(keyOf(hosp, it)))) break;
        learn(hosp, await post(detailBody(r, fd, "Single")), kind);
      }
    }
    for (const it of items) { const s = latest.get(keyOf(it.hosp, it)); it.unit = s ? s.unit : ""; it.ref = s ? s.ref : ""; it.code = s ? s.code : ""; }
    return items;
  }
  async function onTrend() {
    if (busy) return; busy = true;
    try {
      const pt = patient(), fd = formDates(), sp = span(fd);
      const items = await loadMix(pt, fd);
      toast("", 1);
      picker(pt, Z.combineHosp(items).concat(Z.renalTrend({ dict: DICT, items, birth: pt.birth, sex: pt.sex }), Z.metabTrend({ dict: DICT, items, birth: pt.birth })), sp);
    } catch (e) { toast(String((e && e.message) || e), 9000); }
    finally { busy = false; }
  }
  function picker(pt, items, sp) {
    const { bar, body } = shell("檢驗數值變化・選項目");
    const groups = new Map();
    for (const it of items) {
      const e = it.calc ? { zh: it.zh, cat: it.cat } : Z.lookup(DICT, it), cat = e ? e.cat : Z.UNKNOWN_CAT;
      it.label = (e ? e.zh + (!it.calc && Z.isUrine(it) && e.cat !== "尿液" ? "（尿）" : "") + "　" : "") + it.name;
      it.n = it.points.length;
      if (!groups.has(cat)) groups.set(cat, []);
      groups.get(cat).push(it);
    }
    const short = sp.days && sp.days < 360;
    const multi = new Set(items.flatMap((it) => it.hosps)).size > 1;
    const head = el("div", { style: "padding:8px 14px;border-bottom:1px solid #eee" },
      el("div", { text: `查詢區間：${Z.fmtDay(sp.a)}～${Z.fmtDay(sp.b)}　勾選要印的項目（可多選），每項會有一張折線圖和數值表。` }),
      short ? el("div", { style: "color:#b00020;font-weight:700", text: "目前查詢區間不到一年。要看一年內的變化，請先關掉這個視窗，把院內「查詢區間」改成 1 年，再按一次「📈 多項變化」。" }) : null);
    const list = el("div", { style: "flex:1;overflow:auto;padding:6px 14px;columns:2 320px;column-gap:24px" });
    for (const cat of [...Z.CAT_ORDER, Z.UNKNOWN_CAT].filter((c) => groups.has(c))) {
      list.append(el("div", { style: "break-inside:avoid;margin:8px 0 2px;font-weight:700;border-bottom:1px solid #ddd", text: cat }));
      for (const it of groups.get(cat)) {
        const cb = el("input", { type: "checkbox", "data-id": it.id });
        list.append(el("label", { style: "display:block;break-inside:avoid;padding:2px 0;cursor:pointer" }, cb, " " + it.label, el("span", { style: "color:#777", text: `（${it.n} 次` + (multi ? "・" + it.hosps.join("、") : "") + (multi && it.unit ? "・" + it.unit : "") + "）" })));
      }
    }
    body.append(head, list);
    const go = () => {
      const ids = new Set([...list.querySelectorAll("input:checked")].map((c) => c.getAttribute("data-id")));
      const chosen = items.filter((it) => ids.has(it.id));
      if (!chosen.length) return toast("請至少勾一個項目。", 4000);
      const m = Z.buildTrend({ dict: DICT, patient: pt, items: chosen, from: sp.a, to: sp.b, now: nowText() });
      preview("檢驗數值變化（中文說明版）・預覽", Z.renderTrendHTML(m));
    };
    bar.append(btn("產生報告", go, true), btn("關閉", closeOverlay));
  }

  // ---------- 身高、體重（v0.5.1，老闆 msg1095）：同一個登入，背景讀 TPR 頁的「Body Size」表 ----------
  // TPR 頁網址不帶病人，院內是用登入狀態裡「目前的病人」：另一個分頁換了病人，這裡讀到的就是別人。
  // 所以讀回來的頁面病歷號一定要和這一頁一樣才用；對不上、讀不到就留空讓人手填（不猜）。只讀，不改院內任何東西
  async function loadVitals(pt) {
    try {
      const url = location.pathname.replace(/\/inspectionreport\/?$/i, "/TPRSimple");
      if (url === location.pathname) return { note: "" };
      const p2 = (n) => String(n).padStart(2, "0"), d = new Date(), a = new Date(d.getFullYear() - 10, d.getMonth(), d.getDate());
      const ymd = (x) => `${x.getFullYear()}/${p2(x.getMonth() + 1)}/${p2(x.getDate())}`;
      const key = $("#AjaxRequestKey"), body = new URLSearchParams();
      for (const h of document.querySelectorAll('input[name="HOSP_CODE"]:checked')) body.append("HOSP_CODE", h.value);
      body.append("AjaxRequestKey", key ? key.value : "");
      body.append("begindate", ymd(a)); body.append("enddate", ymd(d)); body.append("typePara", "TPR_Simple_V");
      const r = await fetch(url, { method: "POST", credentials: "include", headers: { "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8", AjaxRequestKey: key ? key.value : "" },
        body: body.toString(), signal: AbortSignal.timeout ? AbortSignal.timeout(20000) : undefined });
      if (r.status !== 200) return { note: "身高體重沒有帶入（TPR 頁回應 " + r.status + "），請手填" };
      const t = await r.text();
      if (LOGIN.test(t.slice(0, 3000))) return { note: "身高體重沒有帶入（院內登入已逾時），請手填" };
      const doc = new DOMParser().parseFromString(t, "text/html");   // 只解析，不執行裡面的 script
      const c = doc.getElementById("CurrentChartno"), chart = c ? String(c.getAttribute("value") || "").trim() : "";
      if (!chart || chart !== pt.chart) return { note: "身高體重沒有帶入：TPR 頁讀到的病人和這一頁不同（可能另一個分頁開了別的病人），請手填" };
      const rows = [];
      for (const tb of doc.querySelectorAll("table")) {
        const hs = [...tb.querySelectorAll("thead th, tr:first-child th")].map((h) => h.textContent.replace(/\s+/g, ""));
        const iD = hs.indexOf("日期"), iW = hs.indexOf("Weight"), iH = hs.indexOf("Height");
        if (iD < 0 || iW < 0 || iH < 0) continue;
        for (const tr of tb.querySelectorAll("tbody tr")) {
          const td = [...tr.querySelectorAll("td")]; if (td.length <= Math.max(iD, iW, iH)) continue;
          const day = (td[iD].textContent.match(/\d{4}\/\d{1,2}\/\d{1,2}/) || [""])[0];
          rows.push([day, td[iW].textContent, td[iH].textContent]);
        }
      }
      const v = Z.parseBodySize(rows);
      return { vitals: v, note: Object.keys(v).length ? "" : "TPR 頁近 10 年沒有身高體重紀錄，請手填" };
    } catch (e) { return { note: "身高體重沒有帶入（讀 TPR 頁失敗），請手填" }; }
  }

  // ---------- ③ 🧮 計算機（v0.5.0，老闆 msg1028／1030）----------
  // 網頁版「檢驗資料臨床計算機」整頁包在外掛裡（labzh_calc.js），用 sandbox iframe（只給 allow-scripts、allow-modals：
  // 能跑計算機和列印，但碰不到院內頁面、也不連外）；病人資料只在這個視窗裡，不進網址、不送出去
  async function onCalc() {
    if (busy) return; busy = true;
    try {
      if (typeof LABZH_CALC_HTML !== "string") throw new Error("計算機沒有載入，請重新整理這一頁。");
      const pt = patient(), fd = formDates(), sp = span(fd);
      const [items, vt] = await Promise.all([loadMix(pt, fd), loadVitals(pt)]);
      const P = Z.calcPrefill({ dict: DICT, items, birth: pt.birth, sex: pt.sex, from: fd.startdate, to: fd.enddate, vitals: vt.vitals, vitNote: vt.note });
      toast("", 1);
      const { bar, body } = shell("檢驗資料臨床計算機（自動帶入）", { narrow: true, key: "calc" });
      // allow＝clipboard-write：讓計算機的「複製結果摘要」能寫剪貼簿（B 審 m2；不給 same-origin，仍碰不到院內頁面）
      const fr = el("iframe", { id: "labzh-calc", title: "計算機", sandbox: "allow-scripts allow-modals", allow: "clipboard-write", style: "flex:1;border:0;width:100%;background:#eceae2" });
      fr.srcdoc = Z.calcDoc(LABZH_CALC_HTML, P);
      body.append(fr);
      bar.append(el("span", { text: sp.days && sp.days < 360 ? "院內查詢區間不到一年，帶入的是這段期間的值" : "複製、列印請用視窗裡的按鈕", style: "color:#555" }), btn("關閉", closeOverlay));
    } catch (e) { toast(String((e && e.message) || e), 9000); }
    finally { busy = false; }
  }

  // ---------- 按鈕：放在院內「列印」鈕旁邊 ----------
  function addButtons() {
    if ($("#labzh-day")) return true;
    const anchor = $("#printReport");
    if (!anchor) return false;
    const mk = (id, text, title, fn) => el("button", { type: "button", id, class: "btn btn-sm", title, text, onclick: (e) => { e.preventDefault(); fn(); },
      style: "margin-left:6px;padding:2px 10px;border:1px solid #0b6e4f;border-radius:4px;background:#e9f6f0;color:#0b4f3a;cursor:pointer;white-space:nowrap" });
    const b2 = mk("labzh-trend", "📈 多項變化", "勾選多個項目，印出查詢區間內每次的數值與折線圖（中文說明版）", onTrend);
    const b3 = mk("labzh-calc-btn", "🧮 計算機", "把查詢區間內每項最近一次的檢驗值自動帶入臨床計算機（eGFR、FIB-4、HOMA-IR、血脂風險、CHA2DS2-VASc 等），可複製、列印", onCalc);
    const b1 = mk("labzh-day", "🖨 中文版", "把這一天的檢驗報告整理成中文說明版（沒勾就是當天全部）", onDay);
    anchor.insertAdjacentElement("afterend", b3);
    anchor.insertAdjacentElement("afterend", b2);
    anchor.insertAdjacentElement("afterend", b1);
    return true;
  }
  if (!addButtons()) {
    const mo = new MutationObserver(() => { if (addButtons()) mo.disconnect(); });
    mo.observe(document.documentElement, { childList: true, subtree: true });
    setTimeout(() => mo.disconnect(), 30000);
  }
})();
