// 中文檢驗報告：純函式（對照表比對、高低標示、組報告、輸出列印頁 HTML）。不碰網頁、不連網，Node 也能測。
// 院內明細欄位依體系病歷「檢驗」頁 renderRptDetailTable／門診工作台 parseDetail：項目、檢體、結果值、標準值、單位、ABNORMAL_FLAG、危急值通報、採檢日、報告日、DETAIL_CODE。
var LABZH = (function () {
  "use strict";
  const VERSION_DATE = "2026-11-23";
  const FOOTER = "非官方中文報告，翻譯僅供參考";   // 老闆 msg808 指定
  const CAT_ORDER = ["血糖", "腎功能", "肝功能", "血脂", "甲狀腺", "荷爾蒙", "電解質", "血球", "凝血", "發炎", "腫瘤標記", "尿液", "其他"];
  const UNKNOWN_CAT = "其他（無中文對照）";

  const esc = (s) => String(s == null ? "" : s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const str = (v) => String(v == null ? "" : v).trim();

  // ---------- 對照表 ----------
  function compileDict(entries) {
    const out = [];
    for (const e of Array.isArray(entries) ? entries : []) {
      if (!e || !e.zh) continue;
      const res = [];
      for (const m of [].concat(e.match || [])) { try { res.push(new RegExp(m, "i")); } catch (err) { /* 壞的規則跳過，build_dict 會先擋 */ } }
      out.push({ res, codes: [].concat(e.code || []).map((c) => str(c).toUpperCase()).filter(Boolean), zh: str(e.zh), en: str(e.en),
        cat: CAT_ORDER.includes(e.cat) ? e.cat : "其他", what: str(e.what), note: str(e.note), spec: e.spec === "urine" || e.spec === "blood" ? e.spec : "",
        units: [].concat(e.units || []).map((u) => str(u).toLowerCase().replace(/\s+/g, "")).filter(Boolean) });
    }
    return out;
  }
  const AMBIG_NO_UNIT = /^\s*tg\s*$/i;
  const isUrine = (x) => /尿|urine/i.test(str(x.spec) + " " + str(x.kind));
  function lookup(dict, x) {
    const urine = isUrine(x), code = str(x.code).toUpperCase(), name = str(x.name);
    // 有 units 的規則：報告有單位就要對得上。裸寫 TG（三酸甘油酯 mg/dL 或甲狀腺球蛋白 ng/mL）沒有單位時不猜，保留英文
    const unit = str(x.unit).toLowerCase().replace(/\s+/g, "");
    if (!unit && AMBIG_NO_UNIT.test(name)) return null;
    const ok = (e) => (!e.spec || (e.spec === "urine") === urine) && (!e.units.length || !unit || e.units.includes(unit));
    if (code) for (const e of dict) if (ok(e) && e.codes.includes(code)) return e;
    if (name) for (const e of dict) if (ok(e) && e.res.some((r) => r.test(name))) return e;
    return null;
  }

  // ---------- 結果、標示 ----------
  // 定性結果翻成中文，原文放括號；數字不動
  const VALUE_ZH = [
    [/^neg(ative)?$|^\(-\)$|^-$/i, "陰性"], [/^pos(itive)?$|^\(\+\)$/i, "陽性"], [/^trace$|^\(±\)$|^±$/i, "微量"],
    [/^non[- ]?reactive$/i, "無反應"], [/^reactive$/i, "有反應"], [/^not detected$|^undetected$/i, "未檢出"], [/^detected$/i, "檢出"],
    [/^normal$/i, "正常"], [/^abnormal$/i, "異常"], [/^none$|^nil$/i, "無"], [/^few$/i, "少量"], [/^many$/i, "多量"],
    [/^clear$/i, "清澈"], [/^turbid$/i, "混濁"], [/^sl(ightly)?\.? ?turbid$/i, "微混濁"], [/^cloudy$/i, "混濁"],
    [/^yellow$/i, "黃色"], [/^pale yellow$|^light yellow$/i, "淡黃色"], [/^straw$/i, "淡黃色"], [/^amber$/i, "琥珀色"], [/^dark yellow$/i, "深黃色"],
  ];
  function valueText(v) {
    const s = str(v);
    for (const [re, zh] of VALUE_ZH) if (re.test(s)) return { text: zh, orig: s };
    return { text: s, orig: "" };
  }
  // 高低以院內 ABNORMAL_FLAG 為準，不自己拿參考值重算
  function flagInfo(flag) {
    const f = str(flag).toUpperCase();
    if (f === "HH") return { cls: "hi", text: "↑↑偏高" };
    if (f === "H") return { cls: "hi", text: "↑偏高" };
    if (f === "LL") return { cls: "lo", text: "↓↓偏低" };
    if (f === "L") return { cls: "lo", text: "↓偏低" };
    if (f === "A" || f === "Y" || f === "*") return { cls: "ab", text: "＊異常" };
    return null;
  }
  const refText = (s) => str(s).replace(/\bMale\b|\bM\s*[:：]/g, "男：").replace(/\bFemale\b|\bF\s*[:：]/g, "女：");

  // 院內明細 → 一列
  function parseDetail(result, kind) {
    return ((result && result.detailReport) || []).map((r) => ({
      name: str(r["項目"]), spec: str(r["檢體"]), value: str(r["結果值"]), ref: str(r["標準值"]), unit: str(r["單位"]),
      flag: str(r.ABNORMAL_FLAG), critical: !!str(r["危急值通報"]) && !/^(N|否|0)$/i.test(str(r["危急值通報"])),
      sampled: str(r["採檢日"]), reported: str(r["報告日"]), code: str(r.DETAIL_CODE), kind: str(kind),
    })).filter((x) => x.name && !/^收到檢體$/.test(x.name));   // 「收到檢體」是採檢時間列
  }

  // ---------- 組報告 ----------
  // reports：[{kind, hosp, rows:[parseDetail 結果]}]；patient：{name, chart}
  function buildReport(o) {
    const dict = o.dict || [], sections = new Map();
    const sampled = new Set(), reported = new Set(), hosps = new Set(), kinds = [];
    let unknown = 0, abnormal = 0, critical = 0;
    for (const rep of o.reports || []) {
      if (rep.hosp) hosps.add(str(rep.hosp));
      if (rep.kind && !kinds.includes(rep.kind)) kinds.push(rep.kind);
      for (const x of rep.rows || []) {
        const e = lookup(dict, x), cat = e ? e.cat : UNKNOWN_CAT;
        if (!e) unknown++;
        const fl = flagInfo(x.flag);
        if (fl) abnormal++;
        if (x.critical) critical++;
        if (x.sampled) sampled.add(x.sampled.split(/\s+/)[0]);
        if (x.reported) reported.add(x.reported.split(/\s+/)[0]);
        if (!sections.has(cat)) sections.set(cat, []);
        sections.get(cat).push({ zh: e ? e.zh : "", name: x.name, value: valueText(x.value), unit: x.unit, ref: refText(x.ref), flag: fl, critical: !!x.critical,
          what: e ? e.what : "", note: e ? e.note : "", urine: isUrine(x) && !(e && e.cat === "尿液") });
      }
    }
    const order = [...CAT_ORDER, UNKNOWN_CAT];
    return {
      patient: { name: str(o.patient && o.patient.name), chart: str(o.patient && o.patient.chart) },
      hosp: [...hosps].join("、") || str(o.hospName), kinds, sampled: [...sampled].sort(), reported: [...reported].sort(),
      sections: order.filter((c) => sections.has(c)).map((c) => ({ cat: c, items: sections.get(c) })),
      count: [...sections.values()].reduce((a, b) => a + b.length, 0), unknown, abnormal, critical, printed: str(o.now), notes: (o.notes || []).map(str).filter(Boolean),
    };
  }

  // ---------- 列印頁 ----------
  const CSS = `@page{size:A4;margin:14mm 12mm 16mm}
*{box-sizing:border-box}body{margin:0;color:#000;background:#fff;font:15px/1.5 "Microsoft JhengHei","PingFang TC","Noto Sans TC",sans-serif}
h1{font-size:22px;margin:0 0 4px}.sub{font-size:13px;color:#333;margin-bottom:8px}
.pt{display:flex;flex-wrap:wrap;gap:4px 22px;border:1.5px solid #000;padding:6px 10px;margin:6px 0 8px;font-size:16px}.pt b{font-weight:700}
.tip{font-size:13.5px;margin:0 0 8px}
h2{font-size:17px;margin:12px 0 4px;padding:2px 8px;border-left:5px solid #000;background:#eee;-webkit-print-color-adjust:exact;print-color-adjust:exact}
table{width:100%;border-collapse:collapse;page-break-inside:auto}tr{page-break-inside:avoid}
th,td{border:1px solid #888;padding:4px 6px;vertical-align:top;text-align:left}th{background:#f3f3f3;font-size:13.5px;-webkit-print-color-adjust:exact;print-color-adjust:exact}
td.n{width:27%}td.n .en{display:block;font-size:12px;color:#444}td.v{width:17%;white-space:nowrap}td.u{width:10%;font-size:13px}td.r{width:16%;font-size:13px}td.w{font-size:13.5px}
.orig{font-size:12px;color:#444}.fl{font-weight:700;display:block}tr.hi td.v,tr.lo td.v,tr.ab td.v{font-weight:700}
tr.hi td.v,tr.lo td.v,tr.ab td.v{background:#f2f2f2;-webkit-print-color-adjust:exact;print-color-adjust:exact}
.crit{display:inline-block;border:1.5px solid #000;padding:0 3px;font-weight:700;font-size:12px;margin-top:2px}
.foot{margin-top:14px;border-top:1.5px solid #000;padding-top:6px;font-size:14px;font-weight:700}.ver{font-size:11.5px;color:#555;font-weight:400;margin-top:2px}
@media screen{body{padding:18px 22px;max-width:900px;margin:0 auto}}`;
  function renderHTML(m) {
    const row = (it) => {
      const cls = it.flag ? it.flag.cls : "";
      const name = it.zh ? `${esc(it.zh)}${it.urine ? "（尿）" : ""}<span class="en">${esc(it.name)}</span>` : `${esc(it.name)}<span class="en">（無中文對照）</span>`;
      const val = esc(it.value.text) + (it.value.orig ? ` <span class="orig">(${esc(it.value.orig)})</span>` : "") +
        (it.flag ? `<span class="fl">${esc(it.flag.text)}</span>` : "") + (it.critical ? `<span class="crit">危急值</span>` : "");
      const what = esc(it.what) + (it.note ? `<br><span class="orig">${esc(it.note)}</span>` : "");
      return `<tr${cls ? ` class="${cls}"` : ""}><td class="n">${name}</td><td class="v">${val}</td><td class="u">${esc(it.unit)}</td><td class="r">${esc(it.ref)}</td><td class="w">${what}</td></tr>`;
    };
    const sec = (s) => `<h2>${esc(s.cat)}</h2><table><thead><tr><th>項目</th><th>結果</th><th>單位</th><th>參考範圍</th><th>這項在看什麼</th></tr></thead><tbody>${s.items.map(row).join("")}</tbody></table>`;
    const pt = [["姓名", m.patient.name], ["病歷號", m.patient.chart], ["院區", m.hosp], ["採檢日", m.sampled.join("、")], ["報告日", m.reported.join("、")]]
      .filter((p) => p[1]).map((p) => `<span>${esc(p[0])}：<b>${esc(p[1])}</b></span>`).join("");
    return `<!doctype html><html lang="zh-Hant"><head><meta charset="utf-8"><title>檢驗報告（中文說明版）</title><style>${CSS}</style></head><body>
<h1>檢驗報告（中文說明版）</h1><div class="sub">${esc(m.kinds.join("、"))}</div>
<div class="pt">${pt}</div>
<p class="tip">結果旁標「↑偏高」「↓偏低」「＊異常」的項目，請和醫師討論。</p>
${(m.notes || []).map((n) => `<p class="tip">※ ${esc(n)}</p>`).join("")}
${m.sections.map(sec).join("\n")}
<div class="foot">${esc(FOOTER)}<div class="ver">列印時間：${esc(m.printed)}　工具版本：${VERSION_DATE}</div></div>
</body></html>`;
  }

  // ---------- 單項一年變化（老闆 msg811；院內「整合」Mix 模式，格式同門診工作台 mixMerge）----------
  // 不做趨勢的報告類別（培養、鏡檢、糞便、新冠、結核基因、血庫）
  const NO_TREND = /培養|鏡檢|糞便|COVID|GeneXpert|抗酸菌|革蘭|血庫/i;
  const fmtDay = (k) => (/^\d{8}$/.test(k) ? k.slice(0, 4) + "/" + k.slice(4, 6) + "/" + k.slice(6, 8) : str(k));
  const dayKey = (s) => { const d = str(s).replace(/\D/g, ""); return d.length >= 8 ? d.slice(0, 8) : ""; };
  // results：[{kind, res}]，res = {columnsDateTime, rowItems:["項目@檢體"], mixTableData:[{COLLECT_DATE_N, 項目, CHART_VALUE}]}
  function mixMerge(results) {
    const items = new Map();
    const keyOf = (raw, kind) => { const [n, sp] = str(raw).split("@"); const urine = /urine|尿/i.test(sp || ""); return { name: str(n), spec: str(sp), urine, k: str(n) + "@" + str(sp) + "@" + (urine ? "U" : kind) }; };
    for (const { kind, res } of results || []) {
      if (!res || !Array.isArray(res.mixTableData)) continue;
      for (const raw of Array.isArray(res.rowItems) ? res.rowItems : []) {
        const o = keyOf(raw, kind);
        if (!o.name || /^收到檢體$/.test(o.name) || items.has(o.k)) continue;
        items.set(o.k, { id: "i" + items.size, name: o.name, spec: o.spec, kind: o.urine ? "尿液檢驗" : kind, values: {} });
      }
      for (const d of res.mixTableData) {
        const day = dayKey(d.COLLECT_DATE_N), v = str(d.CHART_VALUE), o = keyOf(d["項目"], kind), it = items.get(o.k);
        if (!/^\d{8}$/.test(day) || !v || !it) continue;
        if (!(day in it.values)) it.values[day] = v;   // 同一天多次採檢取第一個
      }
    }
    return [...items.values()].filter((x) => Object.keys(x.values).length);
  }
  const num = (v) => { const m = /^[<>≦≧]?\s*(-?\d+(?:\.\d+)?)\s*$/.exec(str(v)); return m ? +m[1] : null; };
  // 折線圖（黑白列印看得清楚）：x 依日期比例、y 自動範圍，每點標數值
  function trendSVG(points) {
    const pts = points.map((p) => ({ day: p.day, y: num(p.v), t: Date.UTC(+p.day.slice(0, 4), +p.day.slice(4, 6) - 1, +p.day.slice(6, 8)) })).filter((p) => p.y !== null).sort((a, b) => a.t - b.t);
    if (pts.length < 2) return "";
    const W = 640, H = 200, L = 46, R = 10, T = 24, B = 34;
    let lo = Math.min(...pts.map((p) => p.y)), hi = Math.max(...pts.map((p) => p.y));
    if (hi === lo) { hi += Math.abs(hi) * 0.1 || 1; lo -= Math.abs(lo) * 0.1 || 1; } else { const pad = (hi - lo) * 0.15; hi += pad; lo -= pad; }
    const t0 = pts[0].t, t1 = pts[pts.length - 1].t;
    const P = 26;   // 左右內縮，點的數值標籤才不會壓到 y 軸刻度、最後一個日期才不會被切掉
    const X = (t) => L + P + (t1 === t0 ? (W - L - R - 2 * P) / 2 : ((t - t0) / (t1 - t0)) * (W - L - R - 2 * P)), Y = (y) => T + (1 - (y - lo) / (hi - lo)) * (H - T - B);
    const g = (n) => +n.toFixed(1), lab = (y) => +y.toPrecision(3);
    const grid = [lo, (lo + hi) / 2, hi].map((y) => `<line x1="${L}" x2="${W - R}" y1="${g(Y(y))}" y2="${g(Y(y))}" stroke="#bbb" stroke-dasharray="3 3"/><text x="${L - 4}" y="${g(Y(y) + 4)}" text-anchor="end" font-size="11">${lab(y)}</text>`).join("");
    const line = `<polyline fill="none" stroke="#000" stroke-width="2" points="${pts.map((p) => g(X(p.t)) + "," + g(Y(p.y))).join(" ")}"/>`;
    const dots = pts.map((p) => `<circle cx="${g(X(p.t))}" cy="${g(Y(p.y))}" r="4" fill="#fff" stroke="#000" stroke-width="2"/><text x="${g(X(p.t))}" y="${g(Y(p.y) - 8)}" text-anchor="middle" font-size="12" font-weight="700">${esc(p.y)}</text><text x="${g(X(p.t))}" y="${H - 12}" text-anchor="middle" font-size="10.5">${esc(fmtDay(p.day).slice(2))}</text>`).join("");
    return `<svg viewBox="0 0 ${W} ${H}" width="100%" style="max-width:${W}px" role="img" aria-label="變化圖">${grid}${line}${dots}</svg>`;
  }
  // picked：[{name, spec, kind, values, unit, ref}]（ref／unit 取最近一次單次報告）
  function buildTrend(o) {
    const dict = o.dict || [];
    const items = (o.items || []).map((x) => {
      const e = lookup(dict, { name: x.name, spec: x.spec, kind: x.kind, code: x.code, unit: x.unit });
      const days = Object.keys(x.values).sort();
      return { zh: e ? e.zh : "", name: x.name, cat: e ? e.cat : UNKNOWN_CAT, what: e ? e.what : "", note: e ? e.note : "", unit: str(x.unit), ref: refText(x.ref),
        urine: isUrine(x) && !(e && e.cat === "尿液"), rows: days.map((d) => ({ day: d, v: x.values[d], value: valueText(x.values[d]) })) };
    });
    return { patient: { name: str(o.patient && o.patient.name), chart: str(o.patient && o.patient.chart) }, hosp: str(o.hosp), from: str(o.from), to: str(o.to), items, printed: str(o.now) };
  }
  function renderTrendHTML(m) {
    const one = (it) => {
      const title = it.zh ? `${esc(it.zh)}${it.urine ? "（尿）" : ""} <span class="en">${esc(it.name)}</span>` : `${esc(it.name)} <span class="en">（無中文對照）</span>`;
      const meta = [it.unit ? "單位：" + esc(it.unit) : "", it.ref ? "參考範圍：" + esc(it.ref) : ""].filter(Boolean).join("　");
      const rows = it.rows.map((r) => `<tr><td>${esc(fmtDay(r.day))}</td><td class="v">${esc(r.value.text)}${r.value.orig ? ` <span class="orig">(${esc(r.value.orig)})</span>` : ""}</td></tr>`).join("");
      return `<section class="it"><h2>${title}</h2>${it.what ? `<p class="what">${esc(it.what)}${it.note ? `（${esc(it.note)}）` : ""}</p>` : ""}${meta ? `<p class="meta">${meta}</p>` : ""}
<div class="tw">${trendSVG(it.rows)}<table class="tt"><thead><tr><th>日期</th><th>結果</th></tr></thead><tbody>${rows}</tbody></table></div></section>`;
    };
    const pt = [["姓名", m.patient.name], ["病歷號", m.patient.chart], ["院區", m.hosp], ["期間", m.from && m.to ? fmtDay(m.from) + "～" + fmtDay(m.to) : ""]]
      .filter((p) => p[1]).map((p) => `<span>${esc(p[0])}：<b>${esc(p[1])}</b></span>`).join("");
    return `<!doctype html><html lang="zh-Hant"><head><meta charset="utf-8"><title>檢驗變化（中文說明版）</title><style>${CSS}
.it{page-break-inside:avoid;margin-bottom:10px}.it h2 .en{font-size:12.5px;font-weight:400;color:#444}.what,.meta{margin:2px 0;font-size:13.5px}
.tw{display:flex;gap:12px;align-items:flex-start}.tw svg{flex:1 1 auto}.tt{width:auto;min-width:190px}.tt th{white-space:nowrap}.tt td.v{font-weight:700}</style></head><body>
<h1>檢驗數值變化（中文說明版）</h1>
<div class="pt">${pt}</div>
<p class="tip">數值高低的意義請和醫師討論；參考範圍以最近一次報告為準。</p>
${m.items.map(one).join("\n")}
<div class="foot">${esc(FOOTER)}<div class="ver">列印時間：${esc(m.printed)}　工具版本：${VERSION_DATE}</div></div>
</body></html>`;
  }

  return { VERSION_DATE, FOOTER, CAT_ORDER, UNKNOWN_CAT, NO_TREND, esc, compileDict, lookup, isUrine, valueText, flagInfo, refText, parseDetail, buildReport, renderHTML,
    fmtDay, dayKey, mixMerge, num, trendSVG, buildTrend, renderTrendHTML };
})();
if (typeof module !== "undefined") module.exports = LABZH;
