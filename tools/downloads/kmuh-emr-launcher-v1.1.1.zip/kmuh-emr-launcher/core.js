// 院區與網址：現役四大院區（高醫、岡山、小港雙網域、旗津），已移除廢止之大同 (kmtth) 與舊小港 (kmhk)
const HOSPS = {
  kmuh: { name: "高醫", base: "https://intraweb.server.kmuh.org.tw", path: "/WEB/ipdNote" },
  kmugh: { name: "岡山", base: "https://intraweb.kmugh.org.tw", path: "/WEB/ipdNote" },
  kmsh: {
    name: "小港",
    base: "https://intraweb.server.kmsh.org.tw",
    altBases: ["https://hisintraweb.kmsh.org.tw"],
    path: "/WEB/ipdNote",
  },
  kmch: { name: "旗津", base: "https://intraweb.server.kmch.org.tw", path: "/WEB/ipdNote" },
};

// 後端 UIPD.FN_GET_MRN_URL 查無病歷號時回傳的固定空值 DES 密文
const EMPTY_MRN_CIPHER = "50FB72297079EEFA";

function resolveBase(h, tabUrl) {
  const info = HOSPS[h];
  if (!info) return "";
  if (tabUrl && Array.isArray(info.altBases)) {
    const lowerTab = String(tabUrl).toLowerCase();
    const matched = info.altBases.find((b) => lowerTab.startsWith(b.toLowerCase()));
    if (matched) return matched;
  }
  return info.base;
}

function apiUrl(h, tabUrl) {
  return resolveBase(h, tabUrl) + HOSPS[h].path + "/Common/GetMRNUrl";
}

function apiUrls(h) {
  const info = HOSPS[h];
  const bases = [info.base, ...(Array.isArray(info.altBases) ? info.altBases : [])];
  return bases.map((b) => b + info.path + "/Common/GetMRNUrl");
}

function loginUrl(h) {
  return HOSPS[h].base + HOSPS[h].path + "/";
}

function tabPatterns(h) {
  const info = HOSPS[h];
  if (Array.isArray(info.altBases) && info.altBases.length > 0) {
    return [info.base + "/*", ...info.altBases.map((b) => b + "/*")];
  }
  return info.base + "/*";
}

// 病歷號：過濾半形/全形空白；英數字 1 到 15 碼；純數字 1~7 碼自動補齊 8 碼前導零防範 Oracle ORA-28232 (HTTP 500)
function cleanChartno(s) {
  const t = String(s || "").replace(/^[\s\u3000]+|[\s\u3000]+$/g, "");
  if (!/^[A-Za-z0-9]{1,15}$/.test(t)) return "";
  return /^\d{1,7}$/.test(t) ? t.padStart(8, "0") : t;
}

// GetMRNUrl 回傳的是網址字串；未登入時會被導到入口網的 HTML 登入頁；查無病歷時可能回傳空密文 50FB72297079EEFA
function parseNoteUrl(text) {
  let t = String(text || "").trim();
  if (t.startsWith('"') && t.endsWith('"')) {
    try {
      t = JSON.parse(t);
    } catch (e) {
      t = t.slice(1, -1);
    }
  }
  t = t.trim();
  if (
    /<html|<!doctype|高醫體系資訊系統入口網|資訊系統入口網|kmuh-captcha|AuthServer|\/Account\/Login/i.test(
      t
    )
  ) {
    return { ok: false, reason: "login" };
  }
  if (/^https?:\/\/\S+$/i.test(t)) {
    if (new RegExp("id=" + EMPTY_MRN_CIPHER, "i").test(t)) {
      return { ok: false, reason: "notfound" };
    }
    if (/[?&]id=(?:$|&)/i.test(t)) {
      return { ok: false, reason: "notfound" };
    }
    if (!/ioenote|id=/i.test(t)) {
      return { ok: false, reason: "notfound" };
    }
    return { ok: true, url: t };
  }
  return { ok: false, reason: "notfound" };
}

if (typeof module !== "undefined") {
  module.exports = {
    HOSPS,
    EMPTY_MRN_CIPHER,
    resolveBase,
    apiUrl,
    apiUrls,
    loginUrl,
    tabPatterns,
    cleanChartno,
    parseNoteUrl,
  };
}
