# 高醫電子病歷快速跳轉 (`kmuh-emr-launcher`)

高醫醫療體系院內專用 Chrome MV3 擴充功能：選院區、輸入病歷號，直接開啟該病人的電子病歷（沿用 Chrome 已登入的院內 SSO 帳號，免重輸密碼與驗證碼）。

## 支援院區與網域

已移除院內 DNS 廢止（`NXDOMAIN`）的大同 (`kmtth`) 與舊小港 (`kmhk`)，全面對齊現役四大院區：

- **高醫 (`kmuh`)**：`https://intraweb.server.kmuh.org.tw`
- **岡山 (`kmugh`)**：`https://intraweb.kmugh.org.tw`
- **小港 (`kmsh`)**：主網域 `https://intraweb.server.kmsh.org.tw`（同時支援小港入口網 `ipdNote` 實際網域 `https://hisintraweb.kmsh.org.tw`）
- **旗津 (`kmch`)**：`https://intraweb.server.kmch.org.tw`

## 核心特性與安全防呆

1. **自動補齊 8 碼前導零（防範 Oracle `ORA-28232` / `HTTP 500`）**：
   - 自動過濾半形與全形空白（`\u3000`）。
   - 當輸入為 1~7 碼純數字病歷號（如 `123456`）時，自動以 `.padStart(8, "0")` 補齊為 `00123456`，避免後端 `UIPD.FN_GET_MRN_URL` 因 DES 8-byte 區塊加密限制拋出 `ORA-28232` (`HTTP 500`)。
   - 保留 1~15 碼含英文字母之外籍或臨時病歷號相容性。
2. **攔截空病歷號密文 (`50FB72297079EEFA`)**：
   - 當查無病歷號且後端回傳固定空值密文 `id=50FB72297079EEFA` 或非有效病歷路徑時，自動攔截並提示「查不到這個病歷號碼」，避免開啟空白病歷分頁。
3. **多分頁智慧路由與 8 秒逾時保護**：
   - 優先透過已開啟的同院區分頁發送同源 POST 請求（`postIn`）；若第一個分頁回傳非 200、`opaqueredirect` 或 SSO 登入頁 HTML，自動嘗試下一個同院區分頁，皆無有效回應時自動依序 fallback 至擴充功能直接查詢各主/副網域（`postDirect`）。
   - 內建 `AbortSignal.timeout(8000)` 防止院外網路無限卡死。
4. **Popup 錯誤訊息防閃退**：
   - 未登入時於背景分頁（`active: false`）預開登入頁，網路異常時直接於 Popup 顯示錯誤，不會因前景切換分頁導致 Popup 瞬間關閉吃掉提示訊息。
5. **最小化權限與快捷鍵**：
   - 僅使用 `storage` 與 `scripting` 權限（移除 `tabs` 權限，消除 Chrome「讀取瀏覽記錄」高風險警告）。
   - 預設綁定快捷鍵 **`Alt+E`** 免滑鼠一鍵喚醒跳轉視窗。
   - 職編於輸入時（`input` 事件）即時寫入 `chrome.storage.local`，且**絕不儲存病歷號**。

## 安裝方式

1. 開啟 Chrome 網址列輸入 `chrome://extensions`，開啟右上角「開發人員模式」。
2. 點選「載入未封裝項目」，選擇 `kmuh-emr-launcher` 資料夾。
3. 將擴充功能釘選至工具列（或按 `Alt+E` 喚醒），首次使用於「設定：職編」填入個人職編即可。

## 測試驗證

執行內建測試套件（含單元測試與 Node `vm` 沙箱整合測試共 70 項斷言）：

```bash
node test/run_tests.js
```

## 1.1.1（2026-10-25）
- 以 1.1.0 為準，只改頁尾，補上「工具版本：2026-10-25」。
