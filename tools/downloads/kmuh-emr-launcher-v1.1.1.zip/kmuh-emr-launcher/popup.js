const $ = (id) => document.getElementById(id);

function say(text, cls) {
  $("msg").textContent = text;
  $("msg").className = cls || "";
}

// 在院內網頁的分頁裡發查詢（同源，最穩）；沒有開著的分頁或分頁未登入時改由外掛直接發
async function postIn(tabId, url, body) {
  const [res] = await chrome.scripting.executeScript({
    target: { tabId },
    args: [url, body],
    func: async (u, b) => {
      const signal =
        typeof AbortSignal !== "undefined" && typeof AbortSignal.timeout === "function"
          ? AbortSignal.timeout(8000)
          : undefined;
      const r = await fetch(u, {
        method: "POST",
        credentials: "include",
        redirect: "manual",
        headers: { "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8" },
        body: b,
        signal,
      });
      return {
        status: r.status,
        type: r.type,
        text: r.type === "opaqueredirect" ? "" : await r.text(),
      };
    },
  });
  return res ? res.result : null;
}

async function postDirect(url, body) {
  const signal =
    typeof AbortSignal !== "undefined" && typeof AbortSignal.timeout === "function"
      ? AbortSignal.timeout(8000)
      : undefined;
  const r = await fetch(url, {
    method: "POST",
    credentials: "include",
    redirect: "manual",
    headers: { "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8" },
    body,
    signal,
  });
  return {
    status: r.status,
    type: r.type,
    text: r.type === "opaqueredirect" ? "" : await r.text(),
  };
}

function isAuthenticatedResponse(cand) {
  if (!cand || cand.status !== 200 || cand.type === "opaqueredirect") return false;
  return parseNoteUrl(cand.text).reason !== "login";
}

async function lookup(h, chartno, staff) {
  const body = new URLSearchParams({ inChartno: chartno, inLoginUser: staff }).toString();
  const tabs = await chrome.tabs.query({ url: tabPatterns(h) });
  let res = null;
  let lastRes = null;
  for (const t of tabs) {
    try {
      const cand = await postIn(t.id, apiUrl(h, t.url), body);
      if (cand) {
        lastRes = cand;
        if (isAuthenticatedResponse(cand)) {
          res = cand;
          break;
        }
      }
    } catch (e) {
      /* 分頁可能還在載入或注入失敗，繼續嘗試下一個同院區分頁 */
    }
  }
  if (!res) {
    const urls = typeof apiUrls === "function" ? apiUrls(h) : [apiUrl(h)];
    let lastErr = null;
    for (const u of urls) {
      try {
        const cand = await postDirect(u, body);
        lastRes = cand;
        if (isAuthenticatedResponse(cand)) {
          res = cand;
          break;
        }
      } catch (e) {
        lastErr = e;
      }
    }
    if (!res && !lastRes && lastErr) throw lastErr;
    res = res || lastRes;
  }
  // session 過期時會被轉址到入口網 SSO（另一個網域），不跟著轉址，看到轉址就當作未登入
  if (res.type === "opaqueredirect" || (res.status >= 300 && res.status < 400)) {
    return { ok: false, reason: "login" };
  }
  if (res.status !== 200) return { ok: false, reason: "http", status: res.status };
  return parseNoteUrl(res.text);
}

async function go() {
  const h = $("hosp").value;
  const chartno = cleanChartno($("chart").value);
  const staff = $("staff").value.trim();
  if (!staff) {
    $("set").open = true;
    say("請先在下方設定填入職編。", "err");
    $("staff").focus();
    return;
  }
  if (!chartno) {
    say("病歷號碼只能是英文字母或數字（最多 15 碼），請再確認。", "err");
    $("chart").focus();
    return;
  }
  $("go").disabled = true;
  say(`查詢中（${HOSPS[h].name}）…`);
  try {
    const r = await lookup(h, chartno, staff);
    if (r.ok) {
      say("已開啟。", "ok");
      $("chart").value = "";
      await chrome.tabs.create({ url: r.url, active: true });
    } else if (r.reason === "login") {
      say(`尚未登入${HOSPS[h].name}院內系統，已於背景開啟登入頁，登入後再按一次。`, "err");
      await chrome.tabs.create({ url: loginUrl(h), active: false });
    } else if (r.reason === "http") {
      say(`院內系統回應錯誤（${r.status}），請確認是否在院內網路。`, "err");
    } else {
      say("查不到這個病歷號碼，請再確認院區和號碼。", "err");
    }
  } catch (e) {
    say("無法連線至院內系統，請確認是否在院內網路或連線逾時。", "err");
  } finally {
    $("go").disabled = false;
  }
}

(async function init() {
  for (const [k, v] of Object.entries(HOSPS)) {
    const o = document.createElement("option");
    o.value = k;
    o.textContent = v.name;
    $("hosp").appendChild(o);
  }
  const s = await chrome.storage.local.get(["hosp", "staff"]);
  if (s.hosp && HOSPS[s.hosp]) $("hosp").value = s.hosp;
  if (s.staff) $("staff").value = s.staff;
  else $("set").open = true;
  $("hosp").addEventListener("change", () => chrome.storage.local.set({ hosp: $("hosp").value }));
  $("staff").addEventListener("input", () =>
    chrome.storage.local.set({ staff: $("staff").value.trim() })
  );
  $("go").addEventListener("click", go);
  $("chart").addEventListener("keydown", (e) => {
    if (e.key === "Enter") go();
  });
  $("chart").focus();
})();
