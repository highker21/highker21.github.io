// 院區與網址：院內病歷網址查詢（GetMRNUrl）與檢查報告頁（EXAMReport）
// 大同（2026-07 起不在高醫體系）與舊小港網域，院內 DNS 已查不到（院內實測），先拿掉；小港新網域與旗津的報告頁路徑未確認，暫不放
const HOSPS = {
  kmuh: { name: "高醫", base: "https://intraweb.server.kmuh.org.tw", note: "/WEB/ipdNote", exam: "/WEB/MRN/EXAMReport" },
  kmugh: { name: "岡山", base: "https://intraweb.kmugh.org.tw", note: "/WEB/ipdNote", exam: "/web/MRN/ExamReport" },
};

function apiUrl(h) { return HOSPS[h].base + HOSPS[h].note + "/Common/GetMRNUrl"; }
function examUrl(h) { return HOSPS[h].base + HOSPS[h].exam; }

// 一串病歷號：換行、空白、逗號、頓號都可分隔；純數字不足 8 碼補 0（原程式 zfill(8)，Excel 會吃掉開頭的 0）
function parseChartList(text) {
  const valid = [], invalid = [], seen = new Set();
  for (let t of String(text || "").split(/[\s,，;；、]+/)) {
    if (!t) continue;
    if (!/^[A-Za-z0-9]{1,15}$/.test(t)) { invalid.push(t); continue; }
    if (/^\d+$/.test(t) && t.length < 8) t = t.padStart(8, "0");
    if (!seen.has(t)) { seen.add(t); valid.push(t); }
  }
  return { valid, invalid };
}

// 原程式的篩選：列文字含「病理報告」且 data-content 含「Thyroid aspiration」（這裡不分大小寫）
function isThyroidCyto(row) {
  return String(row.text || "").includes("病理報告") && /thyroid\s+aspiration/i.test(row.content || "");
}

// 部位：甲狀腺照原程式（Thyroid aspiration）；淋巴結報告的檢體只寫「Lymph node.」、沒有 aspiration 字樣，
// 用「有 Specimen adequacy 欄」認定是細胞學（組織切片沒有這欄），檢體含 lymph node 就歸淋巴結
function cytoSite(row) {
  if (!String(row.text || "").includes("病理報告")) return "";
  const c = String(row.content || "");
  if (/thyroid\s+aspiration/i.test(c)) return "甲狀腺";
  if (/Specimen adequacy\s*:/i.test(c) && /lymph\s*nodes?/i.test(parseReport(c).specimen)) return "淋巴結";
  return "";
}

// 分級只看 Diagnosis 欄（Clinical diagnosis 常寫 cancer，不能掃全文）
// 「cannot rule out／cannot be excluded／r/o」是不確定、不是確診 → suspicious
// 否定詞（negative for／no evidence of／no／without／free of）一路刪到句尾，遇到 but／however 停：
// 「Negative for metastatic carcinoma.」整句不算，「No malignant cells, but atypical lymphoid cells」保留 atypical
// 刪完再依序判 suspicious → malignant → atypia；Bethesda IV（follicular neoplasm）、nondiagnostic、benign 不分級
function grade(diagnosis) {
  const raw = String(diagnosis || "");
  if (/cannot\s+(be\s+)?(rule[ds]?\s+out|excluded?)|\br\/o\b/i.test(raw)) return "suspicious";
  const d = raw.replace(/\b(negative\s+for|no\s+evidence\s+of|no|without|free\s+of)\b[^.;\n]*?(?=\bbut\b|\bhowever\b|[.;\n]|$)/gi, " ");
  if (/suspicious\s+for|bethesda\s*(category\s*)?V\b/i.test(d)) return "suspicious";
  if (/malignan|carcinoma|cancer|metasta|lymphoma|bethesda\s*(category\s*)?VI\b/i.test(d)) return "malignant";
  if (/atypi|\bAUS\b|\bFLUS\b|bethesda\s*(category\s*)?III\b/i.test(d)) return "atypia";
  return "";
}

function grab(s, re) { const m = String(s).match(re); return m ? m[1].trim() : ""; }

// 欄位切法對照原程式的 split()，改成容許多一兩個空白的正規式
function parseReport(content) {
  const c = String(content || "").replace(/\r\n?/g, "\n");
  return {
    date: grab(c, /採檢日：\s*(\S+(?:\s+\d{1,2}:\d{2}(?::\d{2})?)?)/),
    name: grab(c, /病人姓名：\s*([\s\S]*?)\s*出生日期：/),
    // 號碼後面可能用 - 隔開最後一碼（0012345-6），一起抓；後面緊接英數字的（2026-10-25、床號）不併
    chartInReport: grab(c, /病歷號(?:碼)?\s*[：:]\s*([A-Za-z0-9]+(?:[ \t]*[-－][ \t]*[A-Za-z0-9](?![A-Za-z0-9]))?)/),
    specimen: grab(c, /Specimen:\s*\n([\s\S]*?)\n\s*Diagnosis/),
    diagnosis: grab(c, /Diagnosis:\s*([\s\S]*?)\n\s*Specimen adequacy:/),
    adequacy: grab(c, /Specimen adequacy:\s*\n?\s*([^\n]*)/),
    full: c.trim(),
  };
}

// 日期排序鍵：抓出年月日（時分），民國年自動加 1911；抓不到回 ""（排最後）
function dateKey(s) {
  const n = String(s || "").match(/\d+/g);
  if (!n || n.length < 3) return "";
  let y = +n[0]; if (y < 1911) y += 1911;
  const p = (x) => String(+x || 0).padStart(2, "0");
  return String(y) + p(n[1]) + p(n[2]) + p(n[3]) + p(n[4]);
}

// 最近一次：採檢日最大者；同日或日期讀不到時取列表中較前面那筆
function pickLatest(reports) {
  let best = null, bk = null;
  for (const r of reports) {
    const k = dateKey(r.date);
    if (best === null || k > bk) { best = r; bk = k; }
  }
  return best;
}

// 比對前去掉分隔符與開頭的 0
function normChart(x) { return String(x).replace(/[^A-Za-z0-9]/g, "").replace(/^0+/, "").toUpperCase(); }
function sameChart(a, b) { return normChart(a) === normChart(b); }
// 報告號沒有分隔符、只到倒數第二碼
function missingLastDigit(rep, chartno) { const r = normChart(rep), c = normChart(chartno); return /^[A-Za-z0-9]+$/.test(String(rep).trim()) && r.length >= 4 && r === c.slice(0, -1); }

// 把一位病人的原始查詢結果整理成表格的一列
function summarize(chartno, res, site = "甲狀腺") {
  const row = { chartno, site, status: "", grade: "", count: 0, date: "", name: "", specimen: "", diagnosis: "", adequacy: "", full: "" };
  if (res.stage === "login") { row.status = "查詢失敗：院內連線過期或被導向登入頁"; return row; }
  if (res.stage === "http") { row.status = `查詢失敗：院內系統回應 ${res.status}`; return row; }
  if (res.stage === "notfound") { row.status = "查無此病歷號"; return row; }
  if (res.stage === "format") { row.status = "查詢失敗：報告頁格式不符，無法判讀"; return row; }
  if (res.stage !== "ok") { row.status = "查詢失敗：" + (res.detail || "未知錯誤"); return row; }
  const reps = res.rows.filter((x) => cytoSite(x) === site).map((x) => parseReport(x.content));
  row.count = reps.length;
  if (!reps.length) { row.status = `查無${site}細胞學報告`; return row; }
  const r = pickLatest(reps);
  // grade 跟著 fields 走：不符而不輸出報告時也不上色
  const fields = { date: r.date, name: r.name, specimen: r.specimen, diagnosis: r.diagnosis, adequacy: r.adequacy, full: r.full, grade: grade(r.diagnosis) };
  const MISMATCH = "查詢失敗：報告頁的病歷號與查詢不符，請重查（查詢期間請勿另開病歷）";
  // 核對順序：報告內文的病歷號 → 頁面標示的病歷號 → 頁面任何地方出現這個號碼；都沒有就標「未能核對」
  // 不符時 note 寫出看到的號碼與來源，只顯示在外掛畫面，不進 CSV、不存
  const pc = res.pageCharts || [];
  if (r.chartInReport) {
    if (sameChart(r.chartInReport, chartno)) return { ...row, ...fields, status: "有報告" };
    // 少最後一碼：最後一碼若是流水號，前面相同的有 10 個人，所以要頁面上有完整號碼佐證才算相符，否則列出但請抽查
    if (missingLastDigit(r.chartInReport, chartno)) {
      if (pc.some((c) => sameChart(c, chartno)) || res.pageHasChart) return { ...row, ...fields, status: "有報告" };
      // 頁面標示的是別的號碼＝有證據指向別人，判不符，報告不輸出
      if (pc.length) return { ...row, status: MISMATCH, note: `報告內文的病歷號是 ${r.chartInReport}；報告頁面標示的病歷號是 ${[...new Set(pc)].join("、")}` };
      return { ...row, ...fields, status: "有報告（報告內病歷號少最後一碼，未能核對完整號碼，請抽查）", note: `報告內文的病歷號是 ${r.chartInReport}` };
    }
    return { ...row, status: MISMATCH, note: `報告內文的病歷號是 ${r.chartInReport}` };
  }
  if (pc.length) {
    return pc.some((c) => sameChart(c, chartno)) ? { ...row, ...fields, status: "有報告" }
      : { ...row, status: MISMATCH, note: `報告頁面標示的病歷號是 ${[...new Set(pc)].join("、")}` };
  }
  if (res.pageHasChart) return { ...row, ...fields, status: "有報告" };
  return { ...row, ...fields, status: "有報告（未能核對病歷號，請抽查）" };
}

// 一位病人：甲狀腺、淋巴結各取最近一次、各一列；只有淋巴結就不列「查無甲狀腺」，兩者都沒有合成一列
function summarizeRows(chartno, res) {
  if (res.stage !== "ok") return [summarize(chartno, res)];
  const t = summarize(chartno, res, "甲狀腺"), n = summarize(chartno, res, "淋巴結");
  if (!t.count && !n.count) return [{ ...t, site: "", status: "查無甲狀腺或淋巴結細胞學報告" }];
  return [t, n].filter((x) => x.count);
}

const CSV_HEAD = ["病歷號碼", "部位", "狀態", "分級", "該部位筆數", "採檢日", "病人姓名", "檢體", "診斷", "檢體適當性", "報告全文"];
const CSV_KEYS = ["chartno", "site", "status", "grade", "count", "date", "name", "specimen", "diagnosis", "adequacy", "full"];

function csvCell(v) {
  let s = String(v == null ? "" : v);
  if (/^[=+\-@\t\r]/.test(s)) s = "'" + s; // 避免 Excel 當成公式（OWASP CSV injection 清單）
  return '"' + s.replace(/"/g, '""') + '"';
}

// UTF-8 BOM＋CRLF，Excel 直接開中文不亂碼
function toCSV(rows) {
  const lines = [CSV_HEAD.map(csvCell).join(",")];
  for (const r of rows) lines.push(CSV_KEYS.map((k) => csvCell(r[k])).join(","));
  return "﻿" + lines.join("\r\n") + "\r\n";
}

if (typeof module !== "undefined") module.exports = { HOSPS, apiUrl, examUrl, parseChartList, isThyroidCyto, cytoSite, grade, summarizeRows, parseReport, dateKey, pickLatest, sameChart, missingLastDigit, summarize, toCSV, CSV_HEAD };
