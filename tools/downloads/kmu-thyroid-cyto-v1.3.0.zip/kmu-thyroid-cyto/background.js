// 點外掛圖示 → 開（或切到）批次查詢頁；查詢要跑幾分鐘，放在分頁裡才不會因為 popup 關掉而中斷
// 用 runtime.getContexts 找已開的查詢頁，不需要 tabs 權限（安裝時不會跳「讀取瀏覽記錄」警告）
chrome.action.onClicked.addListener(async () => {
  const url = chrome.runtime.getURL("batch.html");
  let ctx = [];
  try { ctx = await chrome.runtime.getContexts({ contextTypes: ["TAB"], documentUrls: [url] }); } catch (e) { /* 舊版 Chrome 沒有 getContexts，就開新的 */ }
  const t = ctx.find((c) => c.tabId >= 0);
  if (t) {
    await chrome.tabs.update(t.tabId, { active: true });
    if (t.windowId >= 0) await chrome.windows.update(t.windowId, { focused: true });
  } else await chrome.tabs.create({ url, active: true });
});
