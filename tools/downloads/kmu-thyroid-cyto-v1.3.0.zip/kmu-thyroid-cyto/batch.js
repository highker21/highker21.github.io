const $ = (id) => document.getElementById(id);
let results = [], stopping = false;

function say(text, cls) { $("msg").textContent = text; $("msg").className = cls || ""; }
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

const CHART_LOAD_MS = 15000, SETTLE_MS = 1500;
const chartTabs = new Set(); // 外掛自己開的病歷分頁，任何情況都要關掉

// 有開著的院內分頁就在分頁裡跑（同源最穩）；某個分頁已登出就換下一個，都不行再由外掛直接跑
async function inHosp(h, func, args) {
  const tabs = await chrome.tabs.query({ url: HOSPS[h].base + "/*" });
  for (const t of tabs) {
    if (chartTabs.has(t.id)) continue;
    try {
      const [res] = await chrome.scripting.executeScript({ target: { tabId: t.id }, args, func });
      if (res && res.result && res.result.stage !== "login") return res.result;
    } catch (e) { /* 分頁可能還在載入，換下一個 */ }
  }
  return func(...args);
}

const origin = (u) => { try { return new URL(u).origin; } catch (e) { return ""; } };
function closeChartTab(id) { chartTabs.delete(id); return chrome.tabs.remove(id).catch(() => {}); }

// 在背景分頁真的打開病歷頁
// 回 { id, fail }：id 是開出來的分頁（呼叫端負責關），fail 是失敗原因
async function openChart(h, url) {
  if (origin(url) !== origin(HOSPS[h].base)) return { id: null, fail: { stage: "error", detail: `病歷網址不在${HOSPS[h].name}院內網域（${origin(url) || "無法解析"}），請回報` } };
  const done = new Set(); let id = null, wake = null;
  const onUpd = (tid, info) => { if (info.status === "complete") { done.add(tid); if (tid === id && wake) wake(true); } };
  chrome.tabs.onUpdated.addListener(onUpd);
  try {
    const tab = await chrome.tabs.create({ url, active: false });
    id = tab.id; chartTabs.add(id);
    const loaded = done.has(id) || await new Promise((res) => { wake = res; setTimeout(() => res(false), CHART_LOAD_MS); });
    if (!loaded) return { id, fail: { stage: "error", detail: `病歷頁 ${CHART_LOAD_MS / 1000} 秒內沒載完` } };
    await sleep(SETTLE_MS);
    // 被導到登入頁（SSO 會換網域，換了網域就讀不到網址）或頁面本身是登入頁 → 當成連線過期
    const t = await chrome.tabs.get(id);
    if (!t.url || origin(t.url) !== origin(url)) return { id, fail: { stage: "login" } };
    const [r] = await chrome.scripting.executeScript({ target: { tabId: id }, func: pageIsLogin });
    if (!r || r.result !== false) return { id, fail: { stage: "login" } };
    return { id, fail: null };
  } catch (e) {
    return { id, fail: { stage: "error", detail: "開不了病歷頁" } };
  } finally { chrome.tabs.onUpdated.removeListener(onUpd); }
}

async function runOne(h, chartno, staff) {
  const u = await inHosp(h, getChartUrl, [apiUrl(h), chartno, staff]);
  if (u.stage !== "url") return u;
  const { id, fail } = await openChart(h, u.url);
  try {
    if (fail) return fail;
    // 病歷頁已跟報告頁同網域（openChart 擋過），就在剛開的病歷分頁裡讀報告，用的是同一份 cookie／session
    const [r] = await chrome.scripting.executeScript({ target: { tabId: id }, args: [examUrl(h), chartno], func: readExam });
    return (r && r.result) || { stage: "error", detail: "讀不到報告頁" };
  } catch (e) {
    return { stage: "error", detail: "讀不到報告頁" };
  } finally { if (id != null) await closeChartTab(id); }
}

// 查詢中關掉這個頁面，也把還開著的病歷分頁收掉
addEventListener("pagehide", () => { for (const id of [...chartTabs]) closeChartTab(id); });

function cell(tr, text, cls) { const td = document.createElement("td"); td.textContent = text; if (cls) td.className = cls; tr.appendChild(td); return td; }

function addRow(i, r) {
  const tr = document.createElement("tr");
  if (r.grade) tr.className = "g-" + r.grade; // atypia／suspicious／malignant 整列底色
  cell(tr, String(i + 1));
  cell(tr, r.chartno);
  cell(tr, r.site || "");
  const st = cell(tr, r.status, r.status.startsWith("查詢失敗") ? "fail" : r.status.startsWith("有報告") ? "" : "none");
  if (r.note) { const d = document.createElement("div"); d.className = "note"; d.textContent = r.note; st.appendChild(d); }
  cell(tr, r.grade || "");
  cell(tr, r.count ? String(r.count) : "");
  for (const k of ["date", "name", "specimen", "diagnosis", "adequacy"]) cell(tr, r[k]);
  const td = cell(tr, "");
  if (r.full) {
    const d = document.createElement("details"), s = document.createElement("summary"), p = document.createElement("pre");
    s.textContent = "展開"; p.textContent = r.full; d.appendChild(s); d.appendChild(p); td.appendChild(d);
  }
  $("tb").appendChild(tr);
}

async function start() {
  const h = $("hosp").value, staff = $("staff").value.trim();
  const { valid, invalid } = parseChartList($("list").value);
  const gap = Math.min(60, Math.max(2, +$("gap").value || 5));
  if (!staff) { say("請先填入職編。", "err"); $("staff").focus(); return; }
  if (!valid.length) { say("沒有可查詢的病歷號碼。", "err"); return; }
  results = []; stopping = false; $("tb").textContent = ""; $("tbl").hidden = false;
  $("start").disabled = true; $("stop").disabled = false; $("csv").disabled = true;
  invalid.forEach((c) => { const r = { chartno: c, status: "格式不符，未查詢", count: 0 }; results.push(r); addRow(results.length - 1, r); });
  let fails = 0;
  for (let i = 0; i < valid.length; i++) {
    if (stopping) break;
    say(`查詢中（${HOSPS[h].name}）：第 ${i + 1} / ${valid.length} 位…`);
    const rs = summarizeRows(valid[i], await runOne(h, valid[i], staff)), r = rs[0];
    for (const x of rs) { results.push(x); addRow(results.length - 1, x); }
    if (rs.some((x) => x.status.startsWith("查詢失敗"))) fails++;
    // 連線過期就停：後面每一位都會失敗，不要一直打院內系統
    if (/連線過期|連不到/.test(r.status)) {
      for (const c of valid.slice(i + 1)) { const x = { chartno: c, status: "未查詢（前一位連線失敗已停止）", count: 0 }; results.push(x); addRow(results.length - 1, x); }
      say(`第 ${i + 1} 位連線失敗，已停止。請先在 Chrome 打開${HOSPS[h].name}院內系統確認可用，再按「開始查詢」重查。`, "err");
      break;
    }
    if (i < valid.length - 1) await sleep((gap + Math.random() * 3) * 1000); // 原程式每位隔 5–10 秒
  }
  if (!/已停止/.test($("msg").textContent)) {
    // 一位病人可能有甲狀腺、淋巴結兩列，以病歷號計人數
    const people = (f) => new Set(results.filter(f).map((r) => r.chartno)).size;
    const got = people((r) => r.status.startsWith("有報告")), unv = people((r) => r.status.includes("未能核對"));
    say(`${stopping ? "已手動停止" : "查詢結束"}：有報告 ${got} 位${unv ? `（其中 ${unv} 位未能核對病歷號，請抽查）` : ""}，查詢失敗 ${fails} 位，共 ${results.length} 列。`, fails ? "err" : "ok");
  }
  $("start").disabled = false; $("stop").disabled = true; $("csv").disabled = !results.length;
}

function download() {
  const d = new Date(), ymd = d.getFullYear() + String(d.getMonth() + 1).padStart(2, "0") + String(d.getDate()).padStart(2, "0");
  const a = document.createElement("a");
  a.href = URL.createObjectURL(new Blob([toCSV(results)], { type: "text/csv;charset=utf-8" }));
  a.download = `甲狀腺細胞學_${HOSPS[$("hosp").value].name}_${ymd}.csv`;
  document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(a.href), 5000);
}

(async function init() {
  for (const [k, v] of Object.entries(HOSPS)) {
    const o = document.createElement("option"); o.value = k; o.textContent = v.name; $("hosp").appendChild(o);
  }
  const s = await chrome.storage.local.get(["hosp", "staff"]); // 只記院區與職編，病歷號與結果都不存
  if (s.hosp && HOSPS[s.hosp]) $("hosp").value = s.hosp;
  if (s.staff) $("staff").value = s.staff;
  $("hosp").addEventListener("change", () => chrome.storage.local.set({ hosp: $("hosp").value }));
  $("staff").addEventListener("change", () => chrome.storage.local.set({ staff: $("staff").value.trim() }));
  $("start").addEventListener("click", start);
  $("stop").addEventListener("click", () => { stopping = true; $("stop").disabled = true; say("會在目前這位查完後停止…"); });
  $("csv").addEventListener("click", download);
})();
