// 高醫單一入口登入頁：找到驗證碼圖（img#kmuh-captcha-img）才動作；只填驗證碼欄，帳號密碼不讀值、不存
let collecting = false;

// 收集樣本（v1.0.2，老闆 msg 377 實測常認錯）：popup 按鈕觸發，點圖換 n 張，只存驗證碼圖本身，下載成 JSON 檔讓老闆傳回來做專用辨識
chrome.runtime.onMessage.addListener((msg, sender, reply) => {
  if (!msg || msg.type !== "collect") return;
  const img = document.getElementById("kmuh-captcha-img");
  if (!img) { reply({ ok: false, why: "這一頁沒有驗證碼圖，請先打開單一入口登入頁" }); return; }
  if (collecting) { reply({ ok: false, why: "正在收集中" }); return; }
  reply({ ok: true });
  collectSamples(Math.min(Math.max(+msg.n || 40, 1), 60));
});
async function collectSamples(n) {
  collecting = true;
  const seen = new Set(), out = [];
  const say = (t) => { let b = document.getElementById("kmuh-captcha-fill-banner"); if (!b) { b = document.createElement("div"); b.id = "kmuh-captcha-fill-banner"; b.style.cssText = "position:fixed;left:50%;top:12px;transform:translateX(-50%);z-index:2147483647;padding:8px 14px;border-radius:6px;font:14px/1.5 sans-serif;box-shadow:0 2px 8px rgba(0,0,0,.25);max-width:90vw;background:#e6f2ee;color:#1f6f5c"; document.body.appendChild(b); } b.textContent = "驗證碼外掛：" + t; };
  try {
    for (let tries = 0; out.length < n && tries < n * 2; tries++) {
      const img = document.getElementById("kmuh-captcha-img");
      if (!img) break;
      if (!img.complete || !img.naturalWidth) await new Promise((r) => { img.onload = r; img.onerror = r; setTimeout(r, 2000); });
      let src = img.src;
      if (!/^data:image\//.test(src)) { try { const c = document.createElement("canvas"); c.width = img.naturalWidth; c.height = img.naturalHeight; c.getContext("2d").drawImage(img, 0, 0); src = c.toDataURL("image/png"); } catch (e) { src = ""; } }
      if (src && !seen.has(src)) { seen.add(src); out.push(src); }
      say(`收集驗證碼樣本中：${out.length} / ${n}（請不要操作這一頁）`);
      const before = img.src;
      img.click();
      for (let k = 0; k < 30 && document.getElementById("kmuh-captcha-img") && document.getElementById("kmuh-captcha-img").src === before; k++) await new Promise((r) => setTimeout(r, 100));
      await new Promise((r) => setTimeout(r, 200));
    }
    if (!out.length) { say("一張都沒收到（讀不到驗證碼圖），沒有下載。請把這個情況告訴助理。"); return; } // B 低2
    const d = new Date(), p2 = (x) => String(x).padStart(2, "0");
    const name = `kmuh-captcha-samples_${d.getFullYear()}${p2(d.getMonth() + 1)}${p2(d.getDate())}_${p2(d.getHours())}${p2(d.getMinutes())}.json`;
    const blob = new Blob([JSON.stringify({ kind: "kmuh-captcha-samples", version: 1, host: location.host, count: out.length, images: out })], { type: "application/json" });
    const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = name; document.body.appendChild(a); a.click();
    setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 5000);
    say(`已收集 ${out.length} 張，下載成 ${name}（只有驗證碼圖），請把這個檔案傳給助理。`);
  } finally { collecting = false; }
}

(async () => {
  const img0 = await waitFor(() => document.getElementById("kmuh-captcha-img"), 5000);
  if (!img0) return;
  const input = findInput();
  if (!input) return;
  const cfg = await chrome.storage.local.get({ enabled: true, autoSubmit: true });
  if (!cfg.enabled) return;
  if (input.value) return; // 使用者已經在輸入

  const KEY = "kmuhCaptchaFill";
  const load = () => { try { return JSON.parse(sessionStorage.getItem(KEY) || "null"); } catch (e) { return null; } };
  const save = (v) => { try { sessionStorage.setItem(KEY, JSON.stringify(v)); } catch (e) { /* 存不了就不自動送出 */ } };

  banner("辨識驗證碼中…");
  let code = "";
  for (let i = 0; i < MAX_READS && !code; i++) {
    if (input.value || collecting) return; // 辨識中使用者自己打了、或在收集樣本，就停
    const img = document.getElementById("kmuh-captcha-img");
    const before = img.src;
    try { code = cleanCode((await readCaptcha(img)).code); } catch (e) { code = ""; }
    if (!code && i < MAX_READS - 1) { img.click(); await waitFor(() => document.getElementById("kmuh-captcha-img").src !== before || null, 3000); await sleep(300); }
  }
  if (collecting) return;
  if (!code) { banner("驗證碼辨識不出來，請手動輸入。", true); input.focus(); return; }
  if (input.value) return;
  setValue(input, code);

  const btn = findSubmit(input);
  const saved = load(), now = Date.now();
  if (!cfg.autoSubmit || !btn) { banner(`驗證碼已填入 ${code}，請按「登入」。`); (btn || input).focus(); return; }
  if (!canAutoSubmit(saved, now)) { banner(`已自動試 ${MAX_SUBMITS} 次沒成功，這次只填入 ${code}，請確認後自己按「登入」（若驗證碼不對，點圖換一張再手動輸入）。`, true); input.focus(); return; }
  // Chrome 自動填入的密碼在使用者點擊／按鍵前，程式讀到的是空值，送出也可能是空的（B 審查：會累計密碼錯誤）；
  // 所以只有讀得到值才自動送出，否則把焦點放在「登入」鈕，按一下 Enter 就好
  if (!credsReadable(input)) {
    if (looksAutofilled(input)) { banner(`驗證碼已填入 ${code}，請按 Enter（或點「登入」）。`); btn.focus(); }
    else banner(`驗證碼已填入 ${code}。帳號或密碼還沒填，請填好後按「登入」。`);
    return;
  }
  if (collecting) return;
  save(bump(saved, now));
  banner(`驗證碼已填入 ${code}，自動登入中…`);
  await sleep(400);
  if (collecting) return; // B 低1：等待中按了收集就不送
  btn.click();

  // ---- 小工具
  function sleep(ms) { return new Promise((r) => setTimeout(r, ms)); }
  function waitFor(fn, ms) {
    return new Promise((res) => {
      const v = fn(); if (v) return res(v);
      const ob = new MutationObserver(() => { const x = fn(); if (x) { ob.disconnect(); clearTimeout(t); res(x); } });
      ob.observe(document.documentElement, { childList: true, subtree: true, attributes: true });
      const t = setTimeout(() => { ob.disconnect(); res(fn() || null); }, ms);
    });
  }
  function findInput() {
    return document.querySelector('input[name="kmuh-captcha"]') || document.getElementById("kmuh-captcha")
      || document.querySelector('input[name*="captcha" i]:not([type=hidden]), input[id*="captcha" i]:not([type=hidden])');
  }
  function findSubmit(el) {
    const scope = el.form || document;
    const cands = [...scope.querySelectorAll('button, input[type=submit], input[type=button], a.btn')];
    return cands.find((b) => /登入|login|sign\s*in/i.test(b.textContent || b.value || "")) || scope.querySelector('button[type=submit], input[type=submit]') || null;
  }
  // 密碼欄是 Chrome 自動填入（值被保護、讀到空字串）→ 只用來挑提示文字，不據此送出
  function looksAutofilled(el) {
    const pw = (el.form || document).querySelector('input[type=password]');
    const m = (sel) => { try { return !!pw && pw.matches(sel); } catch (e) { return false; } };
    return m(":autofill") || m(":-webkit-autofill");
  }
  // 帳號、密碼欄讀得到值才算已填（不讀出值本身，只看是否為空）
  function credsReadable(el) {
    const scope = el.form || document;
    const pw = scope.querySelector('input[type=password]');
    const user = scope.querySelector('input[name="username"], input[type=text]:not([name*="captcha" i]), input[type=email]');
    return !!pw && pw.value !== "" && (!user || user.value !== "");
  }
  function setValue(el, v) {
    const set = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value").set;
    set.call(el, v);
    el.dispatchEvent(new Event("input", { bubbles: true }));
    el.dispatchEvent(new Event("change", { bubbles: true }));
  }
  // v1.1.0：院內驗證碼專用辨識（recog.js＋templates.js），在頁面裡直接算，不再用 tesseract
  async function readCaptcha(img) {
    if (!img.complete || !img.naturalWidth) await new Promise((r) => { img.onload = r; img.onerror = r; setTimeout(r, 2000); });
    const w = img.naturalWidth, h = img.naturalHeight;
    if (!w || !h || w > 400 || h > 200) return { code: "" };
    const c = document.createElement("canvas"); c.width = w; c.height = h;
    const g = c.getContext("2d", { willReadFrequently: true });
    g.drawImage(img, 0, 0);
    return KMU_RECOG.recognize(g.getImageData(0, 0, w, h).data, w, h);
  }
  function banner(text, warn) {
    let b = document.getElementById("kmuh-captcha-fill-banner");
    if (!b) {
      b = document.createElement("div"); b.id = "kmuh-captcha-fill-banner";
      b.style.cssText = "position:fixed;left:50%;top:12px;transform:translateX(-50%);z-index:2147483647;padding:8px 14px;border-radius:6px;font:14px/1.5 sans-serif;box-shadow:0 2px 8px rgba(0,0,0,.25);max-width:90vw";
      document.body.appendChild(b);
    }
    b.style.background = warn ? "#fff4bf" : "#e6f2ee"; b.style.color = warn ? "#8a5a00" : "#1f6f5c";
    b.textContent = "驗證碼外掛：" + text;
  }
})();
