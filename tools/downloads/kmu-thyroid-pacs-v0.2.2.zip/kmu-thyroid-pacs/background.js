// PACS 截圖：背景程式。
//   1. 傳話：截圖小視窗 ⇄ 檢查頁裡的隱藏框架（優先）或使用者自己登入的同院區 WebPACS 分頁（退路）。
//      取圖的請求都是 WebPACS 那一邊的 pacs.js 自己發的，背景程式不碰通行碼。
//   2. 開小視窗（整個瀏覽器只開一個，換病人就換內容）。
//   3. 存檔：只收 data:image、檔名只收 PACS/<種類>_YYYYMMDD_NN[_crop].jpg|png（不含病歷號），寫進「下載」。
importScripts('core.js');
const C = globalThis.ThyPacsCore;

const jobKey = (id) => 'job:' + id;
async function getJob(id) {
  if (!/^[\w-]{8,64}$/.test(String(id || ''))) return null;
  return (await chrome.storage.session.get(jobKey(id)))[jobKey(id)] || null;
}
async function setJob(id, job) { await chrome.storage.session.set({ [jobKey(id)]: job }); }

async function viewerWindow() {
  const w = (await chrome.storage.session.get('viewerWin')).viewerWin;
  if (!w) return null;
  try { const tab = await chrome.tabs.get(w.tabId); return tab.windowId === w.windowId ? w : null; } catch (e) { return null; }
}

async function openViewer(job, sender) {
  if (!sender.tab) return { ok: false, error: 'no-tab' };
  let host = '';
  try { host = new URL(sender.url || sender.tab.url || '').hostname; } catch (e) { /* 空 */ }
  const site = C.siteByHost(host);
  if (!site || site.id !== job.site || site.intra !== host) return { ok: false, error: '院區不對' };
  if (!C.validChart(job.chart)) return { ok: false, error: '病歷號不對' };
  const clean = {
    site: site.id, chart: String(job.chart), tabId: sender.tab.id, frameUrl: sender.url || '',
    accession: /^[A-Za-z0-9]{6,24}$/.test(String(job.accession || '')) ? String(job.accession) : '',
    date: /^\d{8}$/.test(String(job.date || '')) ? String(job.date) : '',
    kind: String(job.kind || '').slice(0, 40), connectErr: String(job.connectErr || '').slice(0, 40), source: null,
  };
  const id = crypto.randomUUID();
  await setJob(id, clean);
  const url = chrome.runtime.getURL('viewer.html') + '#' + id;
  const win = await viewerWindow();
  if (win) {
    await chrome.tabs.update(win.tabId, { url });
    if (win.jobId) await chrome.storage.session.remove(jobKey(win.jobId));
    await chrome.storage.session.set({ viewerWin: Object.assign({}, win, { jobId: id }) });
    await chrome.windows.update(win.windowId, { focused: true }).catch(() => {});
  } else {
    const b = (await chrome.storage.local.get('viewerBounds')).viewerBounds || { width: 1100, height: 900 };
    const w = await chrome.windows.create(Object.assign({ url, type: 'popup', focused: true }, b));
    await chrome.storage.session.set({ viewerWin: { windowId: w.id, tabId: w.tabs[0].id, jobId: id } });
  }
  return { ok: true };
}
// 小視窗關掉：清掉那筆工作（內含病歷號），不留到瀏覽器關閉
chrome.windows.onRemoved.addListener(async (windowId) => {
  const w = (await chrome.storage.session.get('viewerWin')).viewerWin;
  if (!w || w.windowId !== windowId) return;
  if (w.jobId) await chrome.storage.session.remove(jobKey(w.jobId));
  await chrome.storage.session.remove('viewerWin');
});
chrome.windows.onBoundsChanged.addListener(async (w) => {
  const v = await viewerWindow();
  if (v && v.windowId === w.id && w.state === 'normal') chrome.storage.local.set({ viewerBounds: { left: w.left, top: w.top, width: w.width, height: w.height } });
});

// 檢查頁那個分頁還在嗎（外掛沒有院內網站的權限，讀不到分頁網址；換頁或換病人時隱藏框架會跟著消失，
// 所以「問得到隱藏框架」本身就代表還是原本那一頁）
async function examTabOk(job) {
  try { await chrome.tabs.get(job.tabId); return true; } catch (e) { return false; }
}
const ask = async (tabId, msg) => { try { return await chrome.tabs.sendMessage(tabId, msg); } catch (e) { return null; } };

// 找這次檢查：先問檢查頁裡的隱藏框架；沒接上就問使用者自己開的同院區 WebPACS 分頁
async function findStudy(id) {
  const job = await getJob(id);
  if (!job) return { ok: false, reason: 'tab-gone' };
  const site = C.siteById(job.site);
  const want = { type: 'thy-pacs-study', chart: job.chart, accession: job.accession, date: job.date, mods: C.modalitiesFor(job.kind) || [] };
  let last = { ok: false, reason: job.connectErr || 'no-session' };
  if (await examTabOk(job)) {
    const r = await ask(job.tabId, Object.assign({ via: 'hidden' }, want));
    if (r && r.ok) { job.source = { tabId: job.tabId, via: 'hidden' }; await setJob(id, job); return Object.assign(r, { site: site.name, via: 'hidden' }); }
    if (r && r.reason !== 'no-session') last = r;
  } else if (!job.connectErr) last = { ok: false, reason: 'tab-gone' };
  for (const tab of await chrome.tabs.query({ url: 'https://' + site.pacs + '/*' })) {
    const r = await ask(tab.id, Object.assign({ via: 'user' }, want));
    if (r && r.ok) { job.source = { tabId: tab.id, via: 'user' }; await setJob(id, job); return Object.assign(r, { site: site.name, via: 'user' }); }
    if (r && r.reason !== 'no-session') last = r;
  }
  return Object.assign(last, { site: site.name });
}

async function getImage(id, uid, size) {
  const job = await getJob(id);
  if (!job || !job.source) return { ok: false, reason: 'no-session' };
  const r = await ask(job.source.tabId, { type: 'thy-pacs-image', via: job.source.via, uid: String(uid || ''), size: size === 'thumb' ? 'thumb' : 'full' });
  return r || { ok: false, reason: job.source.via === 'hidden' ? 'tab-gone' : 'no-session' };
}

const waitDone = (dlId) => new Promise((resolve) => {
  const t0 = Date.now();
  const tick = async () => {
    const [it] = await chrome.downloads.search({ id: dlId });
    // 存好後把這筆從下載紀錄拿掉（檔案留著）：紀錄裡的來源網址就是整張影像的 data: 內容
    if (it && it.state === 'complete') { await chrome.downloads.erase({ id: dlId }).catch(() => {}); return resolve({ ok: true, path: it.filename }); }
    if (it && it.state === 'interrupted') return resolve({ ok: false, error: it.error || 'interrupted' });
    if (Date.now() - t0 > 60000) return resolve({ ok: false, error: '等待存檔逾時' });
    setTimeout(tick, 150);
  };
  tick();
});
async function save(dataUrl, filename) {
  if (!/^data:image\/(jpeg|png);base64,/.test(String(dataUrl || ''))) return { ok: false, error: '不是影像' };
  if (!/^PACS\/(IMG|[A-Z]{2,4})_(\d{8}|nodate)_\d{2,3}(_crop)?\.(jpg|png)$/.test(String(filename || ''))) return { ok: false, error: '檔名不對' };
  const dlId = await chrome.downloads.download({ url: dataUrl, filename, conflictAction: 'uniquify', saveAs: false });
  return waitDone(dlId);
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || typeof msg.type !== 'string') return;
  let job;
  const fromViewer = sender.url && sender.url.startsWith(chrome.runtime.getURL('viewer.html'));
  if (msg.type === 'thy-ping' && sender.tab) job = ask(sender.tab.id, { type: 'thy-pacs-ping' }).then((r) => r || { ok: false });
  else if (msg.type === 'thy-open-viewer' && sender.tab) job = openViewer(msg.job || {}, sender);
  else if (msg.type === 'thy-job' && fromViewer) job = getJob(msg.id).then((j) => (j ? { ok: true, job: { site: C.siteById(j.site).name, chart: j.chart, date: j.date, kind: j.kind, accession: j.accession } } : { ok: false }));
  else if (msg.type === 'thy-study' && fromViewer) job = findStudy(msg.id);
  else if (msg.type === 'thy-image' && fromViewer) job = getImage(msg.id, msg.uid, msg.size);
  else if (msg.type === 'thy-save' && fromViewer) job = save(msg.dataUrl, msg.filename);
  else return;
  job.then(sendResponse, (e) => sendResponse({ ok: false, reason: 'error', error: String((e && e.message) || e) }));
  return true;
});
