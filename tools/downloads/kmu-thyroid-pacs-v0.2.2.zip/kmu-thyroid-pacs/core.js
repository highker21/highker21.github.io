/* PACS 截圖：純函式。頁面腳本、背景程式與 Node 測試共用，不碰 DOM、不碰 chrome.*。 */
(function (root) {
  'use strict';

  const SITES = [
    { id: 'kmuh', name: '附院', intra: 'intraweb.server.kmuh.org.tw', pacs: 'webpacs.kmuh.org.tw' },
    { id: 'kmugh', name: '岡山', intra: 'intraweb.kmugh.org.tw', pacs: 'webpacs.kmugh.org.tw' },
  ];
  function siteByHost(host) {
    const h = String(host || '').toLowerCase();
    return SITES.find((s) => s.intra === h || s.pacs === h) || null;
  }
  const siteById = (id) => SITES.find((s) => s.id === id) || null;

  /** 病歷號比對用：只留數字、去掉開頭的 0。 */
  function chartKey(v) {
    return String(v == null ? '' : v).replace(/\D/g, '').replace(/^0+/, '');
  }
  /** 檢查頁上的病歷號（輸入框的值）是不是合理的病歷號：4–12 位數字（可有前導 0）。 */
  function validChart(v) {
    return /^\d{4,12}$/.test(String(v == null ? '' : v).trim()) && chartKey(v) !== '';
  }

  /** 檢查頁「開啟」按鈕的 onclick → WebPACS 開圖連結。
   *  只收：https、這個院區的 WebPACS 主機、/DicomWeb/DicomWeb.dll/OpenImage、剛好 SN／E／E1 三個參數而且長相對；其餘回 ''。 */
  function pacsOpenLink(onclick, pacsHost) {
    const want = String(pacsHost || '').toLowerCase();
    for (const m of String(onclick || '').matchAll(/https:\/\/[^'"\s)<>]+/g)) {
      let u;
      try { u = new URL(m[0].replace(/&amp;/g, '&')); } catch (e) { continue; }
      if (u.protocol !== 'https:' || u.hostname.toLowerCase() !== want || u.port || u.username || u.password) continue;
      if (u.pathname !== '/DicomWeb/DicomWeb.dll/OpenImage') continue;
      const q = u.searchParams;
      if ([...q.keys()].sort().join() !== 'E,E1,SN') continue;
      if (!/^-?\d{1,12}$/.test(q.get('SN')) || !/^[0-9a-f]{16,64}$/i.test(q.get('E')) || !/^[0-9a-f]{32,512}$/i.test(q.get('E1'))) continue;
      return u.href;
    }
    return '';
  }

  /** 檢查列 data-exentric（報告 PDF 連結）→ { accession, chart }；讀不到的欄位留 ''。 */
  function exentricInfo(href) {
    const out = { accession: '', chart: '' };
    let u;
    let h = String(href || '');
    for (let i = 0; i < 3 && /&amp;/.test(h); i++) h = h.replace(/&amp;/g, '&'); // 頁面原始碼是 &amp;amp;，讀出來還剩一層
    try { u = new URL(h); } catch (e) { return out; }
    if (u.protocol !== 'https:') return out;
    const acc = u.searchParams.get('accessno') || '';
    const pat = u.searchParams.get('patno_no') || '';
    if (/^[A-Za-z0-9]{6,24}$/.test(acc)) out.accession = acc;
    if (/^\d{4,12}$/.test(pat)) out.chart = pat;
    return out;
  }

  /** 報告類別 → 可接受的 PACS 檢查種類（modality）。只在「沒有檢查單號、要靠日期配對」時用：
   *  認得出類別才配，而且只配那幾種；認不出回 null（不配，寧可不列也不配錯檢查）。 */
  // 順序有意義：先比對「不會被誤吃」的專有詞，再比對寬的詞。
  //  - 裸的「甲狀腺／thyroid」不算超音波（甲狀腺掃描、攝取率是核醫）；甲狀腺超音波由「超音波」抓到。
  //  - 「掃描／scan」放在 CT、MR、骨密、超音波之後，免得「電腦斷層掃描」「骨質密度掃描」被當成核醫。
  const MOD_RULES = [
    [/正子|\bPET\b/i, ['PT', 'CT', 'NM']],
    [/骨質密度|\bBMD\b|DXA|DEXA/i, ['OT', 'BMD', 'DX']],
    [/電腦斷層|\bCTA?\b/i, ['CT']],
    [/磁振|\bMR(I|A|CP)?\b/i, ['MR']],
    [/乳房攝影|mammo/i, ['MG']],
    [/超音波|sono|echo|doppler|都卜勒|duplex/i, ['US']],
    [/\bUS\b/, ['US']],
    [/核醫|掃描|\bscan\b|uptake|攝取|MIBI|Tc-?99|\bSPECT\b/i, ['NM', 'PT']],
    [/一般攝影|X光|X-?ray|胸部攝影|\bKUB\b|\bCXR\b/i, ['CR', 'DX']],
  ];
  function modalitiesFor(t) {
    const s = String(t || '');
    for (const [re, mods] of MOD_RULES) if (re.test(s)) return mods.slice();
    return null;
  }
  const isUsType = (t) => { const m = modalitiesFor(t); return !!(m && m.length === 1 && m[0] === 'US'); };

  /** 檢查頁日期文字（'2026/11/12 11:30'、'115/11/12'、'2026-11-12'）→ 'YYYYMMDD'；讀不懂回 ''。 */
  function ymd(text) {
    const m = /(\d{2,4})[/-](\d{1,2})[/-](\d{1,2})/.exec(String(text || ''));
    if (!m) return '';
    let y = +m[1];
    if (y < 1000) y += 1911; // 民國
    const mo = +m[2], d = +m[3];
    const dt = new Date(y, mo - 1, d);
    if (isNaN(dt) || dt.getMonth() !== mo - 1 || dt.getDate() !== d) return '';
    return String(y) + String(mo).padStart(2, '0') + String(d).padStart(2, '0');
  }

  /** 存檔檔名（不含病歷號、姓名）：PACS/<檢查種類>_YYYYMMDD_NN[_crop].ext；種類只收 2–4 個大寫英文字母，否則 IMG。 */
  function fileName(dateYmd, index, crop, ext, modality) {
    const m = /^[A-Z]{2,4}$/.test(String(modality || '').trim().toUpperCase()) ? String(modality).trim().toUpperCase() : 'IMG';
    const d = /^\d{8}$/.test(String(dateYmd)) ? dateYmd : 'nodate';
    const n = String(Math.max(1, Math.min(999, Math.floor(+index) || 1))).padStart(2, '0');
    const e = ext === 'png' ? 'png' : 'jpg';
    return 'PACS/' + m + '_' + d + '_' + n + (crop ? '_crop' : '') + '.' + e;
  }

  /** 兩個拖曳點（畫面座標，已換算成影像像素）→ 影像內的裁切框 {x,y,w,h}；太小（<8 px）回 null。 */
  function cropRect(a, b, imgW, imgH) {
    const clamp = (v, max) => Math.max(0, Math.min(max, Math.round(v)));
    const x1 = clamp(Math.min(a.x, b.x), imgW), x2 = clamp(Math.max(a.x, b.x), imgW);
    const y1 = clamp(Math.min(a.y, b.y), imgH), y2 = clamp(Math.max(a.y, b.y), imgH);
    if (x2 - x1 < 8 || y2 - y1 < 8) return null;
    return { x: x1, y: y1, w: x2 - x1, h: y2 - y1 };
  }

  /** 從 PACS 回的檢查清單挑出這一筆：
   *  rows：[{accession, patientId, date, modality}]；want：{accession, chart, date, mods}。
   *  規則（寧可不列，也不列到別人的）：
   *   1. 每一筆的病歷號都要讀得到；讀不到 → 'no-patient-column'。
   *   2. 只留病歷號相同的；一筆都沒有 → 'patient-mismatch'。
   *   3. 有檢查單號：只收單號完全相同的那一筆（剛好一筆）。
   *   4. 沒有檢查單號：要認得出檢查種類（mods），同一天、這幾種裡剛好一筆才收；認不出 → 'no-accession'。
   *  回 { ok, row } 或 { ok:false, reason }。 */
  function pickStudy(rows, want) {
    const list = Array.isArray(rows) ? rows : [];
    if (!list.length) return { ok: false, reason: 'not-found' };
    if (list.some((r) => !chartKey(r.patientId))) return { ok: false, reason: 'no-patient-column' };
    const same = list.filter((r) => chartKey(r.patientId) === chartKey(want.chart));
    if (!same.length) return { ok: false, reason: 'patient-mismatch' };
    if (want.accession) {
      const hit = same.filter((r) => String(r.accession || '') === String(want.accession));
      return hit.length === 1 ? { ok: true, row: hit[0] } : { ok: false, reason: hit.length ? 'ambiguous' : 'not-found' };
    }
    const day = same.filter((r) => ymd(r.date) === want.date || String(r.date || '').replace(/\D/g, '') === want.date);
    const mods = Array.isArray(want.mods) ? want.mods.map((m) => String(m).toUpperCase()) : [];
    if (!mods.length) return { ok: false, reason: 'no-accession' };
    const c = day.filter((r) => mods.includes(String(r.modality || '').trim().toUpperCase()));
    return c.length === 1 ? { ok: true, row: c[0] } : { ok: false, reason: c.length ? 'ambiguous' : 'not-found' };
  }

  const REASONS = {
    'no-site': '這一頁不是附院或岡山的院內系統。',
    'bad-chart': '檢查頁上讀不到這位病人的病歷號，為了不看錯人，不開影像。',
    'no-link': '這一列沒有可用的「開啟PACS」連結。',
    'no-session': 'WebPACS 沒有接上（連結可能已用過或過期）。請重新整理檢查頁再按一次；或先自己開一個 WebPACS 分頁登入。',
    'unsupported': '這個瀏覽器不支援獨立讀取框（請更新 Chrome），請先自己開一個 WebPACS 分頁登入。',
    'blocked': 'WebPACS 沒有在背景載入（院方可能不允許），請先自己開一個 WebPACS 分頁登入後再按。',
    'auth-failed': 'WebPACS 不接受這條連結（可能已用過）。請重新整理檢查頁再按一次。',
    'not-found': 'PACS 找不到這次檢查的影像。',
    'ambiguous': 'PACS 同一天有不只一筆同種檢查，這一列又沒有檢查單號，為了不看錯，不自動選。請用 WebPACS 自己開。',
    'no-accession': '這一列沒有檢查單號，也認不出是哪一種檢查，為了不配到同一天的別的檢查，不自動找。請用 WebPACS 自己開。',
    'patient-mismatch': 'PACS 的病歷號和檢查頁對不上，為了不看錯人，不顯示。',
    'no-patient-column': 'PACS 的檢查清單讀不到病歷號，無法核對，不顯示。',
    'tab-gone': '原本的檢查頁已經關掉或換頁，請回檢查頁重按「🩻 截圖」。',
    'error': '發生錯誤。',
  };
  const reasonText = (r, detail) => (REASONS[r] || REASONS.error) + (detail ? '（' + detail + '）' : '');

  const api = { SITES, siteByHost, siteById, chartKey, validChart, pacsOpenLink, exentricInfo, isUsType, modalitiesFor, ymd, fileName, cropRect, pickStudy, reasonText };
  root.ThyPacsCore = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(typeof globalThis !== 'undefined' ? globalThis : this);
