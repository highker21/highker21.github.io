/* PACS 截圖：體系病歷「檢查」頁（/WEB/MRN/ExamReport）。
 * 每一列有「開啟PACS」（WebPACS）按鈕的檢查，旁邊加「🩻 截圖」（老闆 msg894：不限甲狀腺）。按下去：
 *   1. 核對病歷號：頁面上的目前病歷號（#CurrentChartno）要合理；那一列報告連結上的病歷號（有的話）要相同。
 *   2. 還沒接上 WebPACS 時，用「這一列」的開圖連結（一次性）在隱藏框架接上：框架是 credentialless
 *      （自己一套 cookie）＋sandbox，不動使用者自己的病歷分頁與 WebPACS 分頁，不能開視窗或把這一頁導走。
 *   3. 開截圖小視窗（外掛頁），之後的查詢都由隱藏框架裡的 pacs.js 回答。
 * 只讀頁面，不改院內資料；連結與通行碼只在記憶體。 */
(function () {
  'use strict';
  const C = globalThis.ThyPacsCore;
  if (!C) return;
  if (!/^\/web\/mrn\/examreport\/?$/i.test(location.pathname)) return;
  // 門診工作台等外掛的背景讀取框（credentialless）裡不加按鈕
  try { if (window.credentialless === true) return; } catch (e) { return; }
  const site = C.siteByHost(location.hostname);
  if (!site) return;

  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const refuse = (reason, detail) => Object.assign(new Error(detail || reason), { reason });
  const send = async (msg) => { try { return await chrome.runtime.sendMessage(msg); } catch (e) { return null; } };

  // ---------- 小提示（不用 alert，免得卡住頁面） ----------
  let toastEl = null, toastTimer = 0;
  function toast(msg, ms) {
    if (!toastEl) {
      toastEl = document.createElement('div');
      toastEl.id = 'thy-pacs-toast';
      toastEl.style.cssText = 'position:fixed;right:16px;bottom:16px;z-index:2147483000;max-width:420px;padding:10px 14px;border-radius:8px;background:#1d2b3a;color:#fff;font:14px/1.5 "Microsoft JhengHei",sans-serif;box-shadow:0 4px 16px rgba(0,0,0,.3)';
      (document.body || document.documentElement).appendChild(toastEl);
    }
    toastEl.textContent = msg;
    toastEl.style.display = 'block';
    clearTimeout(toastTimer);
    if (ms) toastTimer = setTimeout(() => { toastEl.style.display = 'none'; }, ms);
  }

  // ---------- 表格欄位 ----------
  function columns(table) {
    const out = {};
    const ths = table.querySelectorAll('thead th');
    ths.forEach((th, i) => {
      const t = th.textContent.replace(/\s+/g, '');
      if (t === '預定檢查日期') out.date = i;
      else if (t === '報告類別') out.type = i;
      else if (t === '開啟PACS') out.pacs = i;
    });
    return out;
  }
  function rowInfo(tr, col) {
    const cell = (i) => (i != null ? tr.cells[i] : null);
    const typeCell = cell(col.type);
    const type = typeCell ? (typeCell.getAttribute('title') || typeCell.textContent).trim() : '';
    // 附院每列有兩顆：先是舊看片程式（pacsURLA、http://web.pacs…），再是 WebPACS（openNewWindow、https）。
    // 逐顆看，用第一顆解析得出「這個院區 WebPACS 開圖連結」的。
    const cands = [...tr.querySelectorAll('.pacs-btn[onclick]')];
    if (cell(col.pacs)) for (const b of cell(col.pacs).querySelectorAll('[onclick]')) if (!cands.includes(b)) cands.push(b);
    let btn = null, link = '';
    for (const b of cands) { const l = C.pacsOpenLink(b.getAttribute('onclick'), site.pacs); if (l) { btn = b; link = l; break; } }
    const date = C.ymd(cell(col.date) ? cell(col.date).textContent : '');
    const ex = C.exentricInfo(tr.getAttribute('data-exentric') || '');
    return { type, link, date, accession: ex.accession, exChart: ex.chart, btn, hasBtn: cands.length > 0 };
  }

  // ---------- 接上 WebPACS（隱藏框架） ----------
  let pacsFrame = null, connecting = null;
  const used = new Set(); // 用過的一次性連結
  const isolated = (f) => { try { return f.credentialless === true && f.contentWindow.credentialless === true; } catch (e) { return false; } };
  async function ping() { const r = await send({ type: 'thy-ping' }); return r && r.ok ? r : null; }
  async function connected() { if (!pacsFrame || !pacsFrame.isConnected) return false; const r = await ping(); return !!(r && r.key); }
  async function connect(link) {
    if (await connected()) return;
    if (!('credentialless' in HTMLIFrameElement.prototype)) throw refuse('unsupported');
    if (used.has(link)) throw refuse('auth-failed');
    if (pacsFrame) { pacsFrame.remove(); pacsFrame = null; }
    const f = document.createElement('iframe');
    f.credentialless = true; // 放進頁面之前設
    f.name = 'thy-pacs';
    f.setAttribute('sandbox', 'allow-scripts allow-same-origin allow-forms');
    f.setAttribute('aria-hidden', 'true');
    f.tabIndex = -1;
    f.style.cssText = 'position:fixed;left:-12000px;top:0;width:1100px;height:800px;border:0;visibility:hidden;pointer-events:none';
    document.documentElement.appendChild(f);
    if (!isolated(f)) { f.remove(); throw refuse('unsupported'); }
    f.src = link;
    let heard = false;
    for (let i = 0; i < 40; i++) {
      await sleep(300);
      const r = await ping();
      if (!r) continue;
      heard = true;
      used.add(link); // WebPACS 有回應才算用掉；完全沒載入（blocked）時連結可能還能用
      if (r.key) { pacsFrame = f; return; }
      if (r.refused) break;
    }
    f.remove();
    throw refuse(heard ? 'auth-failed' : 'blocked');
  }

  async function onClick(tr, col) {
    const chartEl = document.getElementById('CurrentChartno');
    const chart = chartEl ? String(chartEl.value || '').trim() : '';
    if (!C.validChart(chart)) return toast(C.reasonText('bad-chart'), 8000);
    const info = rowInfo(tr, col);
    if (!info.link) return toast(C.reasonText('no-link'), 6000);
    if (info.exChart && C.chartKey(info.exChart) !== C.chartKey(chart)) return toast(C.reasonText('patient-mismatch'), 8000);
    toast('正在接上 WebPACS…');
    let connectErr = '';
    try {
      if (!connecting) connecting = connect(info.link).finally(() => { connecting = null; });
      await connecting;
    } catch (e) { connectErr = (e && e.reason) || 'error'; }
    const r = await send({ type: 'thy-open-viewer', job: { site: site.id, chart, accession: info.accession, date: info.date, kind: info.type, connectErr } });
    if (!r || !r.ok) return toast('開不了截圖視窗：' + ((r && r.error) || '外掛剛更新過的話，請重新整理這一頁'), 8000);
    toast(connectErr ? C.reasonText(connectErr) + '（小視窗會改找你自己開的 WebPACS 分頁）' : '已開截圖視窗', connectErr ? 9000 : 2500);
  }

  // ---------- 在有 WebPACS 連結的每一列加按鈕 ----------
  function decorate() {
    const table = document.getElementById('examReportTable');
    if (!table) return;
    const col = columns(table);
    if (col.type == null) return;
    let bad = 0; // 有「開啟」鈕、卻解析不出這個院區 WebPACS 連結的列（完全沒鈕＝未做／無影像，屬正常，不算）
    for (const tr of table.querySelectorAll('tbody tr')) {
      if (tr.dataset.thyPacs) continue;
      const info = rowInfo(tr, col);
      if (!info.link || !info.btn) { if (info.hasBtn) bad++; continue; }
      tr.dataset.thyPacs = '1';
      const b = document.createElement('button');
      b.type = 'button';
      b.className = 'btn btn-sm thy-pacs-btn';
      b.textContent = '🩻 截圖';
      b.title = '列出這次檢查的 PACS 影像，可框選後複製或存檔（PACS 截圖外掛）';
      b.style.cssText = 'margin-left:4px;padding:2px 8px;font-size:13px;border:1px solid #1a7bb7;border-radius:4px;background:#e8f3fb;color:#0b4f7a;cursor:pointer;white-space:nowrap';
      for (const t of ['mousedown', 'mouseup', 'dblclick']) b.addEventListener(t, (e) => e.stopPropagation());
      b.addEventListener('click', (e) => { e.preventDefault(); e.stopPropagation(); onClick(tr, col); });
      info.btn.insertAdjacentElement('afterend', b);
    }
    note(bad);
  }

  // 有列加不上按鈕時，在表格上方說明一行（只有數量，不含病歷號），不要靜默。
  let noteEl = null;
  // 注意：只在內容真的變了才寫 DOM，否則會觸發自己的 MutationObserver → 又 decorate → 無限循環。
  function note(bad) {
    const table = document.getElementById('examReportTable');
    const msg = bad ? `PACS 截圖：有 ${bad} 列檢查的「開啟」連結格式不認得，那幾列不加「🩻 截圖」。請把這頁存檔傳給維護者。` : '';
    if (!msg) { if (noteEl && noteEl.style.display !== 'none') noteEl.style.display = 'none'; return; }
    if (!noteEl || !noteEl.isConnected) {
      noteEl = document.createElement('div');
      noteEl.id = 'thy-pacs-note';
      noteEl.style.cssText = 'margin:4px 0;padding:4px 8px;font-size:13px;color:#7a4a00;background:#fff4e0;border:1px solid #f0c78a;border-radius:4px';
      table.insertAdjacentElement('beforebegin', noteEl);
    }
    if (noteEl.textContent !== msg) noteEl.textContent = msg;
    if (noteEl.style.display) noteEl.style.display = '';
  }
  decorate();
  let decoT = 0; // 體系病歷頁 DOM 變動很多：200ms 內合併成一次
  new MutationObserver(() => { clearTimeout(decoT); decoT = setTimeout(decorate, 200); }).observe(document.documentElement, { childList: true, subtree: true });
})();
