/* 甲狀腺 PACS 截圖：WebPACS（SoliPACS Web Server）頁面腳本，每個框架都會載入，但只在兩種框架裡回答：
 *   1. 外掛自己的隱藏框架（名字 thy-pacs）：檢查頁的 OpenImage 一次性連結開出來的，通行碼在頁面變數。
 *   2. 使用者自己登入的 WebPACS 分頁的查詢框架（Queryfrm）：通行碼在查詢表單。
 * 回答三件事：這位病人這次檢查是哪一筆（病歷號＋檢查單號核對）、那筆有哪些影像、取某張影像（縮圖或原圖）。
 * 對 PACS 唯讀：只發查詢與下載的 GET。通行碼當場使用，不存、不外傳。 */
(function () {
  'use strict';
  // core.js 沒有注入 WebPACS；需要的幾個小函式在下面自己寫（規則和 core.js 相同，測試在 test/）
  const BASE = '/DicomWeb/DicomWeb.dll/';
  const MAX_IMAGES = 150;
  const HIDDEN = window.name === 'thy-pacs' && window.top !== window && /\/OpenImage$/i.test(location.pathname);
  const QUERY = window.name === 'Queryfrm';
  if (!HIDDEN && !QUERY) return;

  const text = (el) => (el ? el.textContent.replace(/\s+/g, ' ').trim() : '');
  const fail = (reason, detail) => ({ ok: false, reason, detail: detail || '' });
  const chartKey = (v) => String(v == null ? '' : v).replace(/\D/g, '').replace(/^0+/, '');
  const pageAttr = (n) => document.documentElement.getAttribute(n) || '';

  function accKey() {
    try { document.dispatchEvent(new CustomEvent('thy-pacs-acckey')); } catch (e) { /* 照舊讀 */ }
    if (HIDDEN) return pageAttr('data-thy-acckey');
    const f = document.forms['QueryPatient'];
    return (f && f.AccKey && f.AccKey.value) || '';
  }
  async function getDoc(path, params) {
    const r = await fetch(BASE + path + '?' + new URLSearchParams(params), { credentials: 'include', cache: 'no-store' });
    if (!r.ok) throw Object.assign(new Error('HTTP ' + r.status), { reason: 'no-session' });
    return new DOMParser().parseFromString(await r.text(), 'text/html');
  }
  async function wado(uid, key, extra) {
    const r = await fetch(BASE + 'WADO?' + new URLSearchParams(Object.assign({ requestType: 'WADO', objectUID: uid }, extra, { AccKey: key })), { credentials: 'include', cache: 'no-store' });
    if (!r.ok) throw Object.assign(new Error('HTTP ' + r.status), { reason: 'no-session' });
    return r.blob();
  }
  const toDataUrl = (blob) => new Promise((resolve, reject) => { const fr = new FileReader(); fr.onload = () => resolve(fr.result); fr.onerror = () => reject(fr.error); fr.readAsDataURL(blob); });

  // 檢查清單的欄位沒有名字：從表頭的排序動作 SortPatient('AccNo') 這類認是哪一欄
  function columnIndex(row) {
    const out = {};
    const table = row && row.closest('table');
    const head = table && table.rows[0];
    if (head) [...head.cells].forEach((td, i) => { const m = /SortPatient\('(\w+)'\)/.exec(td.getAttribute('onclick') || ''); if (m) out[m[1]] = i; });
    return out;
  }
  function studyRow(row, col) {
    const cell = (name) => { const v = col[name] != null && row.cells[col[name]] ? text(row.cells[col[name]]) : ''; return v === '-' ? '' : v; };
    return {
      id: row.getAttribute('study_uid_id') || '',
      date: row.getAttribute('studydate') || cell('StudyDate'),
      modality: cell('Modality'), desc: cell('StudyDesc'),
      accession: cell('AccNo'), patientId: cell('PatientID'),
    };
  }
  function blankQuery(key) {
    const p = new URLSearchParams();
    const f = document.forms['QueryPatient'];
    if (f) for (const e of f.elements) {
      if (!e.name || e.type === 'button' || e.type === 'submit' || e.type === 'password') continue;
      if ((e.type === 'checkbox' || e.type === 'radio') && !e.checked) continue;
      p.set(e.name, '');
    }
    p.set('AccKey', key);
    return p;
  }
  // 和 core.js 的 pickStudy 同一套規則（WebPACS 這邊沒有載入 core.js）
  function pick(rows, want) {
    if (!rows.length) return fail('not-found');
    if (rows.some((r) => !chartKey(r.patientId))) return fail('no-patient-column');
    const same = rows.filter((r) => chartKey(r.patientId) === chartKey(want.chart));
    if (!same.length) return fail('patient-mismatch');
    if (want.accession) {
      const hit = same.filter((r) => r.accession === want.accession);
      return hit.length === 1 ? { ok: true, row: hit[0] } : fail(hit.length ? 'ambiguous' : 'not-found');
    }
    const us = same.filter((r) => String(r.date).replace(/\D/g, '') === want.date && /^US$/i.test(r.modality));
    return us.length === 1 ? { ok: true, row: us[0] } : fail(us.length ? 'ambiguous' : 'not-found');
  }

  async function study(want) {
    if (!/^\d{4,12}$/.test(want.chart) || !chartKey(want.chart)) return fail('bad-chart');
    if (want.accession && !/^[A-Za-z0-9]{6,24}$/.test(want.accession)) return fail('error', '檢查單號格式不對');
    if (!want.accession && !/^\d{8}$/.test(want.date)) return fail('not-found');
    const key = accKey();
    if (!key) return fail('no-session');
    const q = blankQuery(key);
    if (want.accession) q.set('AID', want.accession); else q.set('CHARTID', want.chart);
    const doc = await getDoc('QueryPatientStudy', q);
    const trs = [...doc.querySelectorAll('tr[study_uid_id]')];
    if (!trs.length) return fail(doc.querySelector('form[name="QuerySeries"],form#QuerySeries,form[name="ViewImage"],form#ViewImage') ? 'not-found' : 'no-session');
    const col = columnIndex(trs[0]);
    if (col.PatientID == null) return fail('no-patient-column');
    if (want.accession && col.AccNo == null) return fail('error', '檢查清單上認不出檢查單號那一欄');
    const p = pick(trs.map((r) => studyRow(r, col)), want);
    if (!p.ok) return p;
    const s = p.row;
    if (!/^[\w.-]{1,64}$/.test(s.id)) return fail('error', '檢查編號不對');
    const ser = await getDoc('QuerySeriesImage', { STUDY_UID_ID: s.id, AccKey: key });
    const images = [];
    let total = 0, si = 0;
    for (const sr of ser.querySelectorAll('tr[series_uid_id]')) {
      if (sr.getAttribute('prko') === '1') continue; // 標記／呈現狀態，不是影像
      si++;
      const idoc = await getDoc('QueryImage', { Series_UID_ID: sr.getAttribute('series_uid_id'), AccKey: key });
      for (const im of idoc.querySelectorAll('img[imagefile]')) {
        if (im.getAttribute('prko') === '1') continue;
        const uid = im.getAttribute('imagefile') || '';
        if (!/^[\w.-]{1,128}$/.test(uid)) continue;
        total++;
        if (images.length < MAX_IMAGES) images.push({ uid, series: si });
      }
    }
    if (!images.length) return fail('not-found');
    return { ok: true, study: { date: String(s.date).replace(/\D/g, '').slice(0, 8), modality: s.modality, desc: s.desc, accession: s.accession }, images, total, capped: total > images.length };
  }

  async function image(uid, size) {
    if (!/^[\w.-]{1,128}$/.test(uid)) return fail('error', '影像編號不對');
    const key = accKey();
    if (!key) return fail('no-session');
    const blob = await wado(uid, key, size === 'thumb' ? { rows: '200' } : {});
    if (!/^image\//.test(blob.type)) return fail('error', '伺服器回的不是影像');
    return { ok: true, dataUrl: await toDataUrl(blob) };
  }

  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (!msg || typeof msg.type !== 'string' || !msg.type.startsWith('thy-pacs-')) return;
    if (msg.type === 'thy-pacs-ping') {
      if (!HIDDEN) return;
      const key = accKey();
      sendResponse({ ok: true, key: !!key, refused: !key && document.readyState === 'complete' && pageAttr('data-thy-refused') === '1' });
      return;
    }
    // 使用者自己的 WebPACS 分頁只在外掛明講「找使用者的分頁」時回答；隱藏框架只在「找隱藏框架」時回答
    if ((msg.via === 'hidden') !== HIDDEN) return;
    let job;
    if (msg.type === 'thy-pacs-study') job = study({ chart: String(msg.chart || ''), accession: String(msg.accession || ''), date: String(msg.date || '') });
    else if (msg.type === 'thy-pacs-image') job = image(String(msg.uid || ''), msg.size === 'thumb' ? 'thumb' : 'full');
    else return;
    job.then(sendResponse, (e) => sendResponse(fail((e && e.reason) || 'error', String((e && e.message) || e))));
    return true;
  });
})();
