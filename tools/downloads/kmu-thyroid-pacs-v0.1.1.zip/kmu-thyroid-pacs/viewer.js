/* 甲狀腺 PACS 截圖：小視窗。縮圖 → 大圖 → 框選 → 複製（PNG 到剪貼簿）或存 JPG。
 * 影像都是背景程式向 WebPACS 那一邊要來的 data: 網址；這一頁不直接連任何網站。 */
(function () {
  'use strict';
  const C = globalThis.ThyPacsCore;
  const $ = (id) => document.getElementById(id);
  const id = location.hash.slice(1);
  const send = async (msg) => { try { return await chrome.runtime.sendMessage(Object.assign({ id }, msg)); } catch (e) { return { ok: false, reason: 'error', detail: String(e && e.message || e) }; } };
  const status = (t, err) => { $('status').textContent = t; $('status').className = err ? 'err' : ''; };

  let images = [], studyDate = '', cur = -1, full = null, sel = null, drag = null;

  async function start() {
    const j = await send({ type: 'thy-job' });
    if (!j || !j.ok) return status('找不到這次的工作（外掛可能剛重新載入），請回檢查頁重按「🩻 截圖」。', true);
    const job = j.job;
    $('meta').textContent = [job.site, '病歷號 ' + job.chart, job.date ? '檢查日 ' + job.date.slice(0, 4) + '/' + job.date.slice(4, 6) + '/' + job.date.slice(6) : '', job.kind].filter(Boolean).join('・');
    document.title = '甲狀腺 PACS 截圖'; // 標題會出現在工作列、Alt-Tab、瀏覽紀錄：不放病歷號
    studyDate = job.date;
    status('向 PACS 查這次檢查…');
    const r = await send({ type: 'thy-study' });
    if (!r || !r.ok) return status(C.reasonText(r && r.reason, r && r.detail), true);
    images = r.images;
    if (r.study && /^\d{8}$/.test(r.study.date)) studyDate = r.study.date;
    status('共 ' + r.total + ' 張' + (r.capped ? '（只列前 ' + images.length + ' 張）' : '') + (r.via === 'user' ? '・經由你自己開的 WebPACS 分頁' : '') + (r.study && r.study.desc ? '・' + r.study.desc : '') + '。點縮圖看大圖。');
    const grid = $('grid');
    images.forEach((im, i) => {
      const d = document.createElement('div');
      d.className = 'th'; d.tabIndex = 0;
      d.innerHTML = '<span>' + (i + 1) + '</span><em>載入中…</em>';
      d.addEventListener('click', () => openBig(i));
      d.addEventListener('keydown', (e) => { if (e.key === 'Enter') openBig(i); });
      im.el = d;
      grid.appendChild(d);
    });
    // 同時最多 3 張，不要一次塞爆 PACS
    let next = 0;
    const worker = async () => {
      while (next < images.length) {
        const im = images[next++];
        const t = await send({ type: 'thy-image', uid: im.uid, size: 'thumb' });
        const em = im.el.querySelector('em');
        if (t && t.ok && /^data:image\//.test(t.dataUrl)) { const img = new Image(); img.src = t.dataUrl; img.alt = ''; em.replaceWith(img); }
        else em.textContent = '縮圖載不到';
      }
    };
    await Promise.all([worker(), worker(), worker()]);
  }

  // ---------- 大圖 ----------
  const cv = $('cv'), ctx = cv.getContext('2d');
  async function openBig(i) {
    if (i < 0 || i >= images.length) return;
    cur = i; sel = null; full = null; drawSel();
    $('big').classList.add('on');
    $('prev').disabled = i === 0; $('next').disabled = i === images.length - 1;
    $('bigmsg').textContent = '第 ' + (i + 1) + '／' + images.length + ' 張・載入原圖…';
    setButtons(false);
    const r = await send({ type: 'thy-image', uid: images[i].uid, size: 'full' });
    if (cur !== i) return;
    if (!r || !r.ok) { $('bigmsg').textContent = C.reasonText(r && r.reason, r && r.detail); return; }
    const img = new Image();
    img.onload = () => {
      if (cur !== i) return;
      full = img; cv.width = img.naturalWidth; cv.height = img.naturalHeight; ctx.drawImage(img, 0, 0);
      $('bigmsg').textContent = '第 ' + (i + 1) + '／' + images.length + ' 張・' + img.naturalWidth + '×' + img.naturalHeight + '・拖曳可框選';
      setButtons(true);
    };
    img.onerror = () => { $('bigmsg').textContent = '原圖讀不出來'; };
    img.src = r.dataUrl;
  }
  function closeBig() { $('big').classList.remove('on'); cur = -1; full = null; sel = null; drawSel(); if (images.length) images[Math.max(0, Math.min(images.length - 1, lastFocus))].el.focus(); }
  let lastFocus = 0;
  function setButtons(on) { $('copy').disabled = !on; $('save').disabled = !on; $('clear').disabled = !on || !sel; }

  // 畫面座標 → 影像像素
  function toImg(e) {
    const r = cv.getBoundingClientRect();
    return { x: (e.clientX - r.left) * cv.width / r.width, y: (e.clientY - r.top) * cv.height / r.height };
  }
  function drawSel() {
    const box = $('sel');
    if (!sel) { box.style.display = 'none'; $('clear').disabled = true; return; }
    const r = cv.getBoundingClientRect(), s = $('stage').getBoundingClientRect();
    const k = r.width / cv.width;
    box.style.display = 'block';
    box.style.left = (r.left - s.left + sel.x * k) + 'px';
    box.style.top = (r.top - s.top + sel.y * k) + 'px';
    box.style.width = (sel.w * k) + 'px';
    box.style.height = (sel.h * k) + 'px';
    $('clear').disabled = false;
  }
  $('stage').addEventListener('mousedown', (e) => { if (!full || e.button !== 0) return; drag = toImg(e); e.preventDefault(); });
  window.addEventListener('mousemove', (e) => { if (!drag || !full) return; sel = C.cropRect(drag, toImg(e), cv.width, cv.height); drawSel(); });
  window.addEventListener('mouseup', () => { drag = null; });
  window.addEventListener('resize', drawSel);

  // 輸出：有框選就只輸出框選範圍
  function output() {
    if (!full) return null;
    if (!sel) return { canvas: cv, crop: false };
    const c = document.createElement('canvas');
    c.width = sel.w; c.height = sel.h;
    c.getContext('2d').drawImage(full, sel.x, sel.y, sel.w, sel.h, 0, 0, sel.w, sel.h);
    return { canvas: c, crop: true };
  }
  async function copy() {
    const o = output();
    if (!o) return;
    try {
      const blob = await new Promise((res) => o.canvas.toBlob(res, 'image/png'));
      await navigator.clipboard.write([new ClipboardItem({ 'image/png': blob })]);
      flash('已複製' + (o.crop ? '框選範圍' : '整張') + '，可以直接貼到報告');
    } catch (e) { flash('複製失敗：' + String(e && e.message || e)); }
  }
  async function save() {
    const o = output();
    if (!o) return;
    const name = C.fileName(studyDate, cur + 1, o.crop, 'jpg');
    const r = await send({ type: 'thy-save', dataUrl: o.canvas.toDataURL('image/jpeg', 0.95), filename: name });
    flash(r && r.ok ? '已存到「下載」/' + name : '存檔失敗：' + ((r && r.error) || ''));
  }
  let flashT = 0;
  function flash(t) { const m = $('bigmsg'); const keep = m.dataset.keep || m.textContent; m.dataset.keep = keep; m.textContent = t; clearTimeout(flashT); flashT = setTimeout(() => { m.textContent = m.dataset.keep; delete m.dataset.keep; }, 3000); }

  $('back').onclick = closeBig;
  $('prev').onclick = () => { lastFocus = cur - 1; openBig(cur - 1); };
  $('next').onclick = () => { lastFocus = cur + 1; openBig(cur + 1); };
  $('clear').onclick = () => { sel = null; drawSel(); };
  $('copy').onclick = copy;
  $('save').onclick = save;
  window.addEventListener('keydown', (e) => {
    if (!$('big').classList.contains('on')) return;
    if (e.key === 'Escape') { if (sel) { sel = null; drawSel(); } else closeBig(); }
    else if (e.key === 'ArrowLeft' && cur > 0) { lastFocus = cur - 1; openBig(cur - 1); }
    else if (e.key === 'ArrowRight' && cur < images.length - 1) { lastFocus = cur + 1; openBig(cur + 1); }
    else if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'c') { e.preventDefault(); copy(); }
    else if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 's') { e.preventDefault(); save(); }
  });
  document.addEventListener('click', (e) => { const t = e.target.closest && e.target.closest('.th'); if (t) lastFocus = [...$('grid').children].indexOf(t); });

  // 同一個小視窗換病人時，背景程式只換 # 後面：整頁重來
  window.addEventListener('hashchange', () => location.reload());
  start();
})();
