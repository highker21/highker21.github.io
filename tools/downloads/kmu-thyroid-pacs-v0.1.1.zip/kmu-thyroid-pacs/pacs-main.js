/* 甲狀腺 PACS 截圖：在 WebPACS 頁面自己的環境（world: MAIN，document_start）跑的一小段。
 * pacs.js 在隔離環境，讀不到頁面的程式變數（登入後的通行碼 AccKey）；這裡替它做兩件事：
 * 1. 外掛自己的隱藏框架（名字 thy-pacs，開的是檢查頁的 OpenImage 一次性連結）：
 *    那一頁原本會去連本機的看片程式（ws://127.0.0.1）；在「這個框架裡」把 WebSocket 換成不連線的空殼，
 *    看片程式不會被叫出來。pacs.js 發事件時，把通行碼抄到框架自己的網頁屬性上給它讀。
 * 2. 使用者自己登入的 WebPACS 查詢框架（Queryfrm）：通行碼只在程式變數裡，按「查詢」時才填進表單；
 *    pacs.js 要用前發事件，這裡做頁面本來就會做的那一步：填進查詢表單的隱藏欄位。
 * 不存、不外傳；使用者自己開的 WebPACS 與看片程式不受影響。 */
(function () {
  'use strict';
  var attr = function (name, value) { try { document.documentElement.setAttribute(name, value); } catch (e) { /* 還沒有根元素 */ } };

  if (window.name === 'thy-pacs' && window.top !== window) {
    var Quiet = function () { this.readyState = 3; this.url = ''; this.send = function () {}; this.close = function () {}; };
    Quiet.CONNECTING = 0; Quiet.OPEN = 1; Quiet.CLOSING = 2; Quiet.CLOSED = 3;
    try { Object.defineProperty(window, 'WebSocket', { configurable: true, writable: true, value: Quiet }); } catch (e) { window.WebSocket = Quiet; }
    document.addEventListener('thy-pacs-acckey', function () {
      var key = '', refused = '';
      try { if (typeof window.AccKey === 'string') key = window.AccKey; } catch (e) { /* 留空 */ }
      try { if (!key && typeof window.msg === 'string' && window.msg) refused = '1'; } catch (e) { /* 留空 */ }
      attr('data-thy-acckey', key);
      attr('data-thy-refused', refused);
    });
    return;
  }

  if (window.name !== 'Queryfrm') return;
  document.addEventListener('thy-pacs-acckey', function () {
    try {
      var form = document.getElementById('QueryPatient');
      var key = window.AccKey;
      if (form && form.AccKey && typeof key === 'string' && key) form.AccKey.value = key;
    } catch (e) { /* 讀不到就照舊，pacs.js 會說沒接上 */ }
  });
})();
