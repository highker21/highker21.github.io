// 報表頁：讀 storage → exportRows（與 Python 記錄器逐格一致）→ 版面比照 clinic_report.py（一～六節）
const params = new URLSearchParams(location.search);
const ID = params.get("id");
let DATA = null, ROWS = null;

const esc = (s) => String(s ?? "").replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
const f1 = (x) => (x === null || x === undefined ? "—" : (Math.round(x * 10) / 10).toFixed(1));
const hm = (ms) => KMU.iso(ms).slice(11, 16);

async function load() {
  const k = ["sessions", "ctx_" + ID, "ev_" + ID, "sm_" + ID];
  const g = await chrome.storage.local.get(k);
  const s = (g.sessions || {})[ID];
  if (!s) { document.getElementById("out").textContent = "找不到這筆記錄（可能已刪除）。"; return null; }
  return { s, ctx: g["ctx_" + ID] || KMU.newCtx(), events: g["ev_" + ID] || [], samples: g["sm_" + ID] || [] };
}

function toMs(day, hms) { return hms ? Date.parse(`${day}T${hms}+08:00`) : null; }

function render() {
  const { s, ctx, events, samples } = DATA;
  // 取樣間隔：舊記錄沒存 → 20 秒（與 v1.0.x 完全相同）。空叫門檻至少 30 秒，不隨短間隔縮小
  const iv = KMU.ivOf(s), flash = Math.max(KMU.FLASH_SEC, iv.max * 1.5);
  ROWS = KMU.exportRows(events, ctx.state, iv.max, flash);   // 與 Python CSV 逐格一致（下載 CSV 用這份）
  // ---- 顯示層調整（不動 CSV）：B 2026-10-15 驗收建議 ----
  // ① 左設限：記錄開始前就已經在看診／已報到的人，開始或報到時間其實是「記錄起點」，
  //    看診或候診分鐘只是下界，不能混進統計（比照「推估完成時間」的處理）。
  // ② 「未看診即離開（消失前：過號）」沿用 Python 標籤，但有完成時間的人其實是看完才離開，直接給老闆看會誤解。
  const first = events.length ? KMU.hms(events[0].ts) : (samples.length ? KMU.hms(KMU.iso(samples[0])) : "");
  const VIEW = ROWS.map((r) => {
    const v = { ...r }, st = { ...r }, add = [];
    if (first && r["開始看診"] === first) { add.push("開始時間＝記錄起點（看診分鐘為下界，不列入統計）"); st["看診分鐘"] = ""; st["候診分鐘"] = ""; }
    else if (first && r["開始看診"] && r["報到時間"] === first) { add.push("報到早於記錄起點（候診分鐘為下界，不列入統計）"); st["候診分鐘"] = ""; }
    if (r["完成時間"]) v["資料品質"] = v["資料品質"].replace(/未看診即離開（消失前：過號）/, "看完後轉過號、離開清單");
    if (add.length) v["資料品質"] = (v["資料品質"] === "正常" ? "" : v["資料品質"] + "／") + add.join("／");
    v._censored = add.length > 0;
    return { v, st };
  });
  const sum = KMU.summarize(VIEW.map((x) => x.st));
  const censored = VIEW.filter((x) => x.v._censored).map((x) => x.v["看診號"]);
  const q = KMU.sampleQuality(samples, iv);
  const site = KMU.SITES[s.site].name, noon = KMU.NOONS[s.noon];
  const doctor = s.pageDoctor || s.doctor || "";
  const recFrom = samples.length ? samples[0] : s.created;
  const recTo = samples.length ? samples[samples.length - 1] : s.created;
  const status = { running: "記錄中（報表自動更新）", paused: "已暫停", stopped: "" }[s.status] || "";
  const visits = VIEW.map((x) => x.st["看診分鐘"]).filter((x) => typeof x === "number");
  const waits = VIEW.map((x) => x.st["候診分鐘"]).filter((x) => typeof x === "number");
  const longWait = VIEW.map((x) => x.st).filter((r) => typeof r["候診分鐘"] === "number" && r["候診分鐘"] >= 120)
    .sort((a, b) => b["候診分鐘"] - a["候診分鐘"]);
  const estRows = ROWS.filter((r) => r["推估完成時間"]);

  // ---- 卡片（同 Python 報告：總號數／已報到／進過診間／完成時間實測／看診中位數／候診中位數／最長候診） ----
  const card = (v, l, sub) => `<div class="card"><div class="v">${v}</div><div class="l">${l}</div>${sub ? `<div class="s">${sub}</div>` : ""}</div>`;
  const cards = [
    card(sum.total, "總號數"),
    card(sum.checkedIn, "已報到"),
    card(sum.entered, "進過診間", "＝看診人數"),
    card(sum.measured, "完成時間實測", `另 ${estRows.length} 筆為推估`),
    sum.visitMedian !== null ? card(f1(sum.visitMedian), "看診中位數（分）", `平均 ${f1(sum.visitMean)}`) : "",
    sum.waitMedian !== null ? card(f1(sum.waitMedian), "候診中位數（分）", `平均 ${f1(sum.waitMean)}`) : "",
    sum.waitMax !== null ? card(Math.round(sum.waitMax), "最長候診（分）", "見下方名單") : "",
  ].join("");

  // ---- 取樣缺口：會讓整份統計不完整，放在最上面（Python 版沒有這種情況，所以沒有這塊） ----
  const gapBox = q.gaps.length ? `<div class="badbox"><b>以下時段沒有記到</b>（電腦睡眠、Chrome 關閉或斷網）：` +
    q.gaps.map(([a, b]) => `${hm(a)}–${hm(b)}（${Math.round((b - a) / 60000)} 分）`).join("、") +
    `。這些時段內發生的報到、看診與完成時間都無法得知，統計不完整。</div>` : "";

  const tblHead = ["看診號", "報到", "開始看診", "完成", "候診(分)", "看診(分)", "最終狀態", "資料品質"];
  const tblKeys = ["看診號", "報到時間", "開始看診", "完成時間", "候診分鐘", "看診分鐘", "最終狀態", "資料品質"];
  const table = ROWS.length ? `<div class="tblwrap"><table><thead><tr>${tblHead.map((h) => `<th>${h}</th>`).join("")}</tr></thead><tbody>` +
    VIEW.map(({ v: r }) => {
      const warn = typeof r["候診分鐘"] === "number" && r["候診分鐘"] >= 120;
      const qq = r["資料品質"] || "";
      return `<tr${warn ? " class='warn'" : ""}>` + tblKeys.map((k) => {
        let val = r[k] === "" || r[k] === null || r[k] === undefined ? (k === "資料品質" || k === "最終狀態" ? "" : "—") : r[k];
        if (typeof val === "number") val = val.toFixed(1);   // 同 Python CSV：分鐘一律一位小數
        const cls = k === "候診分鐘" || k === "看診分鐘" ? " class='n'" : (k === "資料品質" && qq && qq !== "正常" ? " class='q'" : "");
        return `<td${cls}>${esc(val)}</td>`;
      }).join("") + `</tr>`;
    }).join("") + `</tbody></table></div>` : `<p class="note">還沒有任何號碼資料。</p>`;

  const qc = {};
  for (const { v } of VIEW) { const k = v["資料品質"] || "（未標）"; qc[k] = (qc[k] || 0) + 1; }
  const stat = (a) => a.length ? { n: a.length, med: KMU.median(a), mean: a.reduce((x, y) => x + y, 0) / a.length, min: Math.min(...a), max: Math.max(...a) } : null;
  const sc = stat(visits), sw = stat(waits);

  const extra = [];
  if (sum.flashOnly.length) extra.push(`只有空叫（叫號時人不在）、從未實際看診：${sum.flashOnly.join("、")} 號`);
  if (sum.leftNoVisit.length) extra.push(`從沒進過診間就從清單消失（已完診或取消掛號，站方分不出來）：${sum.leftNoVisit.join("、")} 號`);
  if (censored.length) extra.push(`記錄開始前就已報到或已在看診，分鐘數只是下界、不列入統計：${censored.join("、")} 號`);

  document.getElementById("live").textContent = s.status === "running" ? `● 記錄中，${hm(Date.now())} 更新` : "";
  document.getElementById("gen").textContent = `產製時間：${KMU.iso(Date.now()).slice(0, 16).replace("T", " ")}（台灣時間）・`;
  document.getElementById("out").innerHTML = `
    <h1>門診記錄報告</h1>
    <div class="sub">${esc(site)}・${esc(noon)}　${esc(s.day)}　${esc(s.dname)}${doctor ? `・${esc(doctor)} 醫師` : ""}
    記錄區間 ${hm(recFrom)} – ${hm(recTo)}${status ? `・${status}` : ""}</div>
    ${gapBox}
    <div class="cards">${cards}</div>

    <h2>一、時間軸：每一號的候診與看診</h2>
    <div class="note">一號一列，依開始看診時間排序。淺色＝從報到到被叫號的等待，深色＝實際看診。</div>
    <div class="tlbox">${timeline(s.day)}
    <div class="legend"><span><i style="background:#cfe4e2"></i>候診</span>
    <span><i style="background:#0f6e64"></i>看診</span>
    <span><i style="border:1px dashed #0f6e64"></i>推估（完成時間缺失）</span>
    <span><i style="background:#c0562c"></i>沒等到結束（收工時未結束／中途失去追蹤）</span></div></div>

    <h2>二、看診時間分布</h2>
    ${hist(visits, [0, 2, 4, 6, 8, 10], "看診分鐘", "#0f6e64")}
    <div class="note">n＝${sc ? sc.n : 0}　中位數 ${sc ? f1(sc.med) : "—"} 分、平均 ${sc ? f1(sc.mean) : "—"} 分、範圍 ${sc ? `${f1(sc.min)}–${f1(sc.max)}` : "—"} 分</div>

    <h2>三、候診時間分布</h2>
    ${hist(waits, [0, 30, 60, 90, 120, 150], "候診分鐘", "#7aa8a3")}
    <div class="note">n＝${sw ? sw.n : 0}　中位數 ${sw ? f1(sw.med) : "—"} 分、平均 ${sw ? f1(sw.mean) : "—"} 分、最長 ${sw ? f1(sw.max) : "—"} 分</div>
    <div class="warnbox"><b>候診超過 2 小時者（${longWait.length} 人）</b><br>${longWait.map((r) => `${esc(r["看診號"])} 號（${Math.round(r["候診分鐘"])} 分）`).join("、") || "無"}</div>

    <h2>四、完整記錄</h2>
    ${table}

    <h2>五、完成時間缺失與推估（${estRows.length} 筆）</h2>
    <div class="note">這 ${estRows.length} 位<b>確實進過診間</b>，但完成時間沒有被記到。
    推估依據：<b>醫師不可能同時看兩個人，所以下一號開始看診時，這一號必定已結束。</b>
    因此推估值是<b>上界</b>（含叫下一位的空檔），<b>必然高估</b>，所以<b>刻意不併入上面的看診時間統計</b>，只單獨列出。</div>
    <div class="warnbox">${estRows.map((r) => `${esc(r["看診號"])} 號（${esc(r["開始看診"])}→推估 ${esc(r["推估完成時間"])}，約 ${esc(r["推估看診分鐘"])} 分）`).join("、") || "無"}</div>
    <div class="note">・<b>本報告仍可能少算</b>：本工具只看得到候診系統上的號碼，現場加號或以其他途徑掛號者不會出現在這裡。</div>

    <h2>六、資料品質與誤差</h2>
    <div class="note">這份記錄是依設定間隔（${esc(KMU.ivText(iv))}）抓取網站狀態推導出來的，<b>不是院方系統的原始時間</b>。以下逐項標明，不把估計值當成精確值。</div>
    <ul class="qc">${Object.entries(qc).sort((a, b) => b[1] - a[1]).map(([k, n]) => `<li><b>${esc(k)}</b>：${n} 筆</li>`).join("")}</ul>
    ${extra.length ? `<ul class="qc">${extra.map((x) => `<li>${esc(x)}</li>`).join("")}</ul>` : ""}
    <div class="note">
    ・<b>取樣</b>：共 ${q.n} 次，記錄時段 ${hm(recFrom)}–${hm(recTo)}${q.median !== null ? `；實際間隔中位數 ${q.median.toFixed(1)} 秒，最長 ${q.max.toFixed(0)} 秒` : ""}。${q.gaps.length ? `<b>有 ${q.gaps.length} 段沒記到</b>（見最上方）。` : (q.n > 1 ? "整段沒有中斷。" : "")}${q.slow ? `有 ${q.slow} 次間隔超過 ${f1(q.warn).replace(/\.0$/, "")} 秒，這幾段的時間誤差會大於 ${iv.max} 秒。` : ""}${s.lastErr ? `最近一次抓取錯誤：${esc(s.lastErr)}。` : ""}${s.reason ? esc(s.reason) : ""}<br>
    ・<b>完成時間誤差上界</b>：${iv.max} 秒（＝取樣間隔上限）。網站的號碼格看不出「已完診」，完成時間是以「離開看診中」判定，因此最多會晚一個取樣間隔。<br>
    ・<b>看診時間含叫號空檔</b>：站方是在下一位開始時才更新前一位狀態，所以「看診分鐘」實際是該病人佔用診間的時間。<br>
    ・<b>空叫</b>：被叫號但停留 ≤${flash} 秒，視為誤觸或跳號，不計入看診時間；同一號被叫多次只取最後一段。<br>
    ・<b>報到未觀測</b>：記錄開始前就已報到，無法回推報到時刻，候診時間不列入統計。<br>
    ・<b>收工時未結束</b>：停止記錄當下仍在看診中（每節最多一筆，即最後一號），看診時間不列入統計。<br>
    ・<b>看診中途失去追蹤</b>：被叫進去之後就沒等到結束，而後面還有別的號碼被叫——這一號必定已經結束，只是網站沒讓我們看到。看診時間同樣不列入統計。<br>
    ・統計的 n 已排除上述無法認定的筆數，各段落均標明實際 n。下載的 CSV 與 Python 記錄器格式完全相同；畫面與 PDF 上的部分文字為了好讀有調整（例如 Python 版的「未看診即離開（消失前：過號）」若其實有完成時間，這裡改標「看完後轉過號、離開清單」，所以第六節分類筆數會和 Python 版不同）。
    </div>`;
}

// 直方圖：與 clinic_report.py svg_hist 相同（固定分組、最高柱上方留空間）
function hist(vals, bins, unit, color) {
  if (!vals.length) return `<p class="note">無資料。</p>`;
  const edges = [...bins, Infinity], counts = new Array(bins.length).fill(0);
  for (const v of vals) for (let i = 0; i < bins.length; i++) if (edges[i] <= v && v < edges[i + 1]) { counts[i]++; break; }
  const mx = Math.max(...counts) || 1;
  const BW = 52, GAP = 10, H = 120, TOP = 16, W = counts.length * (BW + GAP);
  let g = "";
  counts.forEach((c, i) => {
    const x = i * (BW + GAP), h = c / mx * H;
    g += `<rect x="${x}" y="${(TOP + H - h).toFixed(1)}" width="${BW}" height="${h.toFixed(1)}" rx="3" fill="${color}"/>`;
    g += `<text x="${x + BW / 2}" y="${(TOP + H - h - 4).toFixed(1)}" text-anchor="middle" font-size="10" fill="#5f7070">${c}</text>`;
    const lab = i + 1 < bins.length ? `${bins[i]}–${bins[i + 1]}` : `≥${bins[i]}`;
    g += `<text x="${x + BW / 2}" y="${TOP + H + 15}" text-anchor="middle" font-size="9" fill="#93a3a3">${lab}</text>`;
  });
  g += `<text x="${W / 2}" y="${TOP + H + 33}" text-anchor="middle" font-size="9" fill="#93a3a3">${unit}</text>`;
  return `<svg class="hist" viewBox="0 0 ${W} ${TOP + H + 40}" role="img" aria-label="${unit}">${g}</svg>`;
}

// 時間軸：與 clinic_report.py svg_timeline 相同（每 30 分刻度、淺色候診／深色看診／橘色沒等到結束），另加虛框＝推估
function timeline(day) {
  const rs = ROWS.map((r) => ({
    no: r["看診號"], ci: toMs(day, r["報到時間"]), st: toMs(day, r["開始看診"]),
    en: toMs(day, r["完成時間"]), est: toMs(day, r["推估完成時間"]),
  })).filter((r) => r.st || r.ci).sort((a, b) => (a.st || a.ci) - (b.st || b.ci));
  if (!rs.length) return `<p class="note">沒有足夠的時間資料可畫時間軸。</p>`;
  const vals = rs.flatMap((r) => [r.ci, r.st, r.en, r.est]).filter(Boolean);
  const lo = Math.floor(Math.min(...vals) / 1800e3) * 1800e3, hi = (Math.floor(Math.max(...vals) / 1800e3) + 1) * 1800e3;
  const LW = 46, W = 700, RH = 15, TOP = 30, H = TOP + rs.length * RH + 22;
  const X = (t) => LW + (t - lo) / (hi - lo) * W;
  let g = "";
  for (let t = lo; t <= hi; t += 1800e3) {
    g += `<line x1="${X(t).toFixed(1)}" y1="${TOP - 8}" x2="${X(t).toFixed(1)}" y2="${H - 20}" stroke="#e6eeee" stroke-width="1"/>`;
    g += `<text x="${X(t).toFixed(1)}" y="${TOP - 12}" text-anchor="middle" font-size="9" fill="#93a3a3">${hm(t)}</text>`;
  }
  rs.forEach((r, i) => {
    const y = TOP + i * RH;
    g += `<text x="${LW - 6}" y="${y + 10}" text-anchor="end" font-size="8.5" fill="#5f7070">${esc(r.no)}</text>`;
    if (r.ci && r.st && r.st > r.ci) g += `<rect x="${X(r.ci).toFixed(1)}" y="${y + 3}" width="${Math.max(1, X(r.st) - X(r.ci)).toFixed(1)}" height="8" rx="2" fill="#cfe4e2"/>`;
    if (r.st && r.en && r.en > r.st) g += `<rect x="${X(r.st).toFixed(1)}" y="${y + 1}" width="${Math.max(1.5, X(r.en) - X(r.st)).toFixed(1)}" height="12" rx="2" fill="#0f6e64"/>`;
    else if (r.st && r.est && r.est > r.st) g += `<rect x="${X(r.st).toFixed(1)}" y="${y + 1.5}" width="${Math.max(1.5, X(r.est) - X(r.st)).toFixed(1)}" height="11" rx="2" fill="none" stroke="#0f6e64" stroke-dasharray="3 2"/>`;
    else if (r.st && !r.en) g += `<rect x="${X(r.st).toFixed(1)}" y="${y + 1}" width="4" height="12" rx="2" fill="#c0562c"/>`;
  });
  return `<svg class="tl" viewBox="0 0 ${LW + W + 14} ${H}" role="img" aria-label="時間軸">${g}</svg>`;
}

function download(name, text, type) {
  const a = document.createElement("a");
  a.href = URL.createObjectURL(new Blob([text], { type }));
  a.download = name; a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 5000);
}
function fileBase() { const s = DATA.s; return `${s.day}_${s.site}_${s.noon}_${s.dept}_${s.pageDoctor || s.doctor || ""}`; }

document.getElementById("print").onclick = () => window.print();
document.getElementById("csv").onclick = () => {
  if (!ROWS || !ROWS.length) return;
  const head = Object.keys(ROWS[0]);
  const cell = (v) => { const t = String(v ?? ""); return /[",\n]/.test(t) ? `"${t.replace(/"/g, '""')}"` : t; };
  const text = "﻿" + [head.join(","), ...ROWS.map((r) => head.map((h) => cell(r[h])).join(","))].join("\r\n");
  download(fileBase() + "_門診記錄.csv", text, "text/csv");
};
document.getElementById("json").onclick = () => {
  download(fileBase() + "_原始資料.json", JSON.stringify({ session: DATA.s, state: DATA.ctx.state, events: DATA.events, samples: DATA.samples }, null, 1), "application/json");
};

(async function main() {
  DATA = await load();
  if (!DATA) return;
  document.title = `${DATA.s.day} ${DATA.s.pageDoctor || DATA.s.doctor || ""} 門診進度報表`;
  render();
  setInterval(async () => {
    if (!DATA || DATA.s.status !== "running") return;
    DATA = await load(); if (DATA) render();
  }, 20000);
})();
