// 背景（service worker）：抓資料、跑狀態機、存檔。
// ⚠️ MV3 的 service worker 閒置約 30 秒就會被停掉，所以它自己不能當時鐘。
//    時鐘＝offscreen document（至少每 1 秒送一個 tick 進來，順便把 SW 叫醒；SW 回覆下一次要等多久）；
//    tick 只檢查「哪個診到期了」（session.nextAt），到期才抓。間隔每個診各自設定（session.iv），
//    隨機模式每抓一次就重抽下一次的間隔（v1.1.0）。
//    chrome.alarms 每 30 秒當看門狗：offscreen 不見了就重建，太久沒 tick 就自己補一輪。
//    預約開始另用 chrome.alarms（sched:<id>）叫醒，見「預約開始」段。
//    不用「常駐分頁＋setInterval」：分頁在背景 5 分鐘後會被 Chrome 壓到每分鐘一次
//    （intensive throttling），報表會看起來正常但其實取樣變稀（B 2026-10-15 提醒）。
importScripts("core.js");

const OFFSCREEN = "offscreen.html";
const primed = {};          // 每個院區是否已取得 session cookie（SW 重啟就重來，成本很低）
let ticking = false;
let lastTick = 0;
let lastSaved = 0;

// ---------- 儲存 ----------
const get = async (k, d) => ((await chrome.storage.local.get(k))[k] ?? d);
const set = (obj) => chrome.storage.local.set(obj);
async function sessions() { return get("sessions", {}); }

// ---------- 站方請求 ----------
async function prime(site) {
  const base = KMU.SITES[site].base;
  const r = await fetch(base + "/OPDSeq/ProcessMain?lang=tw", { credentials: "include", cache: "no-store" });
  if (!r.ok) throw new Error(`ProcessMain HTTP ${r.status}`);
  await r.text();
  primed[site] = true;
}
async function post(site, path, data) {
  if (!primed[site]) await prime(site);
  const base = KMU.SITES[site].base;
  const r = await fetch(base + path, {
    method: "POST", credentials: "include", cache: "no-store",
    headers: { "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8", "X-Requested-With": "XMLHttpRequest" },
    body: new URLSearchParams(data).toString(),
    // 岡山會把 GetClinicProcessDetail 302 轉到 ProcessDetailAdvantech（GET 帶參數），fetch 會自動跟
  });
  if (!r.ok) throw new Error(`HTTP ${r.status}`);
  const html = await r.text();
  // 站方 session 過期時回整頁（含 <!DOCTYPE html>），前端程式也是用這個判斷「請重新登入」
  if (html.includes("<!DOCTYPE html>") && !html.includes("fn_ShowProcessBySeqNo") && !html.includes("c_table")) {
    primed[site] = false;
    throw new Error("站方 session 失效（已重新取得，下一輪重試）");
  }
  return html;
}
async function listClinics(site, noon) {
  const html = await post(site, "/OPDSeq/GetSeqDetial", { VirtualDept: "0000", Noon: noon });
  return KMU.parseClinicList(html);
}
async function fetchDetail(s) {
  return post(s.site, "/OPDSeq/GetClinicProcessDetail",
    { VirtualDept: "0000", DeptCode: s.dept, DeptName: s.dname, Noon: s.noon });
}

// ---------- 一輪 ----------
function untilMs(s) {
  const [h, m] = s.until.split(":").map(Number);
  let t = Date.parse(`${s.day}T${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}:00+08:00`);
  if (t <= s.created) t += 86400e3;     // 跨午夜
  return t;
}

// ⚠️ 所有對 storage 的「讀→改→寫」一律排進同一條佇列依序執行，而且只 patch 自己那一筆。
//    v1.0.0 的 pollOne 是「先讀整包 sessions → await fetch（數秒）→ 整包寫回」，
//    這幾秒內 popup 的開始／停止／刪除會被舊資料蓋掉：新勾的診安靜消失、按了停止又變回記錄中
//    （B 2026-10-15 審查抓到）。fetch 放在佇列外面，只有寫入在佇列裡。
let queue = Promise.resolve();
function serial(fn) {
  const p = queue.then(fn, fn);
  queue = p.catch(() => {});
  return p;
}
// 在佇列裡重新讀最新的 sessions，交給 fn 修改；fn 回傳 false 代表不寫
function mutate(fn) {
  return serial(async () => {
    const all = await sessions();
    const extra = await fn(all);
    if (extra === false) return false;
    await set({ sessions: all, ...(extra || {}) });
    return true;
  });
}

async function pollOne(id) {
  const s0 = (await sessions())[id];
  if (!s0 || s0.status !== "running" || (s0.nextAt || 0) > Date.now()) return;
  const now = Date.now();
  if (now >= untilMs(s0)) {
    await mutate((all) => {
      const s = all[id];
      if (!s || s.status !== "running") return false;
      s.status = "stopped"; s.stoppedAt = now; s.reason = `到預定時間 ${s.until} 自動收工`;
    });
    return;
  }
  let html, err = null;
  try { html = await fetchDetail(s0); } catch (e) { err = e; }
  const okAt = Date.now();
  const ts = KMU.iso(okAt);
  await mutate(async (all) => {
    const s = all[id];
    // fetch 期間被停止、暫停或刪除 → 這一輪結果作廢，什麼都不寫
    if (!s || s.status !== "running") return false;
    // 下一次什麼時候抓：從「這次發出請求」起算，隨機模式每次重抽
    const next = KMU.drawIv(KMU.ivOf(s));
    s.nextAt = now + next * 1000;
    if (err) {
      s.failStreak = (s.failStreak || 0) + 1;
      // 失敗就退避（10→20→40→80→120 秒封頂），短間隔模式下避免連續失敗時一直打站方、被 WAF 擋
      s.nextAt = now + Math.max(next, Math.min(120, 10 * 2 ** (s.failStreak - 1))) * 1000;
      s.lastErr = `${KMU.iso(now).slice(11, 19)} ${err.message}`;
      if (s.failStreak >= 3) primed[s.site] = false;     // 連續失敗才重建 session
      return;
    }
    const snap = KMU.parseDetail(html);
    const doc = KMU.doctorOf(html);
    // 醫師核對：選的是「診間」，同一診間不同時段是不同醫師。頁面一放出姓名就核對，
    // 對不上就暫停，不要安靜地記到別人的診（2026-08-10 Python 版踩過）。
    if (doc && !s.doctorConfirmed) {
      const ok = !s.doctor || doc === s.doctor || (s.sub && doc === s.sub);
      if (!ok) {
        s.status = "paused";
        s.reason = `頁面顯示的醫師是「${doc}」，不是選定的「${s.doctor}」，已暫停（沒有寫入資料）`;
        return;
      }
      s.doctorConfirmed = true;
      s.pageDoctor = doc;
    }
    s.failStreak = 0;
    s.lastErr = "";
    s.lastOk = okAt;
    const k = { ctx: "ctx_" + id, ev: "ev_" + id, sm: "sm_" + id };
    const got = await chrome.storage.local.get([k.ctx, k.ev, k.sm]);
    const samples = got[k.sm] || [];
    samples.push(okAt);
    if (!snap) {
      s.note = "尚無號碼資料（可能還沒開診或已收診）";
      return { [k.sm]: samples };
    }
    const ctx = got[k.ctx] || KMU.newCtx();
    const events = got[k.ev] || [];
    const { events: neu, truncated } = KMU.step(ctx, snap, ts);
    events.push(...neu);
    s.note = truncated ? `回應只有 ${Object.keys(snap.seq).length} 列，本輪不做消失判定` : "";
    s.calling = snap.calling;
    s.rows = Object.keys(snap.seq).length;
    s.siteUpdated = snap.site_updated;
    return { [k.ctx]: ctx, [k.ev]: events, [k.sm]: samples };
  });
}

let again = false;
async function tick(source) {
  // 正在跑的話記一筆「跑完再來一輪」，不要直接丟掉（新開始的診要馬上抓第一筆）
  if (ticking) { again = true; return; }
  ticking = true;
  try {
    do {
      again = false;
      const prevSaved = lastSaved;
      lastTick = Date.now();
      const run = Object.values(await sessions()).filter((s) => s.status === "running");
      const due = run.filter((s) => (s.nextAt || 0) <= lastTick);
      // 依序抓，避免同時打太多請求
      for (const s of due) { try { await pollOne(s.id); } catch (e) { console.warn("poll", s.id, e); } }
      if (!run.length) await closeOffscreen();
      // tick 每秒一次，lastTick 不必每秒寫進 storage（看門狗只看 40 秒內有沒有 tick）
      if (lastTick - prevSaved >= 10e3 || due.length) { lastSaved = lastTick; await set({ lastTick: { at: lastTick, source } }); }
    } while (again);
  } finally { ticking = false; }
}
// 告訴 offscreen 下一次 tick 要等多久：最早到期的診還差幾毫秒（最多 1 秒，最少 50 毫秒）。
// 只靠固定每秒 tick 的話，到期時間常落在 tick 後幾毫秒，固定 20 秒會變成 21 秒。
async function nextWait() {
  const run = Object.values(await sessions()).filter((s) => s.status === "running");
  if (!run.length) return 1000;
  const due = Math.min(...run.map((s) => s.nextAt || 0)) - Date.now();
  return Math.max(50, Math.min(1000, due + 5));
}

// ---------- 時鐘 ----------
async function ensureOffscreen() {
  if (await chrome.offscreen.hasDocument()) return;
  try {
    await chrome.offscreen.createDocument({
      url: OFFSCREEN, reasons: ["DOM_PARSER"],
      justification: "依設定的間隔觸發門診進度抓取（service worker 無法常駐計時）",
    });
  } catch (e) { if (!String(e).includes("single offscreen")) throw e; }
}
async function closeOffscreen() {
  if (await chrome.offscreen.hasDocument()) await chrome.offscreen.closeDocument();
}
async function ensureClock() {
  const all = await sessions();
  if (Object.values(all).some((s) => s.status === "running")) {
    await ensureOffscreen();
    const a = await chrome.alarms.get("watchdog");
    if (!a) chrome.alarms.create("watchdog", { periodInMinutes: 0.5 });
  } else {
    await closeOffscreen();
    chrome.alarms.clear("watchdog");
  }
}
chrome.alarms.onAlarm.addListener(async (a) => {
  if (a.name !== "watchdog") return;
  await ensureClock();
  const lt = (await get("lastTick", {})).at || 0;
  if (Date.now() - Math.max(lt, lastTick) > 40e3) tick("alarm");
});
chrome.runtime.onStartup.addListener(() => { ensureClock(); syncSchedAlarms(); });
chrome.runtime.onInstalled.addListener(() => { ensureClock(); syncSchedAlarms(); });

// ---------- 開始記錄（手動開始與預約開始共用） ----------
async function startClinics({ site, noon, iv: ivKey, until, clinics }) {
  const now = Date.now();
  const ids = [];
  const io = KMU.IV_OPTS[ivKey] || KMU.IV_OPTS["20"];
  const iv = { key: KMU.IV_OPTS[ivKey] ? ivKey : "20", min: io.min, max: io.max };
  await mutate((all) => { for (const c of clinics) {
    const day = KMU.today(now);
    const base = `${day}_${site}_${noon}_${c.dept}`;
    // 同一天同一診已在記錄中就不重開（預約和手動同時按也不會重複）
    const live = Object.values(all).find((s) => (s.id === base || s.id.startsWith(base + "_")) && s.status === "running");
    if (live) { ids.push(live.id); continue; }
    // 同一診有已結束／暫停的舊記錄：另開新 id，不覆寫舊的（舊的 ctx_/ev_/sm_ 會被接在新記錄上；B 2026-10-22 review）
    const id = all[base] ? `${base}_${KMU.iso(now).slice(11, 19).replace(/:/g, "")}` : base;
    all[id] = { id, site, noon, dept: c.dept, dname: c.dname,
      doctor: c.doctor || "", sub: c.sub || "", day, created: now, until,
      status: "running", reason: "", doctorConfirmed: false, failStreak: 0, iv, nextAt: 0 };
    ids.push(id);
  } });
  await ensureClock();
  tick("start");
  return ids;
}

// ---------- 預約開始（v1.2.0） ----------
// 用 chrome.alarms（when）叫醒 SW；SW 休眠、Chrome 重開後鬧鐘仍在（onStartup 再對一次帳）。
// 時間到：載入該院區午別的診間清單，依「醫師姓名」找診（明天的診間號可能和今天不同，所以不存診間號），
// 找到的開錄；清單還沒放出或還沒找到的，每 2 分鐘重試，最多到開始後 60 分鐘或收工時間（取較早）。
// 錯過（Chrome 關著、電腦睡眠）：醒來時還沒到收工時間就照樣開錄並註明延遲；已過收工時間就標「已錯過」。
const SCHED_RETRY_MIN = 2, SCHED_WINDOW_MIN = 60;
const sAlarm = (id) => "sched:" + id;
async function schedules() { return get("schedules", {}); }
function mutateSched(fn) {
  return serial(async () => {
    const all = await schedules();
    if ((await fn(all)) === false) return false;
    await set({ schedules: all });
    return true;
  });
}
function hm2ms(day, hm) { return Date.parse(`${day}T${hm}:00+08:00`); }
function schedUntilMs(p) {
  let t = hm2ms(p.day, p.until);
  if (t <= p.at) t += 86400e3;     // 收工時間早於開始時間＝跨午夜
  return t;
}
async function syncSchedAlarms() {
  const all = await schedules();
  for (const p of Object.values(all)) {
    if (p.status !== "waiting") continue;
    const a = await chrome.alarms.get(sAlarm(p.id));
    if (!a) chrome.alarms.create(sAlarm(p.id), { when: Math.max(Date.now() + 1000, p.nextTry || p.at) });
  }
}
function matchClinics(list, names) {
  const hit = [], hitNames = [];
  for (const n of names) {
    const c = list.find((c) => c.doctor === n || c.sub === n);
    if (c) { hit.push(c); hitNames.push(n); }
  }
  return { hit, hitNames };
}
// B 2026-10-22 review：
//  ① 一進來先排「保險鬧鐘」（2 分鐘後），SW 中途被停或丟例外時預約不會卡在等待中、也不會沒鬧鐘
//  ② busy 鎖：執行中不能取消（否則畫面顯示已取消、其實已開錄）；鎖超過 2 分鐘視為上一輪中斷、可以重入
//  ③ 延遲原因只在第一次執行時判斷（睡眠／關機）；重試後才找到就寫第幾次重試
async function runSchedule(id) {
  const p0 = (await schedules())[id];
  if (!p0 || p0.status !== "waiting") return;
  chrome.alarms.create(sAlarm(id), { when: Date.now() + SCHED_RETRY_MIN * 60e3 });
  const now = Date.now();
  let claimed = false;
  await mutateSched((all) => {
    const q = all[id];
    if (!q || q.status !== "waiting" || (q.busy && now - q.busy < SCHED_RETRY_MIN * 60e3)) return false;
    q.busy = now; claimed = true;
  });
  if (!claimed) return;
  const p = (await schedules())[id];
  try {
    const end = Math.min(p.at + SCHED_WINDOW_MIN * 60e3, schedUntilMs(p));
    if (now >= schedUntilMs(p)) {
      await mutateSched((all) => { const q = all[id]; if (!q) return false;
        q.status = "missed"; q.busy = 0; q.note = `已錯過：醒來時已過收工時間 ${q.until}（Chrome 關著或電腦睡眠）`; });
      await chrome.alarms.clear(sAlarm(id));
      return;
    }
    let list = [], err = "";
    try { list = await listClinics(p.site, p.noon); } catch (e) { err = String(e.message || e); }
    const todo = p.names.filter((n) => !(p.started || {})[n]);
    const { hit, hitNames } = matchClinics(list, todo);
    const ids = hit.length ? await startClinics({ site: p.site, noon: p.noon, iv: p.iv, until: p.until, clinics: hit }) : [];
    const tries = (p.tries || 0) + 1;
    const late = !p.nextTry ? Math.round((now - p.at) / 60e3) : 0;
    await mutateSched((all) => {
      const q = all[id]; if (!q) return false;
      q.busy = 0; q.tries = tries;
      if (!q.lateMin && late >= 3) q.lateMin = late;
      q.started = q.started || {};
      hitNames.forEach((n, i) => { q.started[n] = ids[i]; });
      const left = q.names.filter((n) => !q.started[n]);
      const why = q.lateMin ? `（延遲 ${q.lateMin} 分鐘開始：Chrome 關著或電腦睡眠）` : tries > 1 ? `（第 ${tries - 1} 次重試才在清單找到）` : "";
      const n0 = Object.keys(q.started).length;
      if (!left.length) { q.status = "done"; q.note = `已開始記錄 ${q.names.length} 診${why}`; return; }
      if (Date.now() + SCHED_RETRY_MIN * 60e3 > end) {
        q.status = n0 ? "done" : "failed";
        q.note = `${n0 ? `已開始 ${n0} 診；` : ""}找不到：${left.join("、")}（清單裡沒有這些醫師，可能今天沒開診或姓名不同）${err ? "；最近錯誤：" + err : ""}`;
        return;
      }
      q.nextTry = Date.now() + SCHED_RETRY_MIN * 60e3;
      q.note = `${n0 ? `已開始 ${n0} 診；` : ""}還沒找到：${left.join("、")}，${SCHED_RETRY_MIN} 分鐘後再試${err ? "（" + err + "）" : ""}`;
    });
  } catch (e) {
    // 例外也要留紀錄、解鎖；保險鬧鐘已排好，2 分鐘後會再試
    await mutateSched((all) => { const q = all[id]; if (!q) return false; q.busy = 0; q.note = `執行出錯，2 分鐘後再試：${e.message || e}`; });
  }
  const q = (await schedules())[id];
  if (q && q.status === "waiting") chrome.alarms.create(sAlarm(id), { when: q.nextTry || Date.now() + SCHED_RETRY_MIN * 60e3 });
  else await chrome.alarms.clear(sAlarm(id));
}
chrome.alarms.onAlarm.addListener((a) => {
  if (a.name.startsWith("sched:")) runSchedule(a.name.slice(6)).catch((e) => console.warn("sched", e));
});

// ---------- 訊息 ----------
chrome.runtime.onMessage.addListener((msg, sender, reply) => {
  (async () => {
    switch (msg.type) {
      case "tick": await tick("offscreen"); return { ok: true, wait: ticking ? 200 : await nextWait() };
      case "listClinics": return { ok: true, clinics: await listClinics(msg.site, msg.noon) };
      case "start": {
        const ids = await startClinics(msg);
        return { ok: true, ids };
      }
      case "schedAdd": {
        const names = [...new Set((msg.names || []).map((n) => n.trim()).filter(Boolean))];
        if (!names.length) return { ok: false, error: "請至少輸入一位醫師姓名" };
        if (!/^\d{4}-\d{2}-\d{2}$/.test(msg.day) || !/^\d{2}:\d{2}$/.test(msg.time)) return { ok: false, error: "日期或時間格式不對" };
        const at = hm2ms(msg.day, msg.time);
        if (at < Date.now() - 60e3) return { ok: false, error: "開始時間已經過了" };
        const id = `${msg.day}_${msg.site}_${msg.noon}_${at}`;
        let dup = "";
        await mutateSched((all) => {
          // 同日同院區同午別、仍在等待的預約，同一位醫師不能重複預約
          for (const q of Object.values(all)) {
            if (q.status === "waiting" && q.day === msg.day && q.site === msg.site && q.noon === msg.noon) {
              const d = names.filter((n) => q.names.includes(n));
              if (d.length) { dup = d.join("、"); return false; }
            }
          }
          all[id] = { id, day: msg.day, time: msg.time, at, site: msg.site, noon: msg.noon, names,
            iv: msg.iv, until: msg.until, status: "waiting", created: Date.now(), started: {}, note: "" };
        });
        if (dup) return { ok: false, error: `${dup} 在同一天同一診別已經有預約了（要修改請先取消原預約）` };
        chrome.alarms.create(sAlarm(id), { when: Math.max(Date.now() + 1000, at) });
        return { ok: true, id };
      }
      case "schedCancel": {
        let busy = false;
        await mutateSched((all) => { const q = all[msg.id]; if (!q || q.status !== "waiting") return false;
          if (q.busy && Date.now() - q.busy < SCHED_RETRY_MIN * 60e3) { busy = true; return false; }
          q.status = "cancelled"; q.note = "已取消"; });
        if (busy) return { ok: false, error: "這筆預約正在開錄中，請等幾秒再試；已開始的診請在記錄清單按「停止」" };
        await chrome.alarms.clear(sAlarm(msg.id));
        return { ok: true };
      }
      case "schedDelete": {
        await chrome.alarms.clear(sAlarm(msg.id));
        await mutateSched((all) => { delete all[msg.id]; });
        return { ok: true };
      }
      case "stop": {
        await mutate((all) => { if (all[msg.id]) { all[msg.id].status = "stopped"; all[msg.id].stoppedAt = Date.now(); all[msg.id].reason = "手動停止"; } });
        await ensureClock();
        return { ok: true };
      }
      case "resume": {
        await mutate((all) => { const s = all[msg.id]; if (s) { s.status = "running"; s.reason = ""; s.nextAt = 0; if (msg.acceptDoctor) { s.doctor = msg.acceptDoctor; } } });
        await ensureClock(); tick("resume");
        return { ok: true };
      }
      case "delete": {
        await mutate(async (all) => {
          delete all[msg.id];
          await chrome.storage.local.remove(["ctx_" + msg.id, "ev_" + msg.id, "sm_" + msg.id]);
        });
        return { ok: true };
      }
      default: return { ok: false, error: "unknown " + msg.type };
    }
  })().then(reply, (e) => reply({ ok: false, error: String(e.message || e) }));
  return true;
});
