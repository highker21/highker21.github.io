const $ = (id) => document.getElementById(id);
const send = (m) => chrome.runtime.sendMessage(m);
let clinics = [];
let runningLoad = 0;   // 已在記錄中的診換算成「單診每 20 秒」的倍數（renderSessions 更新）
const loadOf = (iv) => 20 / ((iv.min + iv.max) / 2);

const SCHED_TIME = { AM: "08:20", PM: "13:20", Night: "17:50" };   // 開診前約 10 分鐘
function esc(s) { return String(s ?? "").replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c])); }

// 預設：依現在時間猜午別
(function init() {
  const h = new Date().getHours();
  $("noon").value = h < 12 ? "AM" : h < 17 ? "PM" : "Night";
  try { const s = localStorage.getItem("site"); if (s) $("site").value = s; } catch (e) {}
  $("until").value = KMU.DEFAULT_UNTIL[$("noon").value];
  $("noon").onchange = () => { $("until").value = KMU.DEFAULT_UNTIL[$("noon").value]; };
  $("iv").innerHTML = Object.entries(KMU.IV_OPTS).map(([k, o]) => `<option value="${k}">${o.label}</option>`).join("");
  $("iv").value = "20";
  $("iv").onchange = updateStart;
  // 預約：預設明天、該午別開診前 10 分鐘
  $("sIv").innerHTML = $("iv").innerHTML; $("sIv").value = "20";
  const tmr = new Date(Date.now() + 86400e3);
  $("sDay").value = KMU.today(tmr.getTime());
  const schedDefaults = () => { $("sTime").value = SCHED_TIME[$("noon").value]; $("sUntil").value = KMU.DEFAULT_UNTIL[$("noon").value]; };
  schedDefaults();
  $("noon").addEventListener("change", schedDefaults);
  renderSessions();
  setInterval(renderSessions, 5000);
})();

$("load").onclick = async () => {
  const site = $("site").value, noon = $("noon").value;
  try { localStorage.setItem("site", site); } catch (e) {}
  $("loadMsg").className = "msg"; $("loadMsg").textContent = "載入中…";
  $("load").disabled = true;
  const r = await send({ type: "listClinics", site, noon });
  $("load").disabled = false;
  if (!r.ok) { $("loadMsg").className = "msg err"; $("loadMsg").textContent = "載入失敗：" + r.error; return; }
  clinics = r.clinics;
  if (!clinics.length) {
    $("loadMsg").textContent = "這個時段目前沒有任何診間資料（可能還沒放出或今天沒開診）。";
    $("pick").hidden = true; return;
  }
  $("loadMsg").textContent = `${KMU.SITES[site].name}・${KMU.NOONS[noon]}：共 ${clinics.length} 診`;
  $("pick").hidden = false;
  renderList();
};

function renderList() {
  const q = $("filter").value.trim();
  const shown = clinics.filter((c) => !q || (c.doctor + c.sub + c.dname).includes(q));
  $("list").innerHTML = shown.map((c) => `
    <label><input type="checkbox" value="${esc(c.dept)}">
      <span class="dn"><span class="doc">${esc(c.doctor || "（未提供）")}</span>
        ${c.sub ? `<span class="sub">代診 ${esc(c.sub)}</span>` : ""}<br>
        <span class="cur">${esc(c.dname)}</span></span>
      <span class="cur">目前 ${esc(c.current || "-")} 號</span></label>`).join("") || '<div class="msg" style="padding:8px">沒有符合的診間</div>';
  $("list").querySelectorAll("input").forEach((i) => (i.onchange = () => { updateStart(); fillSchedNames(); }));
  updateStart();
}
// ② 勾選的醫師帶入預約姓名欄（代診優先，因為頁面上看到的是代診醫師）
function fillSchedNames() {
  const names = [...$("list").querySelectorAll("input:checked")]
    .map((i) => clinics.find((c) => c.dept === i.value)).map((c) => c.sub || c.doctor).filter(Boolean);
  $("sNames").value = [...new Set(names)].join("、");
}

$("sAdd").onclick = async () => {
  const names = $("sNames").value.split(/[、,，\s]+/).filter(Boolean);
  const r = await send({ type: "schedAdd", site: $("site").value, noon: $("noon").value, day: $("sDay").value, time: $("sTime").value,
    names, iv: $("sIv").value, until: $("sUntil").value || KMU.DEFAULT_UNTIL[$("noon").value] });
  $("sMsg").className = r.ok ? "msg" : "msg err";
  $("sMsg").textContent = r.ok ? `已預約：${$("sDay").value} ${$("sTime").value} ${KMU.SITES[$("site").value].name}・${KMU.NOONS[$("noon").value]}・${names.join("、")}` : "預約失敗：" + r.error;
  renderScheds();
};

async function renderScheds() {
  const all = (await chrome.storage.local.get("schedules")).schedules || {};
  const list = Object.values(all).sort((a, b) => a.at - b.at);
  const st = { waiting: "等待中", done: "已開錄", failed: "未開錄", missed: "已錯過", cancelled: "已取消" };
  $("scheds").innerHTML = list.map((p) => {
    const acts = p.status === "waiting"
      ? `<button data-s="cancel" data-id="${esc(p.id)}">取消預約</button>`
      : `<button data-s="del" data-id="${esc(p.id)}">移除</button>`;
    return `<div class="sess ${p.status === "waiting" ? "paused" : p.status === "done" ? "running" : "stopped"}">
      <div class="t"><span class="dot"></span>${esc(p.names.join("、"))}　<small>${st[p.status] || p.status}</small></div>
      <div class="m">${esc(p.day)} ${esc(p.time)} 開始・${KMU.SITES[p.site].name}・${KMU.NOONS[p.noon]}・收工 ${esc(p.until)}・${KMU.ivText(KMU.IV_OPTS[p.iv] || KMU.IV_OPTS["20"])}
      ${p.note ? `<br><span class="${p.status === "failed" || p.status === "missed" ? "bad" : ""}">${esc(p.note)}</span>` : ""}</div>
      <div class="acts">${acts}</div></div>`;
  }).join("");
  $("scheds").querySelectorAll("button").forEach((b) => (b.onclick = async () => {
    await send({ type: b.dataset.s === "cancel" ? "schedCancel" : "schedDelete", id: b.dataset.id });
    renderScheds();
  }));
}
$("filter").oninput = renderList;
function updateStart() {
  const n = $("list").querySelectorAll("input:checked").length;
  $("start").disabled = !n;
  // 對站方的請求量＝診數 × (20 ÷ 平均間隔)，以 20 秒單診為 1 倍
  // 要加上已在記錄中的診，否則分次加診會低估（B 2026-10-16 review）
  const load = Math.max(n, 1) * loadOf(KMU.IV_OPTS[$("iv").value]) + runningLoad;
  $("ivMsg").textContent = load > 2.5
    ? `連同記錄中的診，對醫院網站的查詢量約為「單診每 20 秒」的 ${load.toFixed(1)} 倍；量太大可能被網站擋掉，請斟酌。`
    : "";
}

$("start").onclick = async () => {
  const picked = [...$("list").querySelectorAll("input:checked")].map((i) => clinics.find((c) => c.dept === i.value));
  const r = await send({ type: "start", site: $("site").value, noon: $("noon").value, iv: $("iv").value, until: $("until").value || KMU.DEFAULT_UNTIL[$("noon").value], clinics: picked });
  $("startMsg").className = r.ok ? "msg" : "msg err";
  $("startMsg").textContent = r.ok ? `已開始記錄 ${r.ids.length} 診` : "開始失敗：" + r.error;
  renderSessions();
};

async function renderSessions() {
  renderScheds();
  const all = (await chrome.storage.local.get("sessions")).sessions || {};
  const list = Object.values(all).sort((a, b) => b.created - a.created);
  runningLoad = list.filter((s) => s.status === "running").reduce((t, s) => t + loadOf(KMU.ivOf(s)), 0);
  if ($("list").children.length) updateStart();
  if (!list.length) { $("sessions").innerHTML = '<div class="msg">尚無記錄</div>'; return; }
  const now = Date.now();
  $("sessions").innerHTML = list.map((s) => {
    const st = { running: "記錄中", paused: "已暫停", stopped: "已結束" }[s.status];
    const ago = s.lastOk ? Math.round((now - s.lastOk) / 1000) : null;
    let m = `${s.day}・${KMU.SITES[s.site].name}・${KMU.NOONS[s.noon]}・收工 ${s.until}・${KMU.ivText(KMU.ivOf(s))}`;
    if (s.status === "running") {
      m += `<br>${s.calling ? `目前叫號 ${esc(s.calling)}・` : ""}${s.rows ? `清單 ${s.rows} 號・` : ""}上次抓取 ${ago === null ? "—" : ago + " 秒前"}`;
      const late = Math.max(60, KMU.ivOf(s).max * 3);
      if (ago !== null && ago > late) m += ` <span class="bad">（超過 ${late} 秒沒抓到，請確認網路）</span>`;
    }
    if (s.note) m += `<br><span class="warn">${esc(s.note)}</span>`;
    if (s.lastErr) m += `<br><span class="bad">最近錯誤：${esc(s.lastErr)}</span>`;
    if (s.reason) m += `<br><span class="${s.status === "paused" ? "bad" : ""}">${esc(s.reason)}</span>`;
    const acts = [`<button data-a="report" data-id="${esc(s.id)}">報表</button>`];
    if (s.status === "running") acts.push(`<button data-a="stop" data-id="${esc(s.id)}">停止</button>`);
    if (s.status === "paused") acts.push(`<button data-a="resume" data-id="${esc(s.id)}">確認無誤，繼續記錄</button>`);
    if (s.status !== "running") acts.push(`<button data-a="delete" data-id="${esc(s.id)}">刪除</button>`);
    return `<div class="sess ${s.status}"><div class="t"><span class="dot"></span>${esc(s.doctor || s.pageDoctor || "")}　${esc(s.dname)}　<small>${st}</small></div>
      <div class="m">${m}</div><div class="acts">${acts.join("")}</div></div>`;
  }).join("");
  $("sessions").querySelectorAll("button").forEach((b) => (b.onclick = () => act(b.dataset.a, b.dataset.id, all[b.dataset.id])));
}

async function act(a, id, s) {
  if (a === "report") return chrome.tabs.create({ url: "report.html?id=" + encodeURIComponent(id) });
  if (a === "stop") await send({ type: "stop", id });
  if (a === "resume") {
    const doc = (s.reason.match(/醫師是「(.+?)」/) || [])[1];
    await send({ type: "resume", id, acceptDoctor: doc });
  }
  if (a === "delete") {
    if (!confirmDelete(id)) return;
    await send({ type: "delete", id });
  }
  renderSessions();
}
// 刪除要按兩次（避免誤刪；不用 confirm() 對話框）
const pendingDel = {};
function confirmDelete(id) {
  if (pendingDel[id] && Date.now() - pendingDel[id] < 4000) return true;
  pendingDel[id] = Date.now();
  $("sessMsg").textContent = "再按一次「刪除」確認（資料無法復原）";
  setTimeout(() => ($("sessMsg").textContent = ""), 4000);
  return false;
}
