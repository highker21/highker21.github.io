// 時鐘：叫醒 service worker；哪個診到期該抓由 SW 依各自的間隔決定（v1.1.0）。
// SW 回覆「下一次要等幾毫秒」（最多 1 秒），讓到期的診準時抓；SW 沒回應就 1 秒後再叫。
// offscreen 只能用 chrome.runtime。
async function loop() {
  let wait = 1000;
  try { const r = await chrome.runtime.sendMessage({ type: "tick" }); if (r && r.wait) wait = r.wait; } catch (e) {}
  setTimeout(loop, wait);
}
loop();
