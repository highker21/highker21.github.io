// 高醫門診進度記錄 —— 核心邏輯（解析、狀態機、匯出統計）
// 移植自 ~/claudecode/scripts/clinic_recorder.py（2026-10-15）。
// 純函式，不碰 chrome.*，同時給 service worker、報表頁、node 測試使用。
// ⚠️ 各段的「為什麼」都在 Python 原檔的註解裡，這裡只留最必要的提醒。

const KMU = (() => {
  const SITES = {
    gangshan: { name: "高醫岡山醫院", base: "https://www.kmugh.org.tw/Web/WebRegistration" },
    kmuh:     { name: "高醫附設中和紀念醫院", base: "https://www.kmuh.org.tw/Web/WebRegistration" },
    siaogang: { name: "小港醫院", base: "https://www.kmsh.org.tw/Web/WebRegistration" },
  };
  const NOONS = { AM: "上午診", PM: "下午診", Night: "夜間診" };
  // 預設自動收工時間（沿用 crontab：AM 16:00、PM 21:00、Night 23:59）
  const DEFAULT_UNTIL = { AM: "16:00", PM: "21:00", Night: "23:59" };

  const S_SEEN = "已報到", S_IN = "看診中", S_MISSED = "過號";
  const LEFT_DONE = "（已離開清單）", LEFT_NOVISIT = "（未看診即離開）";
  const INTERVAL = 20;           // 秒；網站自己 60 秒，20 秒是準確度與擾動的折衷
  const STALE_MIN = 30;
  const GAP_WARN = 30;           // 取樣間隔超過這個秒數就算「取樣變慢」（20 秒模式；其他模式＝上限×1.5）
  const GAP_LOST = 90;           // 超過這個秒數就算「這段沒有記到」（至少 90，或上限×3）
  // 取樣間隔選項（v1.1.0，老闆 2026-10-15 要求可調）。每個診開始時決定、存進 session.iv，記錄中不變。
  // 隨機模式每一輪重新抽。舊記錄沒有 iv → 一律當 20 秒。
  const IV_OPTS = {
    "20":   { min: 20, max: 20, label: "每 20 秒（預設）" },
    "10":   { min: 10, max: 10, label: "每 10 秒" },
    "5-10": { min: 5,  max: 10, label: "5～10 秒隨機" },
    "30":   { min: 30, max: 30, label: "每 30 秒" },
  };
  const FLASH_SEC = 30;          // 空叫門檻下限 30 秒（＝20 秒模式的 1.5 倍）；報表實際用 max(30, 上限×1.5)，短間隔不縮小、30 秒模式放寬到 45
  function ivOf(s) { return (s && s.iv && s.iv.max) ? s.iv : { min: INTERVAL, max: INTERVAL }; }
  function ivText(iv) { return iv.min === iv.max ? `每 ${iv.min} 秒` : `${iv.min}～${iv.max} 秒隨機`; }
  function drawIv(iv) { return iv.min + Math.random() * (iv.max - iv.min); }   // 秒

  // ---------- 時間（一律台灣時間 +08:00） ----------
  function iso(ms) {
    const d = new Date(ms + 8 * 3600e3);
    return d.toISOString().replace("Z", "+08:00");
  }
  // 保留微秒（Python 記錄器的時間戳有 6 位小數；只取到毫秒會讓分鐘數在捨入邊界差 0.1）
  function T(s) {
    const m = s.match(/\.(\d+)/);
    const base = Date.parse(s.replace(/\.(\d+)/, ""));
    return m ? base + Number("0." + m[1]) * 1000 : base;
  }
  function hms(s) { return s ? iso(T(s)).slice(11, 19) : ""; }
  function today(ms) { return iso(ms).slice(0, 10); }
  // Python round() 是銀行家捨入；用同樣規則，重放比對才會逐字一致
  //   Python 依 double 的「精確十進位值」判斷是否剛好落在 .x5；toFixed(30) 可取得該值
  function round1(x) {
    const neg = x < 0, s = Math.abs(x).toFixed(30);
    const [ip, fp] = s.split(".");
    const keep = Number(ip + "." + fp[0]);
    const rest = fp.slice(1);
    let up;
    if (/^50*$/.test(rest)) up = Number(fp[0]) % 2 === 1;   // 剛好一半 → 取偶數
    else up = rest[0] >= "5";
    const r = up ? Math.round((keep + 0.1) * 10) / 10 : keep;
    return neg ? -r : r;
  }
  function mins(a, b) { return (a && b) ? round1((T(b) - T(a)) / 60000) : ""; }

  // ---------- 解析 ----------
  // ⚠️ 不能用 [^)]*：小港的診名帶括號（「心臟血管內科(1)」），會在診名裡就停下、整頁 0 列。
  //    onclick="..." 內不會有雙引號，所以用 [^"]*。
  const ROW = /onclick="fn_ShowProcessBySeqNo\([^"]*?,\s*'(\d+)'\)".*?monospace;">\s*(\d+)\s*<\/div>.*?background-color:\s*(#[0-9a-fA-F]{3,6});\s*">\s*([^<]+?)\s*<\/div>/gs;
  const UPDATED = /更新時間\s*[:：]\s*([\d/]+\s[\d:]+)/;
  const CALLING = /目前叫號<\/div>.*?monospace;">\s*(\d+)\s*<\/span>/s;

  function stripTags(html) {
    return html.replace(/<script[\s\S]*?<\/script>/g, "").replace(/<[^>]+>/g, " ").replace(/\s+/g, " ");
  }
  function doctorOf(html) {
    const m = stripTags(html).match(/([一-鿿]{2,4})\s*醫師/);
    return m ? m[1] : null;
  }
  // 回傳 null＝頁面上沒有任何號碼（還沒開診／已收診／抓錯端點）
  function parseDetail(html) {
    const seq = {};
    let n = 0;
    for (const r of html.matchAll(ROW)) { seq[r[2]] = r[4]; n++; }
    if (!n) return null;
    const u = html.match(UPDATED), c = html.match(CALLING);
    return { site_updated: u ? u[1] : null, calling: c ? c[1] : null, seq };
  }
  // GetSeqDetial 的診間卡片：data-dept / data-dname / 醫師 / 代診醫師 / 目前號碼
  function parseClinicList(html) {
    const out = [];
    const parts = html.split(/<div class="[^"]*c_table"/).slice(1);
    for (const p of parts) {
      const dept = (p.match(/data-dept="([^"]*)"/) || [])[1];
      const dname = (p.match(/data-dname="([^"]*)"/) || [])[1];
      if (!dept) continue;
      const t = stripTags(p);
      const doc = (t.match(/醫師\s+([一-鿿A-Za-z．·]{2,8})\s+代診醫師/) || [])[1] || "";
      const sub = (t.match(/代診醫師\s+(\S+)/) || [])[1] || "-";
      const cur = (t.match(/(\d+)\s*$/) || [])[1] || "";
      out.push({ dept, dname, doctor: doc, sub: sub === "-" ? "" : sub, current: cur });
    }
    return out;
  }

  // ---------- 狀態機：一輪輪詢（對應 Python record() 迴圈本體） ----------
  // ctx = { state:{no:rec}, prev:{no:status}, missing:{}, firstMissing:{}, refRows, truncStreak }
  // 回傳本輪新增的事件陣列（呼叫端負責存檔）。
  function newCtx() {
    return { state: {}, prev: {}, missing: {}, firstMissing: {}, refRows: null, truncStreak: 0 };
  }
  function step(ctx, snap, tsIso) {
    const events = [];
    const { state, prev } = ctx;
    for (const [no, status] of Object.entries(snap.seq)) {
      const rec = state[no] || (state[no] = { no, status: null, checkin: null, start: null, end: null,
        missed: null, last_in: null, left_at: null, left_from: null });
      const old = prev[no] === undefined ? null : prev[no];
      if (status === old) {
        if (status === S_IN) rec.last_in = tsIso;
        continue;
      }
      rec.status = status;
      if (status === S_SEEN && !rec.checkin) rec.checkin = tsIso;
      else if (status === S_IN) { if (!rec.start) rec.start = tsIso; rec.last_in = tsIso; }
      else if (status === S_MISSED) rec.missed = tsIso;
      if (old === S_IN && status !== S_IN && !rec.end) rec.end = tsIso;
      events.push({ ts: tsIso, no, from: old, to: status, site_updated: snap.site_updated, calling: snap.calling });
      prev[no] = status;
    }
    for (const [no, status] of Object.entries(snap.seq)) {
      if (status === S_IN && state[no].end) state[no].end = null;   // 撤銷誤判的完成
    }
    // 號碼消失：①整批縮水（相對上一次被接受的輪次 <70%）跳過；②單號連續消失兩次才採信
    const rowsNow = Object.keys(snap.seq).length;
    const truncated = ctx.refRows !== null && rowsNow < ctx.refRows * 0.7 && ctx.truncStreak < 5;
    if (truncated) {
      ctx.truncStreak += 1;
    } else {
      ctx.truncStreak = 0;
      ctx.refRows = rowsNow;
      for (const [no, rec] of Object.entries(state)) {
        if (no in snap.seq) {
          if ((ctx.missing[no] || 0) >= 2) { rec.left_at = null; rec.left_from = null; }
          ctx.missing[no] = 0;
          continue;
        }
        if (!(ctx.missing[no] || 0)) ctx.firstMissing[no] = tsIso;
        ctx.missing[no] = (ctx.missing[no] || 0) + 1;
        if (ctx.missing[no] !== 2) continue;
        const leftFrom = prev[no] === undefined ? null : prev[no];
        let leftTo;
        if (leftFrom === S_IN) { if (!rec.end) rec.end = ctx.firstMissing[no]; leftTo = LEFT_DONE; }
        else leftTo = LEFT_NOVISIT;
        rec.left_at = ctx.firstMissing[no];
        rec.left_from = leftFrom;
        events.push({ ts: ctx.firstMissing[no], no, from: leftFrom, to: leftTo,
          site_updated: snap.site_updated, calling: snap.calling });
        prev[no] = leftTo;
      }
    }
    return { events, truncated };
  }

  // ---------- 匯出（對應 Python segments_from_events + export） ----------
  function segmentsFromEvents(events, intervalHint, flashMax = intervalHint * 1.5) {
    const byNo = {};
    for (const e of events) (byNo[e.no] = byNo[e.no] || []).push(e);
    const out = {};
    for (const [no, es0] of Object.entries(byNo)) {
      const es = es0.slice().sort((a, b) => (a.ts < b.ts ? -1 : a.ts > b.ts ? 1 : 0));
      const segs = []; let start = null;
      for (const e of es) {
        if (e.to === S_IN) start = e.ts;
        else if (start !== null) { segs.push([start, e.ts]); start = null; }
      }
      if (start !== null) segs.push([start, null]);
      const flashes = segs.filter((s) => s[1] && (T(s[1]) - T(s[0])) / 1000 <= flashMax);
      const real = segs.filter((s) => !flashes.includes(s));
      const chosen = real.length ? real[real.length - 1] : null;
      let checkin = null;
      for (const e of es) {
        if (e.to !== S_SEEN) continue;
        if (!chosen || T(e.ts) <= T(chosen[0])) checkin = e.ts;
      }
      out[no] = { segs, flashes, chosen, checkin, last_status: es.length ? es[es.length - 1].to : null };
    }
    return out;
  }

  // flashMax：空叫門檻（秒）。Python 是 intervalHint×1.5；新模式固定傳 FLASH_SEC，舊資料（20 秒）兩者相同
  function exportRows(events, state, intervalHint = INTERVAL, flashMax) {
    const rebuilt = segmentsFromEvents(events, intervalHint, flashMax);
    let recEnd = null;
    for (const e of events) if (e.ts) recEnd = e.ts;   // 事件檔最後一筆＝收工
    const allStarts = Object.values(rebuilt).filter((b) => b.chosen).map((b) => b.chosen[0])
      .sort((a, b) => T(a) - T(b));
    const rows = [];
    const nos = Object.keys(state).sort((a, b) => +a - +b);
    for (const no of nos) {
      const r = state[no];
      const b = rebuilt[no] || { segs: [], flashes: [], chosen: null, checkin: null, last_status: null };
      const ch = b.chosen, ci = b.checkin;
      const start = ch ? ch[0] : null;
      let end = ch ? ch[1] : null;
      let notesExtra = null;
      if (start && !end && r.end) {
        if (T(r.end) > T(start)) { end = r.end; notesExtra = "完成時間取自state"; }
      }
      let wait = mins(ci, start);
      if (wait !== "" && wait < 0) wait = "異常(負值)";
      const notes = [];
      if (b.flashes.length) notes.push(`空叫${b.flashes.length}次`);
      if (ch && !ci) notes.push("報到未觀測");
      if (notesExtra) notes.push(notesExtra);
      if (ch && !end) {
        const gap = (recEnd && start) ? (T(recEnd) - T(start)) / 60000 : null;
        const hasLater = !!start && allStarts.some((s) => T(s) > T(start));
        if (hasLater || (gap !== null && gap > STALE_MIN * 3)) {
          notes.push(`看診中途失去追蹤${gap !== null ? `（距收工 ${gap.toFixed(0)} 分）` : ""}`);
        } else notes.push("收工時未結束");
      }
      if (b.segs.length && !ch) notes.push("僅空叫未實際看診");
      if (!b.segs.length) notes.push("未被叫號");
      if (b.last_status === LEFT_NOVISIT) notes.push(`未看診即離開（消失前：${r.left_from || "不明"}）`);
      let estEnd = "", estMin = "";
      if (start && !end) {
        const later = allStarts.filter((s) => T(s) > T(start));
        const ref = later.length ? later[0] : (recEnd && T(recEnd) > T(start) ? recEnd : null);
        if (ref) { estEnd = hms(ref); estMin = mins(start, ref); }
      }
      rows.push({
        "看診號": no, "報到時間": hms(ci), "開始看診": hms(start), "完成時間": hms(end),
        "候診分鐘": wait, "看診分鐘": mins(start, end),
        "過號時間": hms(r.missed), "離開清單時間": hms(r.left_at),
        "最終狀態": r.status || "", "被叫次數": b.segs.length, "空叫次數": b.flashes.length,
        "資料品質": notes.length ? notes.join("／") : "正常",
        "完成時間誤差(秒)": end ? intervalHint : "",
        "推估完成時間": estEnd, "推估看診分鐘": estMin,
      });
    }
    return rows;
  }

  function median(xs) {
    if (!xs.length) return null;
    const v = xs.slice().sort((a, b) => a - b), n = v.length;
    return n % 2 ? v[(n - 1) / 2] : (v[n / 2 - 1] + v[n / 2]) / 2;
  }
  function summarize(rows) {
    const num = (k) => rows.map((r) => r[k]).filter((x) => typeof x === "number");
    const visit = num("看診分鐘"), wait = num("候診分鐘");
    return {
      total: rows.length,
      checkedIn: rows.filter((r) => r["報到時間"]).length,
      entered: rows.filter((r) => r["開始看診"]).length,
      measured: visit.length,
      visitMedian: median(visit), visitMean: visit.length ? visit.reduce((a, b) => a + b, 0) / visit.length : null,
      visitMin: visit.length ? Math.min(...visit) : null, visitMax: visit.length ? Math.max(...visit) : null,
      waitMedian: median(wait), waitMean: wait.length ? wait.reduce((a, b) => a + b, 0) / wait.length : null,
      waitMax: wait.length ? Math.max(...wait) : null,
      flashOnly: rows.filter((r) => r["資料品質"].includes("僅空叫")).map((r) => r["看診號"]),
      estimated: rows.filter((r) => r["推估完成時間"]).map((r) => r["看診號"]),
      // ⚠️ 「未看診即離開」這個標籤沿用 Python CSV（逐格一致），但實際資料裡多數是
      //    「看完 → 過號 → 消失」，有進過診間。摘要只算真的沒進過診間的，否則會誤導。
      leftNoVisit: rows.filter((r) => r["資料品質"].includes("未看診即離開") && !r["開始看診"]).map((r) => r["看診號"]),
      waitOver2h: rows.filter((r) => typeof r["候診分鐘"] === "number" && r["候診分鐘"] > 120).map((r) => r["看診號"]),
    };
  }

  // 取樣品質：samples＝每次「成功抓到頁面」的時間（ms）
  function sampleQuality(samples, iv = { min: INTERVAL, max: INTERVAL }) {
    const warn = iv.max * 1.5, lost = Math.max(GAP_LOST, iv.max * 3);
    if (samples.length < 2) return { n: samples.length, median: null, max: null, slow: 0, gaps: [], warn, lost };
    const d = [];
    const gaps = [];
    for (let i = 1; i < samples.length; i++) {
      const s = (samples[i] - samples[i - 1]) / 1000;
      d.push(s);
      if (s > lost) gaps.push([samples[i - 1], samples[i]]);
    }
    return { n: samples.length, median: median(d), max: Math.max(...d), slow: d.filter((x) => x > warn).length, gaps, warn, lost };
  }

  return { SITES, NOONS, DEFAULT_UNTIL, INTERVAL, GAP_WARN, GAP_LOST, IV_OPTS, FLASH_SEC, ivOf, ivText, drawIv, S_IN, S_SEEN, S_MISSED,
    iso, hms, today, round1, mins, doctorOf, parseDetail, parseClinicList, newCtx, step,
    segmentsFromEvents, exportRows, summarize, sampleQuality, median };
})();

if (typeof module !== "undefined") module.exports = KMU;
