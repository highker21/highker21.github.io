// 中文檢驗報告：體系病歷「檢驗」頁（/WEB/MRN/InspectionReport）。跑在頁面主環境（world: MAIN），才讀得到院內表格每列的資料（jQuery data）。
// 只讀：只送院內頁面本來就會送的明細查詢（同一個登入），不改任何東西、不連院外、不存檔。
// 病人資料只放在預覽框的記憶體裡，關掉預覽就清掉；身分證字號（院內查詢參數 Patient_ID）只用在查詢，不會出現在報告上。
(function () {
  "use strict";
  if (window.top !== window) return;
  if (!/\/mrn\/inspectionreport\/?$/i.test(location.pathname)) return;
  const Z = window.LABZH;
  if (!Z || window.__labzhLoaded) return;
  window.__labzhLoaded = true;
  const DICT = Z.compileDict(window.LABZH_DICT || []);
  const DETAIL = "/WEB/MRN/InspectionReport/GetInspectionReportDetail";
  const LOGIN = /高醫體系資訊系統入口網|資訊系統入口網|AuthServer|\/Account\/Login/i;
  const $ = (s, r) => (r || document).querySelector(s);
  const el = (tag, attrs, ...kids) => {
    const e = document.createElement(tag);
    for (const [k, v] of Object.entries(attrs || {})) { if (k === "text") e.textContent = v; else if (k === "style") e.style.cssText = v; else if (k.startsWith("on")) e.addEventListener(k.slice(2), v); else e.setAttribute(k, v); }
    for (const k of kids) if (k != null) e.append(k);
    return e;
  };

  // ---------- 小提示 ----------
  let toastEl = null, toastT = 0;
  function toast(msg, ms) {
    if (!toastEl) { toastEl = el("div", { id: "labzh-toast", style: "position:fixed;right:16px;bottom:16px;z-index:2147483600;max-width:440px;padding:10px 14px;border-radius:8px;background:#1d2b3a;color:#fff;font:14px/1.5 'Microsoft JhengHei',sans-serif;box-shadow:0 4px 16px rgba(0,0,0,.3)" }); document.body.append(toastEl); }
    toastEl.textContent = msg; toastEl.style.display = "block";
    clearTimeout(toastT); if (ms) toastT = setTimeout(() => { toastEl.style.display = "none"; }, ms);
  }

  // ---------- 讀頁面 ----------
  const inputByLabel = (re) => {
    const g = [...document.querySelectorAll(".input-group")].find((x) => re.test(((x.querySelector(".input-group-text") || {}).textContent || "").replace(/\s+/g, "")));
    const i = g && g.querySelector("input");
    return i ? String(i.value || i.getAttribute("value") || "").trim() : "";
  };
  // 病歷號、姓名要讀得到才印（讀不到寧可不印）
  function patient() {
    const c = $("#CurrentChartno");
    const chart = c ? String(c.value || c.getAttribute("value") || "").trim() : "";
    const name = inputByLabel(/^姓名$/);
    if (!/^[A-Za-z0-9]{4,12}$/.test(chart) || !name) throw new Error("讀不到這一頁的病歷號或姓名，為避免印錯人，這次不產生報告。");
    const idEl = $("#inPATIENT_ID_NO");
    const pid = idEl ? String(idEl.value || idEl.getAttribute("value") || "").trim().toUpperCase() : "";
    return { chart, name, pid };
  }
  function formDates() {
    try { if (typeof window.GetInspectionReportFormParameter === "function") { const p = window.GetInspectionReportFormParameter(); return { startdate: p.startdate, enddate: p.enddate }; } } catch (e) { /* 退回自己讀 */ }
    const f = $("#inspectionReportForm"), d = {};
    if (f) for (const [k, v] of new FormData(f).entries()) d[k] = String(v);
    if (d.CustromDate && d.CustromDate.includes(",")) { const p = d.CustromDate.split(","); return { startdate: p[0], enddate: p[1] }; }
    return { startdate: d.NQuery_startdate, enddate: d.NQuery_enddate };
  }
  const parse = (v) => { if (v && typeof v === "object") return v; try { return JSON.parse(v || "[]"); } catch (e) { return []; } };
  // 目前這一天報告清單的每一列：優先用院內表格每列的 rowData；沒有 jQuery 時照順序對回左邊選中日期的 data-report（院內 loadRptTable 依序建表）
  function reportRows() {
    const trs = [...document.querySelectorAll("#InspectionReportTable tbody tr")];
    const act = $("#home .date-item.active") || $(".date-item.active");
    const fallback = act ? parse(act.getAttribute("data-report")) : [];
    return trs.map((tr, i) => {
      let row = null;
      try { if (window.jQuery) row = window.jQuery(tr).data("rowData") || null; } catch (e) { row = null; }
      if (!row && Array.isArray(fallback) && fallback.length === trs.length) row = fallback[i];
      const chk = tr.querySelector(".row-check");
      return { row, checked: !!(chk && chk.checked), disabled: !!(chk && chk.disabled) };
    }).filter((x) => x.row && x.row.HOSP_CODE !== "CloudEMR");
  }
  // 每筆報告的 Patient_ID 要和頁面上的身分證一致（兩邊都有時才比；不一致就不查，B 審 s2）
  function samePatient(rows, pt) {
    if (!pt.pid) return;
    for (const r of rows) { const id = String((r && r.Patient_ID) || "").trim().toUpperCase(); if (id && id !== pt.pid) throw new Error("報告清單和這一頁的病人對不上，為避免印錯人，這次不產生報告。請重新整理檢驗頁再試。"); }
  }
  // 本頁院區：院內只允許勾選本院區的報告（其他院區勾選框停用）；先看清單裡可勾的那幾列，沒有再看網址（B 審 M1）
  const HOST_HOSP = { "intraweb.kmugh.org.tw": "KMUGH", "intraweb.server.kmuh.org.tw": "KMUH" };
  function localHosp() {
    const ok = reportRows().filter((x) => !x.disabled).map((x) => String(x.row.HOSP_CODE || ""));
    return ok.find(Boolean) || HOST_HOSP[location.hostname.toLowerCase()] || "";
  }
  function detailBody(row, fd, mode) {
    let ctl = row.CHARGE_TIME_LIST;
    if (typeof ctl === "string") { try { ctl = JSON.parse(ctl); } catch (e) { ctl = []; } }
    return { in_HospCode: row.HOSP_CODE, in_ChargeDate: row.charge_date, in_ChargeTimeList: ctl || [], in_PatientID: row.Patient_ID, in_CKNO: row.ckno,
      in_RequestCode: row.request_code, in_kind: row["報告類別"] || "", in_BeginDate: fd.startdate, in_EndDate: fd.enddate, in_TableStatus: mode };
  }
  async function post(body) {
    const r = await fetch(DETAIL, { method: "POST", credentials: "include", headers: { "Content-Type": "application/json; charset=utf-8" }, body: JSON.stringify(body),
      signal: AbortSignal.timeout ? AbortSignal.timeout(20000) : undefined });
    if (r.status !== 200) throw new Error("院內回應 " + r.status);
    const t = await r.text();
    if (/<html/i.test(t.slice(0, 500)) && LOGIN.test(t.slice(0, 3000))) throw new Error("院內登入已逾時，請重新登入後再試。");
    try { return JSON.parse(t); } catch (e) { throw new Error("院內回應格式不對"); }
  }
  const nowText = () => { const d = new Date(), p = (n) => String(n).padStart(2, "0"); return `${d.getFullYear()}/${p(d.getMonth() + 1)}/${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}`; };
  const hospName = (rows) => [...new Set(rows.map((r) => String(r["院區"] || "").trim()).filter(Boolean))].join("、");

  // ---------- 預覽框（關掉就整個移除） ----------
  let overlay = null;
  function closeOverlay() { if (overlay) { overlay.remove(); overlay = null; } document.removeEventListener("keydown", onKey, true); }
  function onKey(e) { if (e.key === "Escape" && overlay) { e.stopPropagation(); closeOverlay(); } }
  function shell(title) {
    closeOverlay();
    const body = el("div", { class: "labzh-body", style: "flex:1;min-height:0;display:flex;flex-direction:column" });
    const bar = el("div", { class: "labzh-bar", style: "display:flex;gap:8px;align-items:center;padding:8px 12px;border-bottom:1px solid #ccc;background:#f6f7f9" },
      el("b", { text: title, style: "font-size:16px;margin-right:auto" }));
    const box = el("div", { style: "position:absolute;inset:3vh 4vw;background:#fff;border-radius:8px;display:flex;flex-direction:column;overflow:hidden;box-shadow:0 8px 40px rgba(0,0,0,.4)" }, bar, body);
    overlay = el("div", { id: "labzh-overlay", style: "position:fixed;inset:0;z-index:2147483500;background:rgba(0,0,0,.45);font:14px/1.5 'Microsoft JhengHei',sans-serif;color:#111" }, box);
    document.body.append(overlay);
    document.addEventListener("keydown", onKey, true);
    return { bar, body };
  }
  const btn = (text, onclick, primary) => el("button", { type: "button", text, onclick, style: `padding:5px 14px;font-size:14px;border-radius:5px;cursor:pointer;border:1px solid ${primary ? "#0b6e4f" : "#888"};background:${primary ? "#0b6e4f" : "#fff"};color:${primary ? "#fff" : "#111"}` });
  function preview(title, html) {
    const { bar, body } = shell(title);
    const fr = el("iframe", { id: "labzh-frame", title: "預覽", sandbox: "allow-same-origin allow-modals", style: "flex:1;border:0;width:100%;background:#fff" });
    body.append(fr);
    const d = fr.contentDocument; d.open(); d.write(html); d.close();
    bar.append(el("span", { text: "確認內容後再按列印", style: "color:#555" }), btn("🖨 列印", () => fr.contentWindow.print(), true), btn("關閉", closeOverlay));
  }

  // ---------- ① 某一天的中文版 ----------
  let busy = false;
  async function onDay() {
    if (busy) return; busy = true;
    try {
      const pt = patient();
      const all = reportRows();
      if (!all.length) throw new Error("請先在左邊點一個抽血日期，等報告清單出來再按。");
      const ok = all.filter((x) => !x.disabled), skipped = all.length - ok.length;
      if (!ok.length) throw new Error("這一天的報告都是其他院區的，院方規定不能在這裡列印。");
      const picked = ok.some((x) => x.checked) ? ok.filter((x) => x.checked) : ok;   // 沒勾就是當天全部（老闆 msg810）
      samePatient(picked.map((x) => x.row), pt);
      toast(`正在讀取 ${picked.length} 份報告…`);
      const fd = formDates(), reports = [];
      for (const x of picked) {
        const kind = String(x.row["報告類別"] || "");
        const res = await post(detailBody(x.row, fd, "Single"));
        reports.push({ kind, hosp: String(x.row["院區"] || ""), rows: Z.parseDetail(res, kind) });
      }
      const m = Z.buildReport({ dict: DICT, patient: pt, reports, now: nowText(), notes: skipped ? [`這一天另有 ${skipped} 份其他院區的報告，依院方規定未列入。`] : [] });
      if (!m.count) throw new Error("這幾份報告沒有讀到檢驗項目。");
      toast(`共 ${m.count} 項` + (m.unknown ? `，其中 ${m.unknown} 項沒有中文對照（保留英文）` : "") + (skipped ? `；${skipped} 份其他院區報告依院方規定略過` : ""), 7000);
      preview("檢驗報告（中文說明版）・預覽", Z.renderHTML(m));
    } catch (e) { toast(String((e && e.message) || e), 9000); }
    finally { busy = false; }
  }

  // ---------- ② 多項目一年變化 ----------
  const span = (fd) => {
    const a = Z.dayKey(fd.startdate), b = Z.dayKey(fd.enddate);
    if (!a || !b) return { a, b, days: 0 };
    const t = (k) => Date.UTC(+k.slice(0, 4), +k.slice(4, 6) - 1, +k.slice(6, 8));
    return { a, b, days: Math.round((t(b) - t(a)) / 86400000) };
  };
  async function onTrend() {
    if (busy) return; busy = true;
    try {
      const pt = patient(), fd = formDates(), sp = span(fd), here = localHosp();
      if (!here) throw new Error("讀不到這一頁的院區，這次不產生報告。");
      // 每種報告類別取查詢區間內最新那筆，用院內「整合」模式查一次就是跨日期的表；只用本院區的報告（同①的院方列印規定）
      const byKind = new Map(), older = new Map();
      let otherHosp = 0;
      const dates = [...document.querySelectorAll(".date-item[data-datekey]")].map((e) => ({ key: String(e.getAttribute("data-datekey") || ""), reports: parse(e.getAttribute("data-report")) }))
        .filter((d) => /^\d{8}$/.test(d.key) && Array.isArray(d.reports)).sort((a, b) => (a.key < b.key ? 1 : -1));
      for (const d of dates) for (const r of d.reports) {
        const k = String((r && r["報告類別"]) || "");
        if (!k || r.HOSP_CODE === "CloudEMR" || Z.NO_TREND.test(k)) continue;
        if (String(r.HOSP_CODE || "") !== here) { otherHosp++; continue; }
        if (!byKind.has(k)) byKind.set(k, r); else { if (!older.has(k)) older.set(k, []); older.get(k).push(r); }
      }
      if (!byKind.size) throw new Error("查詢區間內沒有本院區可以畫變化的檢驗。");
      samePatient([...byKind.values()], pt);
      toast("正在讀取查詢區間內的檢驗…");
      const results = [], latest = new Map(), hosps = [];
      for (const [kind, r] of byKind) {
        results.push({ kind, res: await post(detailBody(r, fd, "Mix")) });
        hosps.push(r);
        for (const x of Z.parseDetail(await post(detailBody(r, fd, "Single")), kind)) {   // 單位、參考範圍取最近一次
          const k = x.name + "@" + (Z.isUrine(x) ? "U" : "B");
          if (!latest.has(k)) latest.set(k, x);
        }
      }
      const items = Z.mixMerge(results);
      if (!items.length) throw new Error("院內沒有回傳可以畫變化的資料。");
      const keyOf = (it) => it.name + "@" + (Z.isUrine(it) ? "U" : "B");
      // 最新一份沒有這項時，往前同類別再找最多 3 份補單位和參考範圍（B 審 m3）
      for (const [kind, list] of older) {
        for (const r of list.slice(0, 3)) {
          if (!items.some((it) => it.kind === kind && !latest.has(keyOf(it)))) break;
          for (const x of Z.parseDetail(await post(detailBody(r, fd, "Single")), kind)) { const k = x.name + "@" + (Z.isUrine(x) ? "U" : "B"); if (!latest.has(k)) latest.set(k, x); }
        }
      }
      for (const it of items) { const s = latest.get(keyOf(it)); it.unit = s ? s.unit : ""; it.ref = s ? s.ref : ""; it.code = s ? s.code : ""; }
      toast("", 1);
      picker(pt, items, sp, hospName(hosps), otherHosp);
    } catch (e) { toast(String((e && e.message) || e), 9000); }
    finally { busy = false; }
  }
  function picker(pt, items, sp, hosp, otherHosp) {
    const { bar, body } = shell("檢驗數值變化・選項目");
    const groups = new Map();
    for (const it of items) {
      const e = Z.lookup(DICT, it), cat = e ? e.cat : Z.UNKNOWN_CAT;
      it.label = (e ? e.zh + (Z.isUrine(it) && e.cat !== "尿液" ? "（尿）" : "") + "　" : "") + it.name;
      it.n = Object.keys(it.values).length;
      if (!groups.has(cat)) groups.set(cat, []);
      groups.get(cat).push(it);
    }
    const short = sp.days && sp.days < 360;
    const head = el("div", { style: "padding:8px 14px;border-bottom:1px solid #eee" },
      el("div", { text: `查詢區間：${Z.fmtDay(sp.a)}～${Z.fmtDay(sp.b)}　勾選要印的項目（可多選），每項會有一張折線圖和數值表。` }),
      short ? el("div", { style: "color:#b00020;font-weight:700", text: "目前查詢區間不到一年。要看一年內的變化，請先關掉這個視窗，把院內「查詢區間」改成 1 年，再按一次「📈 多項變化」。" }) : null);
    const list = el("div", { style: "flex:1;overflow:auto;padding:6px 14px;columns:2 320px;column-gap:24px" });
    for (const cat of [...Z.CAT_ORDER, Z.UNKNOWN_CAT].filter((c) => groups.has(c))) {
      list.append(el("div", { style: "break-inside:avoid;margin:8px 0 2px;font-weight:700;border-bottom:1px solid #ddd", text: cat }));
      for (const it of groups.get(cat)) {
        const cb = el("input", { type: "checkbox", "data-id": it.id });
        list.append(el("label", { style: "display:block;break-inside:avoid;padding:2px 0;cursor:pointer" }, cb, " " + it.label, el("span", { style: "color:#777", text: `（${it.n} 次）` })));
      }
    }
    body.append(head, list);
    const go = () => {
      const ids = new Set([...list.querySelectorAll("input:checked")].map((c) => c.getAttribute("data-id")));
      const chosen = items.filter((it) => ids.has(it.id));
      if (!chosen.length) return toast("請至少勾一個項目。", 4000);
      const m = Z.buildTrend({ dict: DICT, patient: pt, hosp, items: chosen, from: sp.a, to: sp.b, now: nowText(), notes: otherHosp ? ["查詢區間內其他院區的報告，依院方規定未列入。"] : [] });
      preview("檢驗數值變化（中文說明版）・預覽", Z.renderTrendHTML(m));
    };
    bar.append(btn("產生報告", go, true), btn("關閉", closeOverlay));
  }

  // ---------- 按鈕：放在院內「列印」鈕旁邊 ----------
  function addButtons() {
    if ($("#labzh-day")) return true;
    const anchor = $("#printReport");
    if (!anchor) return false;
    const mk = (id, text, title, fn) => el("button", { type: "button", id, class: "btn btn-sm", title, text, onclick: (e) => { e.preventDefault(); fn(); },
      style: "margin-left:6px;padding:2px 10px;border:1px solid #0b6e4f;border-radius:4px;background:#e9f6f0;color:#0b4f3a;cursor:pointer;white-space:nowrap" });
    const b2 = mk("labzh-trend", "📈 多項變化", "勾選多個項目，印出查詢區間內每次的數值與折線圖（中文說明版）", onTrend);
    const b1 = mk("labzh-day", "🖨 中文版", "把這一天的檢驗報告整理成中文說明版（沒勾就是當天全部）", onDay);
    anchor.insertAdjacentElement("afterend", b2);
    anchor.insertAdjacentElement("afterend", b1);
    return true;
  }
  if (!addButtons()) {
    const mo = new MutationObserver(() => { if (addButtons()) mo.disconnect(); });
    mo.observe(document.documentElement, { childList: true, subtree: true });
    setTimeout(() => mo.disconnect(), 30000);
  }
})();
