// KMU Note 門診頁（OPD_Main）：右上角加「門診工作台」按鈕，打開後把左邊查出來的門診清單一位一位讀：
// 上一次門診 SOAP、目前用藥、最近一次抽血、眼底與甲狀腺檢查、本季疫苗。v0.4.0 起是右側側邊欄（msg607）。
// 只讀病歷；唯一會按的是院內「延長時間」鈕（自動延長，可關）。讀過的結果放記憶體＋chrome.storage.session（瀏覽器關掉就清空）。
// 讀取方式照急診工作台：病歷頁在隱藏、sandbox、credentialless（自己一套 cookie）的框裡開，不會切換您自己開著的病歷分頁的「目前病人」。
(function () {
  if (window.top !== window || document.getElementById("opdwb-host")) return;
  const C = OPDWB, H = C.hospOf(location.hostname);
  if (!H) return;
  const ORIGIN = location.origin;
  const VERSION = chrome.runtime.getManifest().version;
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

  // ---------- 畫面 ----------
  const host = document.createElement("div");
  host.id = "opdwb-host";
  document.documentElement.appendChild(host);
  const root = host.attachShadow({ mode: "open" });
  const css = document.createElement("style");
  css.textContent = `
  :host{all:initial}
  *{box-sizing:border-box;font-family:"PingFang TC","Microsoft JhengHei","Noto Sans TC",sans-serif}
  .fab{position:fixed;top:var(--opdwb-top,8px);right:12px;z-index:1045;background:#1f5f8b;color:#fff;border:0;border-radius:6px;padding:7px 14px;font-size:14px;font-weight:600;cursor:pointer;box-shadow:0 2px 6px rgba(0,0,0,.25)}
  .fab:hover{background:#174a6d}
  .side{position:fixed;top:var(--opdwb-top0,0px);right:0;bottom:0;z-index:1045;background:#fff;border-left:1px solid #b8c4ce;box-shadow:-4px 0 16px rgba(0,0,0,.12);display:none;flex-direction:column;color:#1b2631;font-size:14px}
  .side.open{display:flex}
  .side.locked{display:none!important}
  .fab.locked{display:none!important}
  .grip{position:absolute;left:-4px;top:0;bottom:0;width:8px;cursor:col-resize;z-index:2}
  .grip:hover,.grip.drag{background:rgba(31,95,139,.25)}
  .hd{display:flex;align-items:center;gap:8px;padding:8px 12px;border-bottom:1px solid #dde3ea;background:#f4f7fa;flex-wrap:wrap}
  .hd h2{margin:0;font-size:17px}
  .hd2{padding:4px 12px;border-bottom:1px solid #eef1f4;font-size:12px;color:#34495e;background:#fbfcfd}
  .ext{cursor:pointer;user-select:none}
  .extst{color:#5d6d7e}
  .extst.warn{color:#b03a2e;font-weight:700}
  .hd .meta{color:#5d6d7e;font-size:13px}
  .hd .sp{flex:1}
  button.b{border:1px solid #1f5f8b;background:#fff;color:#1f5f8b;border-radius:5px;padding:5px 12px;font-size:13px;cursor:pointer}
  button.b.pri{background:#1f5f8b;color:#fff}
  button.b:disabled{opacity:.45;cursor:default}
  .st{padding:6px 14px;font-size:13px;color:#34495e;border-bottom:1px solid #eef1f4}
  .st.warn{background:#fff4e5;color:#8a4b00}
  .wrap{flex:1;overflow:auto;padding:8px;background:#f4f6f8}
  .card{background:#fff;border:1px solid #dde3ea;border-radius:6px;margin-bottom:8px;font-size:13px;line-height:1.45}
  .card.hl{border:2px solid #1f5f8b;box-shadow:0 0 0 3px rgba(31,95,139,.15)}
  .card.firstrow{background:#fdebd0}
  .ch{display:flex;align-items:flex-start;gap:8px;padding:6px 10px;border-bottom:1px solid #eef1f4}
  .ch .seq{font-weight:700;color:#1f5f8b;min-width:22px}
  .ch .pt{flex:1}
  .ch .pt b{font-size:14px}
  .ch .stc{text-align:right;max-width:45%}
  .secs{display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:0}
  .sec{padding:6px 10px;border-top:1px solid #f0f2f4;min-width:0}
  .sec.wide{grid-column:1/-1}
  .soap3{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:6px}
  .soap3 .col{background:#fafbfc;border:1px solid #eef1f4;border-radius:4px;padding:4px 6px;max-height:220px;overflow:auto;white-space:pre-wrap;min-width:0}
  .soap3 .col .t{font-weight:700;color:#1f5f8b;margin-bottom:2px}
  table.dt{border-collapse:collapse;width:100%;font-size:12.5px}
  table.dt th{background:#eef2f6;color:#5d6d7e;font-weight:600;text-align:left;padding:2px 6px;border-bottom:1px solid #dde3ea}
  table.dt td{padding:2px 6px;border-bottom:1px solid #f0f2f4;vertical-align:top}
  .vno{background:#fdebd0;color:#935116;font-weight:700;padding:0 6px;border-radius:3px}
  .sec .lb{font-size:11px;color:#5d6d7e;font-weight:700;margin-bottom:2px}
  .empty{padding:16px;color:#7f8c8d}
  .muted{color:#7f8c8d}
  .err{color:#b03a2e}
  .soap{max-height:220px;overflow:auto;white-space:pre-wrap;background:#fafbfc;border:1px solid #eef1f4;border-radius:4px;padding:4px 6px}
  .soap .t{font-weight:700;color:#1f5f8b}
  table.lt{border-collapse:collapse;width:100%;margin:2px 0;font-size:12.5px}
  table.lt th{background:#eef2f6;color:#5d6d7e;font-weight:600;text-align:left;padding:2px 6px;border-bottom:1px solid #dde3ea}
  table.lt td{padding:2px 6px;border-bottom:1px solid #f0f2f4;vertical-align:top}
  table.lt td.n{color:#34495e}
  .mtw{overflow-x:auto;max-width:100%}
  table.mt th,table.mt td{white-space:nowrap}
  table.mt td.hi{color:#c0392b;font-weight:700}
  table.mt th:first-child,table.mt td:first-child{position:sticky;left:0;background:#fff;z-index:1}
  .calc{font-size:10.5px;color:#7d3c98;background:#f4ecf7;border-radius:3px;padding:0 3px;margin-left:3px}
  table.lt td.ref{color:#95a5a6;font-size:11.5px}
  .lab.hi .v{color:#c0392b;font-weight:700}
  .lab.crit .v{color:#fff;background:#c0392b;padding:0 3px;border-radius:3px}
  details summary{cursor:pointer;color:#1f5f8b;font-size:12px}
  .ok{color:#1e8449;font-weight:600}
  .no{color:#b9770e;font-weight:600}
  .firstbg{background:#fdebd0}
  .first{color:#935116;font-weight:700;font-size:14px}
  .tag{display:inline-block;background:#eaf2f8;color:#1f5f8b;border-radius:3px;padding:0 4px;margin-left:4px;font-size:11px}
  .drug{max-height:220px;overflow:auto}
  .drug div{margin-bottom:2px}
  .old{color:#7f8c8d;font-size:12px}
  .small{font-size:12px}
  .ft{padding:6px 14px;font-size:12px;color:#7f8c8d;border-top:1px solid #eef1f4}
  `;
  root.appendChild(css);
  const el = (tag, attrs, ...kids) => {
    const e = document.createElement(tag);
    for (const [k, v] of Object.entries(attrs || {})) { if (k === "class") e.className = v; else if (k === "text") e.textContent = v; else if (k.startsWith("on")) e.addEventListener(k.slice(2), v); else e.setAttribute(k, v); }
    for (const k of kids) if (k != null) e.appendChild(typeof k === "string" ? document.createTextNode(k) : k);
    return e;
  };
  const fab = el("button", { class: "fab", text: "門診工作台" });
  const ov = el("div", { class: "side" });   // 右側固定側邊欄（老闆 msg607：不要浮動視窗擋住原本畫面），原本的頁面往左縮
  const grip = el("div", { class: "grip", title: "拖拉調整寬度" });
  const bRead = el("button", { class: "b pri", text: "讀取未讀的", title: "只讀還沒讀過的病人（讀過的會記住，關掉瀏覽器才清空）" });
  const bAll = el("button", { class: "b", text: "全部重讀" });
  const bClear = el("button", { class: "b", text: "清除暫存", title: "清掉這台電腦瀏覽器裡暫存的讀取結果" });
  const ext = el("label", { class: "ext", title: "倒數剩 29 分鐘時替您按院內原本的「延長時間」鈕；畫面已鎖定時不動作" }, el("input", { type: "checkbox" }), " 自動延長 ", el("span", { class: "extst" }));
  const bStop = el("button", { class: "b", text: "停止" });
  const bClose = el("button", { class: "b", text: "收起", title: "收起側邊欄（讀到的資料保留）" });
  const bList = el("button", { class: "b", text: "更新清單", title: "重新讀左邊的門診清單（已讀到的資料會清掉）" });
  const bCsv = el("button", { class: "b", text: "儲存 CSV", title: "把目前讀到的資料存成 CSV（含病人資料，請勿放進雲端資料夾）" });
  const meta = el("span", { class: "meta" });
  const st = el("div", { class: "st", text: "按「讀取全部」：依左邊目前查出的門診清單，一位一位讀。" });
  const tbody = el("div", { class: "list" });
  ov.append(grip, el("div", { class: "hd" }, el("h2", { text: "門診工作台" }), meta, el("span", { class: "sp" }), bRead, bAll, bStop, bCsv, bList, bClear, bClose),
    el("div", { class: "hd2" }, ext),
    st, el("div", { class: "wrap" }, tbody),
    el("div", { class: "ft", text: `v${VERSION}｜只讀病歷（只會按院內延長鈕）、不連院外；讀過的結果暫存在瀏覽器記憶體，關掉瀏覽器或按「清除暫存」就清空。請以院內病歷為準。「儲存 CSV」的檔案含病人資料，請勿放進雲端資料夾。` }));
  root.append(fab, ov);
  // ---------- 側邊欄：固定在右邊，原本的頁面讓出寬度（html 加右邊界）；寬度可拖拉，只記在記憶體 ----------
  let width = Math.round(Math.min(Math.max(window.innerWidth * 0.42, 380), 760)), prevMargin = null;
  const html = document.documentElement;
  // 院內上方工具列是 fixed-top（倒數、延長、登出在右端）：側邊欄從工具列下緣開始，不蓋住它（B 審 Minor 4）
  function topbarBottom() { const n = document.querySelector("nav.fixed-top, nav.app-topbar"); if (!n) return 0; const r = n.getBoundingClientRect(); return r.height && r.bottom > 0 && r.bottom < window.innerHeight / 3 ? Math.round(r.bottom) : 0; }
  function applyTop() { const b = topbarBottom(); host.style.setProperty("--opdwb-top0", b + "px"); host.style.setProperty("--opdwb-top", (b ? b + 6 : 8) + "px"); }
  window.addEventListener("resize", applyTop); setInterval(applyTop, 3000);
  function applyWidth() {
    ov.style.width = width + "px";
    if (ov.classList.contains("open")) html.style.setProperty("margin-right", width + "px", "important");
  }
  function openSide() {
    if (prevMargin === null) prevMargin = { v: html.style.getPropertyValue("margin-right"), p: html.style.getPropertyPriority("margin-right") };
    ov.classList.add("open"); fab.style.display = "none"; applyTop(); applyWidth();
    window.dispatchEvent(new Event("resize"));   // 讓院內頁面依新寬度重排
  }
  function closeSide() {
    ov.classList.remove("open"); fab.style.display = "";
    if (prevMargin) { if (prevMargin.v) html.style.setProperty("margin-right", prevMargin.v, prevMargin.p); else html.style.removeProperty("margin-right"); }
    prevMargin = null;
    window.dispatchEvent(new Event("resize"));
  }
  fab.addEventListener("click", () => { openSide(); refreshList(); });
  bClose.addEventListener("click", closeSide);
  bList.addEventListener("click", () => refreshList());
  grip.addEventListener("mousedown", (e) => {
    e.preventDefault(); grip.classList.add("drag");
    const move = (m) => { width = Math.round(Math.min(Math.max(window.innerWidth - m.clientX, 320), window.innerWidth * 0.8)); applyWidth(); };
    const up = () => { grip.classList.remove("drag"); window.removeEventListener("mousemove", move, true); window.removeEventListener("mouseup", up, true); window.dispatchEvent(new Event("resize")); };
    window.addEventListener("mousemove", move, true); window.addEventListener("mouseup", up, true);
  });
  // 在左邊門診清單點某位病人 → 側邊欄捲到那張卡片並標亮（只聽點擊，不改院內表格、不擋院內動作）
  document.addEventListener("click", (e) => {
    if (!ov.classList.contains("open")) return;
    const tr = e.target && e.target.closest ? e.target.closest("#OPDPatientListTable tr") : null;
    if (!tr) return;
    const td = tr.querySelectorAll("td");
    const p0 = td.length >= 10 ? C.patientFromCells([...td].map((x) => x.textContent)) : null;
    if (!p0) return;
    focusChart(p0.chart);
  }, true);
  function focusChart(chart) {
    let first = null;
    for (const p of patients) {
      const on = !!p.card && C.sameChart(p.chart, chart);
      if (p.card) p.card.classList.toggle("hl", on);
      if (on && !first) first = p.card;
    }
    if (first) first.scrollIntoView({ block: "start", behavior: "smooth" });
  }

  // ---------- 門診清單（讀院內頁面已經查出來的表，不另外送查詢） ----------
  let patients = [];
  function doctorOnPage() { const e = document.querySelector("#oSelectedDoctor"); return e ? String(e.textContent || "").trim() : ""; }
  function deptNameOf(code) {
    if (!code) return "";
    for (const o of document.querySelectorAll("#DeptList option")) if (String(o.getAttribute("data-value") || o.id || "").trim() === code) return String(o.getAttribute("value") || "").trim();
    return "";
  }
  function readList() {
    const t = document.querySelector("#OPDPatientListTable");
    if (!t) return [];
    const out = [];
    for (const tr of t.querySelectorAll("tr")) {
      const td = tr.querySelectorAll("td");
      if (td.length < 10) continue;
      const p = C.patientFromCells([...td].map((x) => x.textContent));
      if (!p) continue;
      // 這一診的主治醫師（列上的 data-vsname；沒有就用頁面上方選的主治）與科別名稱（科別清單 datalist）→ SOAP 優先順序用（老闆 msg579）
      p.doctor = String(tr.getAttribute("data-vsname") || "").trim() || doctorOnPage();
      p.deptName = deptNameOf(p.dept);
      out.push(p);
    }
    return C.sortPatients(out);
  }
  // ---------- 讀過的不重讀（老闆 msg609）：結果放記憶體＋chrome.storage.session（只在記憶體、瀏覽器關掉就清空、網頁讀不到）----------
  // 門診頁重新整理、從病歷頁回來都還在；12 小時後失效。鍵＝院區｜看診日｜病歷號
  const MAX_AGE = 12 * 3600 * 1000, mem = new Map();
  // 鍵含登入帳號、科別、主治（B 審 Minor 1：同一位病人在兩個診、共用電腦換人登入時不能拿到別份）
  let loginCache = "";
  const loginUser = () => loginCache || (loginCache = C.loginUserFrom([...document.scripts].map((x) => x.textContent || "").join("\n")));
  const keyOf = (p) => ["opdwb", H.name, loginUser(), C.ymd(p.visitDate) || "", p.dept || "", p.doctor || "", p.chart].join("|");
  const store = (() => { try { return chrome.storage && chrome.storage.session ? chrome.storage.session : null; } catch (e) { return null; } })();
  async function cacheGet(keys) { if (!store || !keys.length) return {}; try { return (await store.get(keys)) || {}; } catch (e) { return {}; } }
  // 過期的順手刪掉（B 審 Minor 2）
  async function cachePurge() {
    for (const [k, v] of mem) if (!v || Date.now() - v.t >= MAX_AGE) mem.delete(k);
    if (!store) return;
    try { const all = (await store.get(null)) || {}; const old = Object.keys(all).filter((k) => k.startsWith("opdwb|") && (!all[k] || Date.now() - all[k].t >= MAX_AGE)); if (old.length) await store.remove(old); } catch (e) { /* 忽略 */ }
  }
  function cacheSet(p) {
    const v = { t: Date.now(), d: p.data };
    mem.set(keyOf(p), v);
    if (store) try { store.set({ [keyOf(p)]: v }).catch(() => {}); } catch (e) { /* 只留記憶體 */ }
  }
  async function cacheClear() {
    mem.clear();
    if (!store) return;
    try { const all = await store.get(null); const ks = Object.keys(all || {}).filter((k) => k.startsWith("opdwb|")); if (ks.length) await store.remove(ks); } catch (e) { /* 忽略 */ }
  }
  const done = (p) => !!(p.data && /^完成/.test(p.data.status || ""));
  let listSeq = 0, lastSig = "", pendingRefresh = false;
  async function refreshList() {
    if (running) { pendingRefresh = true; return; }
    const seq = ++listSeq;
    const old = new Map(patients.filter((p) => p.data).map((p) => [keyOf(p), { t: p.cachedAt || Date.now(), d: p.data }]));
    const next = readList();
    const want = next.map(keyOf).filter((k) => !old.has(k) && !mem.has(k));
    await cachePurge();
    const got = await cacheGet(want);
    if (seq !== listSeq) return;
    if (running) { pendingRefresh = true; return; }   // B 審 Minor 3：讀取中就等讀完再更新，不要丟掉這次

    // 清單沒變（院內表格只是重畫）就不重建卡片，免得展開的內容、捲動位置跑掉
    const sig = next.map((p) => keyOf(p) + "#" + p.seq).join(",");
    if (sig && sig === lastSig && patients.length && patients.every((p) => p.card && p.card.isConnected)) return;
    lastSig = sig;
    patients = next;
    meta.textContent = `${H.name}｜${patients.length} 位`;
    tbody.textContent = "";
    if (!patients.length) { tbody.append(el("div", { class: "empty", text: "左邊還沒有門診清單：請先選日期、科別、午別按查詢，再按「更新清單」或「讀取全部」。" })); return; }
    // 每位病人一張卡片；各區塊依序（data-col：0 序、1 病人、2 SOAP、3 用藥、4 抽血、5 檢查、6 疫苗、7 狀態）
    for (const p of patients) {
      const box = (col, cls, text) => el("div", { class: cls, "data-col": String(col), text });
      const cells = { soap: box(2, "muted", "—"), drug: box(3, "muted", "—"), labs: box(4, "muted", "—"), fundus: box(5, "muted", "—"), vac: box(6, "muted", "—"), st: box(7, "muted small", "待讀取") };
      const again = el("button", { class: "b small", text: "重讀", style: "margin-top:4px" });
      again.addEventListener("click", () => readOne(p, true));
      cells.st.append(el("br"), again);
      const sec = (label, body, wide) => el("div", { class: "sec" + (wide ? " wide" : "") }, el("div", { class: "lb", text: label }), body);
      const card = el("div", { class: "card" },
        el("div", { class: "ch" }, el("span", { class: "seq", "data-col": "0", text: p.seq }),
          el("div", { class: "pt", "data-col": "1" }, el("b", { text: p.name }), " ", el("span", { class: "muted small", text: [p.sex, p.age, p.chart].filter(Boolean).join("｜") })),
          el("div", { class: "stc" }, cells.st)),
        el("div", { class: "secs" }, sec("上次門診 SOAP", cells.soap, true), sec("目前用藥", cells.drug, true), sec("抽血（一年內）", cells.labs, true), sec("眼底（一年內）／甲狀腺檢查", cells.fundus), sec("疫苗（本季）", cells.vac)));
      tbody.append(card);
      p.cells = cells; p.card = card;   // 每一張卡片自己的格子（同一位出現兩次也各自更新，B 審 Minor）
      const c = old.get(keyOf(p)) || mem.get(keyOf(p)) || got[keyOf(p)];   // 都已過濾過期
      if (c && c.d && Date.now() - c.t < MAX_AGE) { p.data = c.d; p.cachedAt = c.t; mem.set(keyOf(p), c); renderData(p, true); }
    }
    setButtons();
  }

  // ---------- 畫各欄 ----------
  function fill(td, ...kids) { td.textContent = ""; td.className = ""; for (const k of kids) if (k) td.append(k); }
  function showSoap(td, r) {
    if (r.error) return fill(td, el("span", { class: "err", text: r.error }));
    if (r.data.none) {   // 沒有老闆、也沒有本科的門診（老闆 msg579／580：顯示「本科初診」，用不同底色）
      fill(td, el("span", { class: "first", text: "本科初診" })); td.className = "firstbg";
      const card = td.closest(".card"); if (card) card.classList.add("firstrow");   // 整張卡片換底色
      return;
    }
    const d = r.data, box = el("div", { class: "soap" });
    for (const s of d.soap) { if (s.title) box.append(el("div", { class: "t", text: s.title })); if (s.text) box.append(el("div", { text: s.text })); }
    if (!d.soap.length) box.append(el("span", { class: "muted", text: "這次門診沒有 SOAP 內容" }));
    // S、A、P 三欄（老闆 msg629）；O 與完整 SOAP 收在下面。院內標題都認不得時直接顯示完整 SOAP，不讓內容不見
    // 院內實際是兩段（msg635）：S、A&P
    const cols = C.soapColumns(d.soap), ap = [cols.A, cols.P].filter(Boolean).join("\n"), any = cols.S || ap;
    const col = (label, text) => el("div", { class: "col" }, el("div", { class: "t", text: label }), text ? text : el("span", { class: "muted", text: "—" }));
    const main = any ? el("div", { class: "soap3" }, col("S", cols.S), col("A&P", ap)) : box;
    const more = any ? el("details", {}, el("summary", { text: "O 與完整 SOAP" }), box) : null;
    fill(td, el("div", { class: "small muted", text: `${d.visit.date}｜${d.visit.dept}｜${d.visit.doctor}` }, d.visit.tier === "dept" ? el("span", { class: "tag", text: "本科其他醫師" }) : null), main, more,
      d.dx && d.dx.length ? el("div", { class: "small", text: "診斷：" + d.dx.slice(0, 4).join("；") }) : null);
  }
  // 目前用藥（用藥頁，含雲端藥歷）：還沒到期或到期 30 天內；外院的標院所名稱
  function showMeds(td, r) {
    if (r.error) return fill(td, el("span", { class: "err", text: r.error }));
    if (r.data.format) return fill(td, el("span", { class: "err", text: "用藥頁格式不符" }));
    const ds = r.data.list || [];
    const more = r.data.expired ? el("div", { class: "small muted", text: `另有 ${r.data.expired} 項已到期超過 30 天` }) : null;
    if (!ds.length) return fill(td, el("span", { class: "muted", text: "近 30 天沒有用藥紀錄" }), more);
    // 預設只列藥名，用法、到期、來源收在「展開」（msg635）
    const names = el("div", { class: "drug" }, ...ds.map((x) => el("div", { text: C.splitDrug(x.drug).name })));
    fill(td, el("div", { class: "small muted", text: `${ds.length} 項（含雲端藥歷）` + (r.data.lastRx ? (r.data.fromVisit ? `｜上次門診 ${r.data.lastRx} 的藥全列` : `｜本院上次處方 ${r.data.lastRx}`) : "") }),
      names, el("details", {}, el("summary", { text: "展開：用法、到期、來源" }), el("table", { class: "dt" }, el("thead", {}, el("tr", {}, ...["藥名", "用法", "到期／剩餘", "來源"].map((h) => el("th", { text: h })))),
        el("tbody", {}, ...ds.map((x) => { const sp = C.splitDrug(x.drug);
          return el("tr", { title: [x.atc, x.code, x.start + "～" + x.end, x.days && "應領 " + x.days + " 天"].filter(Boolean).join("｜") },
            el("td", { text: sp.name }), el("td", { text: sp.use }),
            el("td", {}, el("span", { class: x.left > 0 ? "ok" : "muted", text: x.left > 0 ? "剩 " + x.left + " 天" : x.end + " 到期" })),
            el("td", {}, x.cloud ? el("span", { class: "tag", text: x.hosp || "外院" }) : el("span", { class: "muted", text: "本院" }))); })))), more);
  }
  // 抽血用表格（老闆 msg625）：項目｜結果｜參考值；異常紅字、危急值紅底
  function labRow(x, dateNote) {
    const cls = "lab" + (x.critical ? " crit" : x.flag ? " hi" : "");
    // 參考值不佔欄（msg635），放在滑鼠停留的提示裡
    return el("tr", { class: cls, title: [x.ref && "參考值 " + x.ref, x.kind, x.sampled && "採檢 " + x.sampled, x.reported && "報告 " + x.reported].filter(Boolean).join("｜") },
      el("td", { class: "n" }, x.name, dateNote ? el("span", { class: "old", text: "（" + dateNote + "）" }) : null),
      el("td", {}, el("span", { class: "v", text: x.value + (x.flag ? " " + x.flag : "") + (x.critical ? "（危急）" : "") })));
  }
  const labTable = (rows) => el("table", { class: "lt" }, el("thead", {}, el("tr", {}, el("th", { text: "項目" }), el("th", { text: "結果" }))), el("tbody", {}, ...rows));
  // 一年內「項目 × 日期」（msg658）：欄是每次抽血的日期（民國），重點項目與外掛計算在上，其他收起；表格可左右捲，預設捲到最新
  function showLabsMix(td, d) {
    const days = d.dates;
    const head = () => el("thead", {}, el("tr", {}, el("th", { text: "項目" }), ...days.map((k) => el("th", { text: C.rocLabel(k) }))));
    const row = (label, values, notes, calc) => el("tr", {}, el("td", { class: "n" }, label, calc ? el("span", { class: "calc", text: " 外掛計算" }) : null),
      ...days.map((k) => { const v = values[k] || ""; return el("td", { class: /\s(H|L|HH|LL)$/.test(v) ? "hi" : "", title: (notes && notes[k]) || "" }, v); }));
    const table = (rows) => { const w = el("div", { class: "mtw" }, el("table", { class: "lt mt" }, head(), el("tbody", {}, ...rows))); setTimeout(() => { w.scrollLeft = w.scrollWidth; }, 0); return w; };
    const key = d.items.filter((x) => x.key), rest = d.items.filter((x) => !x.key);
    const rows = [...key.map((x) => row(x.label, x.values)), ...(d.derived || []).map((x) => row(x.name, x.values, x.notes, true))];
    fill(td, el("div", { class: "small muted", text: `${C.rocLabel(C.ymd(d.from)) || d.from} 起一年內 ${days.length} 次｜${(d.kinds || []).join("、")}` }),
      rows.length ? table(rows) : null,
      d.missing && d.missing.length ? el("div", { class: "old", text: "一年內查無 " + d.missing.join("、") }) : null,
      rest.length ? el("details", {}, el("summary", { text: `其他 ${rest.length} 項` }), table(rest.map((x) => row(x.label, x.values)))) : null);
  }
  function showLabs(td, r) {
    if (r.error) return fill(td, el("span", { class: "err", text: r.error }));
    if (r.data.none) return fill(td, el("span", { class: "muted", text: "查無抽血報告" }));
    if (r.data.mix) return showLabsMix(td, r.data);
    const key = r.data.lines.filter((x) => x.key), rest = r.data.lines.filter((x) => !x.key);
    const abn = rest.filter((x) => x.flag || x.critical), normal = rest.filter((x) => !x.flag && !x.critical);
    // 甲狀腺病人：最近一次沒驗到的 TSH／free T4（甲癌加 Tg）往前找到的值，標日期（老闆 msg583）
    const ex = (r.data.extra || []).filter((x) => !C.isUACRPart(x)), miss = r.data.missing || [];   // 算 UACR 用的尿白蛋白、尿肌酸酐不另列（在 UACR 的提示裡）
    // 外掛自己算的 eGFR、UACR（msg639）：名稱後標「外掛計算」，滑鼠停留看公式與用到的數值
    const der = (r.data.derived || []).map((x) => { const tr = labRow(x, x.date && x.date !== r.data.date ? x.date : ""); tr.title = x.note; tr.querySelector("td.n").append(el("span", { class: "calc", text: " 外掛計算" })); return tr; });
    const rows = [...key.map((x) => labRow(x)), ...der, ...ex.map((x) => labRow(x, x.date)), ...abn.map((x) => labRow(x))];
    const det = normal.length ? el("details", {}, el("summary", { text: `其他 ${normal.length} 項正常` }), labTable(normal.map((x) => labRow(x)))) : null;
    const missNote = miss.length ? el("div", { class: "old", text: `另查 ${r.data.looked || 0} 次檢驗仍查無 ` + miss.join("、") + (miss.includes("eGFR") ? "（找不到血清 Cr，無法計算 eGFR）" : "") + (miss.includes("UACR") ? "（找不到同一張尿液報告的白蛋白與肌酸酐）" : "") }) : null;
    fill(td, el("div", { class: "small muted", text: r.data.date + "｜" + r.data.kinds.join("、") }), rows.length ? labTable(rows) : null, missNote, det);
  }
  function showFundus(td, r) {
    if (r.error) return fill(td, el("span", { class: "err", text: r.error }));
    if (r.data.format) return fill(td, el("span", { class: "err", text: "檢查報告頁格式不符" }));
    const note = r.data.range === "預設" ? el("div", { class: "small muted", text: "（院內預設查詢區間）" })
      : r.data.range === "未確認" ? el("div", { class: "small err", text: "（查詢區間未確認，可能只查了院內預設區間）" })
      : el("div", { class: "small muted", text: `（檢查報告查${r.data.range === "全部" ? "全部年份" : "近 2 年"}，共 ${r.data.rows} 筆）` });
    const f = r.data.latest;
    const fundus = !f ? [el("div", {}, el("span", { class: "muted small", text: "眼底：" }), el("span", { class: "no", text: "一年內無" }))]
      : [el("div", {}, el("span", { class: "muted small", text: "眼底：" }), el("span", { class: "ok", text: f.date + (r.data.count > 1 ? `（一年內 ${r.data.count} 次）` : "") })),
        el("details", {}, el("summary", { text: "報告全文" }), el("div", { class: "soap", text: f.report }))];   // 只顯示日期，全文收起（msg629）
    // 甲狀腺結節病人（老闆 msg587）：最近一次甲狀腺超音波、細胞學
    const thy = r.data.thy, part = (label, x, text) => [el("div", { style: "margin-top:6px" }, el("span", { class: "muted small", text: label + "：" }), x ? el("span", { class: "ok", text: x.date }) : el("span", { class: "no", text: "查無" })),
      x && text ? el("div", { class: "small" + (/Malignant|Suspicious/.test(text) ? " err" : ""), text: text }) : null, x ? el("details", {}, el("summary", { text: "報告全文" }), el("div", { class: "soap", text: x.report })) : null];
    // 甲超只留日期；細胞學顯示日期與結果分類（Benign、AUS/atypia…；分不出來才顯示 Diagnosis 原文）（msg629）
    const thyEls = thy ? [...part("甲狀腺超音波", thy.us, ""), ...part("細胞學", thy.cyto, thy.cyto && (thy.cyto.category || thy.cyto.diagnosis))] : [];
    fill(td, ...fundus, ...thyEls, note);
  }
  function showVac(td, r) {
    if (r.error) return fill(td, el("span", { class: "err", text: r.error }));
    if (r.data.format) return fill(td, el("span", { class: "err", text: "疫苗頁格式不符" }));
    const d = r.data, line = (label, v) => el("div", {}, el("span", { text: label + "：" }), v ? el("span", { class: "ok", text: "✓ " + v.date }) : el("span", { class: "vno", text: "未打" }));
    fill(td, line("流感", d.flu), line("新冠", d.covid),
      d.others.length ? el("div", { class: "small muted", text: "今年其他：" + d.others.map((o) => `${o.kind} ${o.date.slice(5)}`).join("、") }) : null,
      el("div", { class: "small muted", text: `本季從 ${d.season} 起算` }));
  }

  // ---------- 讀取端 ----------
  // 只用獨立讀取框（credentialless）。v0.1 拿掉「共用讀取」退路：用老闆自己的登入開病歷會切換院內的「目前病人」，
  // 另一個分頁正在打的病歷可能存到錯的人（B 審 Major 1）。院內不接受獨立讀取時就停下來說明。
  let running = false, stopFlag = false, frame = null, requestSeq = 0;
  const durations = [];
  function ensureFrame() {
    if (frame && frame.isConnected) return frame;
    frame = document.createElement("iframe");
    frame.credentialless = true;   // 先設好再放進頁面：第一個頁面就是獨立的 cookie
    frame.setAttribute("sandbox", "allow-scripts allow-same-origin allow-forms");   // 不准彈窗、對話框、把門診頁導走
    frame.setAttribute("aria-hidden", "true");
    frame.tabIndex = -1;
    frame.dataset.opdwb = "reader";
    frame.style.cssText = "position:fixed;left:-12000px;top:0;width:1200px;height:900px;border:0;visibility:hidden;pointer-events:none";
    document.documentElement.appendChild(frame);
    return frame;
  }
  const isolatedOk = (f) => { try { return f.credentialless === true && f.contentWindow.credentialless === true; } catch (e) { return false; } };
  class Refused extends Error {}

  function withTimeout(p, ms, msg) { let t; return Promise.race([p, new Promise((_, rej) => { t = setTimeout(() => rej(new Error(msg)), ms); })]).finally(() => clearTimeout(t)); }

  async function getLink(chart) {
    const user = C.loginUserFrom([...document.scripts].map((s) => s.textContent || "").join("\n"));
    if (!user) throw new Error("找不到登入帳號：請重新整理門診頁");
    const r = await fetch("/WEB/ipdNote/Common/GetMRNUrl", { method: "POST", credentials: "include", signal: AbortSignal.timeout(15000),
      headers: { "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8" }, body: new URLSearchParams({ inChartno: chart, inLoginUser: user }).toString() });
    if (/\/AuthServer/i.test(r.url)) throw new Error("院內登入已逾時，請重新登入");
    if (r.status !== 200) throw new Error("取病歷連結失敗（" + r.status + "）");
    const m = C.mrnUrlFrom(await r.text(), ORIGIN);
    if (m.error === "login") throw new Error("院內登入已逾時，請重新登入");
    if (m.error) throw new Error("院內查無這個病歷號的病歷連結");
    return m.url;
  }

  // 在讀取框開一頁，等到表出來、核對病歷號，再接上那一頁的 mrn.js
  // trigger：不換網址，改由頁面自己送出表單（檢查報告頁選 2年）；回 false 表示沒送出、不用等重新載入
  async function openPage(url, ready, chart, trigger) {
    const f = ensureFrame();
    if (!isolatedOk(f)) throw new Refused("瀏覽器不支援獨立讀取框");
    const want = new URL(url).pathname.toLowerCase();
    await withTimeout(new Promise((resolve, reject) => {
      const onLoad = () => {
        let path = null;
        try { if (f.contentWindow.location.href === "about:blank") return; path = f.contentWindow.location.pathname.toLowerCase(); } catch (e) { path = null; }
        f.removeEventListener("load", onLoad);
        if (path === null) reject(new Refused("院內頁面不能在背景開啟"));
        else if (path !== want) reject(new Refused("院內沒有讓獨立讀取框登入"));
        else if (!isolatedOk(f)) reject(new Refused("讀取框不是獨立的"));
        else resolve();
      };
      f.addEventListener("load", onLoad);
      if (!trigger) { f.src = url; return; }
      Promise.resolve().then(trigger).then((sent) => { if (sent === false) { f.removeEventListener("load", onLoad); resolve(); } },
        (e) => { f.removeEventListener("load", onLoad); reject(e); });
    }), trigger ? 60000 : 20000, trigger ? "檢查報告查詢 60 秒內沒有載入" : "院內頁面載入逾時");
    const doc = f.contentDocument, t0 = Date.now();
    for (;;) {
      if (stopFlag) throw new Error("已停止");
      const shown = String((doc.querySelector("#CurrentChartno") || {}).value || "").trim();
      if (shown && !C.sameChart(shown, chart)) throw new Error("病歷頁不是這位病人，已略過");
      if (shown && ready(doc, Date.now() - t0)) break;   // 病歷號要先出現而且對得上，才算載入完成
      if (Date.now() - t0 > 20000) throw new Error(shown ? "院內資料 20 秒內沒有載入" : "病歷頁無法核對病歷號，已略過");
      await sleep(150);
    }
    const id = "r" + (++requestSeq), ch = new MessageChannel();
    const port = ch.port1;
    const waitFor = (action, ms) => withTimeout(new Promise((resolve) => {
      port.onmessage = (e) => { const d = e.data || {}; if (d.requestId === id && d.action === action) resolve(d); };
    }), ms, "院內頁面沒有回應");
    const ok = waitFor("ready", 8000);
    f.contentWindow.postMessage({ ns: "opdwb-connect", requestId: id }, ORIGIN, [ch.port2]);
    const hello = await ok;
    if (!hello.chart || !C.sameChart(hello.chart, chart)) throw new Error("病歷頁不是這位病人，已略過");
    return async (action, arg, ms) => {
      const p = waitFor(action, ms || 30000);
      port.postMessage({ action, arg });
      const d = await p;
      if (!d.chart || !C.sameChart(d.chart, chart)) throw new Error("病歷頁不是這位病人，已略過");
      return d.error ? { error: d.error } : { data: d.data };
    };
  }

  const HIST_READY = (doc) => !!doc.querySelector("#MedicalHistorys tbody");
  const EXAM_READY = (doc, ms) => !!doc.querySelector("#EXAMReportForm, #examReportTable") || ms > 2500;
  const LAB_READY = (doc, ms) => !!doc.querySelector(".date-item[data-datekey]") || (ms > 2500 && !!doc.querySelector("#date-list-wrap") && doc.querySelector("#date-list-wrap").children.length === 0);

  function againBtn(p) { const b = el("button", { class: "b small", text: "重讀", style: "margin-top:4px" }); b.addEventListener("click", () => readOne(p, true)); return b; }
  function renderData(p, cached) {
    const d = p.data || {}, c = p.cells;
    if (d.soap) showSoap(c.soap, d.soap);
    if (d.meds) showMeds(c.drug, d.meds);
    if (d.labs) showLabs(c.labs, d.labs);
    if (d.fundus) showFundus(c.fundus, d.fundus);
    if (d.vac) showVac(c.vac, d.vac);
    const note = (d.status || "") + (cached ? "（已讀過，暫存）" : "");
    fill(c.st, el("span", { class: /^完成/.test(d.status || "") ? "small muted" : "small err", text: note }), el("br"), againBtn(p));
  }
  async function readOne(p, single) {
    const cells = p.cells;
    if (!cells || (single && running)) return;
    p.data = {};   // 這一位這次讀到的結果（給 CSV 用；只在記憶體）
    if (single) { running = true; stopFlag = false; setButtons(); }
    const t0 = Date.now();
    fill(cells.st, el("span", { class: "small", text: "讀取中…" }));
    if (p.card) p.card.classList.remove("firstrow");
    // 基準日＝這張清單的看診日（查過去或明天的清單時，SOAP、眼底一年內、本季疫苗都以那天為準，B 審 Minor）
    const base = C.ymd(p.visitDate) || C.todayKey();
    let note = "", refused = false;
    try {
      const link = await getLink(p.chart);
      const ask1 = await openPage(C.mrnPage(link, "/WEB/MRN/MedicalHistory"), HIST_READY, p.chart);
      showSoap(cells.soap, p.data.soap = await ask1("soap", { chart: p.chart, before: base, dept: p.dept, deptName: p.deptName, doctor: p.doctor }));
      if (stopFlag) throw new Error("已停止");
      const ask2 = await openPage(C.mrnPage(link, "/WEB/MRN/InspectionReport"), LAB_READY, p.chart);
      const dx = p.data.soap && p.data.soap.data && p.data.soap.data.dx || [];
      showLabs(cells.labs, p.data.labs = await ask2("labs", { chart: p.chart, want: ["eGFR", "UACR", ...C.thyroidWant(dx)], age: p.age, sex: p.sex, birth: p.birth, today: base }, 120000));
      if (stopFlag) throw new Error("已停止");
      showVac(cells.vac, p.data.vac = await ask2("vaccine", { chart: p.chart, today: base }));
      const sv = p.data.soap && p.data.soap.data && p.data.soap.data.visit;   // SOAP 選中的那次門診（B 複審 Major：不能用中間看過的急診、別科）
      showMeds(cells.drug, p.data.meds = await ask2("meds", { chart: p.chart, today: base, lastVisit: sv ? sv.date : "" }));
      if (stopFlag) throw new Error("已停止");
      // 檢查報告（msg621）：真的打開檢查報告頁 → 頁面上選 2年（結節病人選全部）由瀏覽器送出 → 讀重新載入後的頁面
      const examArg = { chart: p.chart, today: base, nodule: C.thyroidNodule(dx) };
      const examUrl = C.mrnPage(link, H.exam);
      let ask3 = await openPage(examUrl, EXAM_READY, p.chart);
      let r3 = null;
      ask3 = await openPage(examUrl, EXAM_READY, p.chart, async () => { r3 = await ask3("examSubmit", examArg); return !!(r3 && r3.data && r3.data.submitted); }).catch((e) => { throw e; });
      if (r3 && r3.error) throw new Error(r3.error);
      showFundus(cells.fundus, p.data.fundus = await ask3("exam", examArg, 30000));
      note = "完成 " + new Date().toTimeString().slice(0, 5);
    } catch (e) {
      refused = e instanceof Refused;
      note = e.message || String(e);
    } finally {
      try { if (frame) frame.src = "about:blank"; } catch (e) { /* 忽略 */ }
    }
    p.data.status = note;
    durations.push((Date.now() - t0) / 1000);
    fill(cells.st, el("span", { class: /^完成/.test(note) ? "small muted" : "small err", text: note }), el("br"), againBtn(p));
    if (done(p)) { p.cachedAt = Date.now(); cacheSet(p); }
    if (single) { running = false; setButtons(); afterRun(); }
    return refused;
  }

  function setButtons() { bRead.disabled = running; bAll.disabled = running; bList.disabled = running; bClear.disabled = running; bStop.disabled = !running; bCsv.disabled = running || !patients.some((p) => p.data); }
  // 儲存 CSV：只在按下時產生、用 Blob 下載（不需要 downloads 權限、不寫 storage）
  bCsv.addEventListener("click", () => {
    if (running || isLocked() || !patients.some((p) => p.data)) return;
    const val = (id) => { const e = document.getElementById(id); return e ? String(e.value || "").trim() : ""; };
    const name = C.csvName(H.name, patients[0].visitDate, val("DeptListText") || patients[0].dept, val("AorPorSListText"));
    const url = URL.createObjectURL(new Blob([C.toCSV(patients.map((p) => ({ p, d: p.data })))], { type: "text/csv;charset=utf-8" }));
    const a = el("a", { href: url, download: name, style: "display:none" });
    root.append(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 30000);
    status(`已儲存「${name}」。檔案含病人資料，請勿放進雲端資料夾，用完請刪除。`, true);
  });
  function status(text, warn) { st.textContent = text; st.className = "st" + (warn ? " warn" : ""); }
  const median = (a) => { const s = a.slice(-20).sort((x, y) => x - y); return s.length ? s[Math.floor(s.length / 2)] : 0; };

  function afterRun() { if (pendingRefresh) { pendingRefresh = false; refreshList(); } }
  async function runAll(all) {
    if (running) return;
    await refreshList();
    const todo = patients.filter((p) => all || !done(p));
    if (!todo.length) { status(patients.length ? "清單上的病人都讀過了。要更新請按「全部重讀」或單人「重讀」。" : "左邊還沒有門診清單。"); return; }
    running = true; stopFlag = false; setButtons();
    let i = 0;
    for (const p of todo) {
      if (stopFlag) break;
      i++;
      const m = median(durations);
      status(`讀取中 ${i}/${todo.length}：${p.seq} 號${m ? `｜每位約 ${Math.round(m)} 秒` : ""}`);
      const refused = await readOne(p, false);
      if (refused) {
        status("院內不讓背景的獨立讀取框登入，已停止。請把這個畫面截圖給助理。（為了不切換您正在看的病人，這一版不用您自己的登入去讀。）", true);
        break;
      }
    }
    running = false; setButtons();
    if (!/已停止/.test(st.textContent)) status(stopFlag ? "已停止。" : `讀完 ${i} 位。讀過的會記住，關掉瀏覽器才清空。`);
    afterRun();
  }
  bRead.addEventListener("click", () => runAll(false));
  bAll.addEventListener("click", () => runAll(true));
  bClear.addEventListener("click", async () => { if (running) return; await cacheClear(); for (const p of patients) { delete p.data; delete p.cachedAt; } patients = []; lastSig = ""; await refreshList(); status("已清除暫存。"); });
  // 左邊門診清單變了（重新查詢、新掛號）→ 自動更新側邊欄，讀過的保留
  let mo = null, moT = 0;
  function watchList() {
    const t = document.querySelector("#OPDPatientListTable");
    const target = t ? (t.parentElement || t) : null;
    if (!target || (mo && mo.__t === target)) return;
    if (mo) mo.disconnect();
    mo = new MutationObserver(() => { clearTimeout(moT); moT = setTimeout(() => { if (ov.classList.contains("open")) refreshList(); }, 600); });
    mo.observe(target, { childList: true, subtree: true, characterData: true });
    mo.__t = target;
  }
  setInterval(watchList, 2000); watchList();
  bStop.addEventListener("click", () => { stopFlag = true; status("停止中：讀完這一位就停。"); });
  // ---------- 自動延長（老闆 msg610；照急診工作台 modules/session）----------
  // 院內倒數（#countdown，mm:ss）剩 29 分鐘時，替使用者按院內原本的「延長時間」鈕（button.topbar-refresh[onclick="ReloadTime()"]）。
  // 只在門診頁最上層（opd.js 本來就只跑在最上層）；畫面已鎖定（#lockScreen）時不動作；按了 10 秒內沒看到倒數重設就停下來請手動延長。
  // ⚠ 這是工作台唯一會「按院內按鈕」的地方；院內閒置鎖定是資通安全管理法的要求，預設開啟是老闆的決定（msg610），可以隨時取消勾選。
  const extBox = ext.querySelector("input"), extSt = ext.querySelector(".extst");
  extBox.checked = true;
  let extAt = null, extSuspended = false, extCount = 0;
  function extStatus(text, warn) { extSt.textContent = text + (extCount ? `（已延長 ${extCount} 次）` : ""); extSt.className = "extst" + (warn ? " warn" : ""); fab.title = "自動延長：" + extSt.textContent; }
  function secondsLeft() { const m = /^(\d{2}):([0-5]\d)$/.exec(String((document.getElementById("countdown") || {}).textContent || "").trim()); return m ? +m[1] * 60 + +m[2] : null; }
  function extCheck() {
    if (!extBox.checked) { extAt = null; return extStatus("已關閉"); }
    if (extSuspended) return extStatus("沒確認到延長成功，請手動按延長", true);
    const now = Date.now(), left = secondsLeft();
    if (document.getElementById("lockScreen")) { extAt = null; return extStatus("畫面已鎖定，請正常解鎖"); }
    if (extAt !== null) {
      const el2 = Math.max(0, now - extAt) / 1000;
      if (left !== null && left > 15 && left <= 1800 && el2 <= 120 && left + el2 >= 1770) { extAt = null; extCount++; return extStatus("開啟中"); }
      if (now - extAt >= 10000) { extSuspended = true; return extStatus("沒確認到延長成功，請手動按延長", true); }
      return;
    }
    if (left === null) return extStatus("讀不到院內倒數", true);
    if (left <= 15) return extStatus("快要鎖定了，請手動按延長", true);
    if (left > 1740) return extStatus("開啟中");
    const b = document.querySelector('button.topbar-refresh[title="延長時間"][onclick="ReloadTime()"]');
    if (!b || b.disabled || b.getClientRects().length === 0) return extStatus("找不到院內的延長鈕", true);
    extAt = now; extStatus("延長中…");
    b.click();
  }
  extBox.addEventListener("change", () => { extSuspended = false; extAt = null; extCheck(); });
  // 院內畫面鎖定（#lockScreen，鎖定時才由 blockUI 加進頁面）→ 側邊欄的病人資料一起隱藏，解鎖後恢復（B 審 Major）
  // v0.4.2（B 複審 Major）：鎖定時整個側邊欄與按鈕都藏起來（含「儲存 CSV」），也不會蓋住院內解鎖框
  const isLocked = () => !!document.getElementById("lockScreen");
  function lockCheck() { const l = isLocked(); ov.classList.toggle("locked", l); fab.classList.toggle("locked", l); }
  setInterval(lockCheck, 1000); lockCheck();
  setInterval(extCheck, 5000); extCheck();

  setButtons();
})();
