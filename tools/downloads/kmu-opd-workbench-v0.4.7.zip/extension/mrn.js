// 病歷頁（/WEB/MRN/*）那一端：只在門診工作台自己的隱藏讀取框裡動作（frameElement 標記 data-opdwb="reader"），
// 一般開的病歷分頁完全不碰。跑在頁面主環境（manifest world: MAIN），送出的請求和院內頁面自己送的一樣（同一個框的登入）。
// 只讀：只送院內頁面本來就會送的查詢，不點、不改任何東西。身分證字號只在這個框裡用來查檢驗，不回傳給工作台。
(function () {
  if (window.top === window) return;
  let mine = false;
  try { mine = !!window.frameElement && window.frameElement.dataset.opdwb === "reader"; } catch (e) { mine = false; }
  if (!mine) return;
  const C = OPDWB;
  const sig = (ms) => (AbortSignal.timeout ? AbortSignal.timeout(ms) : undefined);
  const LOGIN = /高醫體系資訊系統入口網|資訊系統入口網|AuthServer|\/Account\/Login/i;
  const chartHere = (doc) => { const e = (doc || document).querySelector("#CurrentChartno"); return e ? String(e.value || e.getAttribute("value") || "").trim() : ""; };
  // 核對一律「對不上或讀不到就失敗」（B 審 Major 2）：頁面標示的病歷號必須存在且是這位
  function mustBe(doc, chart, what, allowText) {
    const shown = chartHere(doc);
    if (shown) { if (!C.sameChart(shown, chart)) throw new Error(what + "不是這位病人"); return; }
    if (allowText) {   // 檢查報告頁沒有存檔可對：退一步找頁面文字裡的「病歷號：…」，要找得到且全部是這位
      const cs = C.chartsInText(doc.body ? doc.body.textContent : "");
      if (cs.length && cs.every((c) => C.sameChart(c, chart))) return;
    }
    throw new Error(what + "無法核對病歷號");
  }

  async function postJSON(path, body) {
    const r = await fetch(path, { method: "POST", credentials: "include", signal: sig(20000),
      headers: { "Content-Type": "application/json; charset=utf-8" }, body: JSON.stringify(body) });
    if (r.status !== 200) throw new Error("院內回應 " + r.status);
    const t = await r.text();
    if (LOGIN.test(t.slice(0, 3000)) && /<html/i.test(t.slice(0, 500))) throw new Error("院內登入已逾時");
    return JSON.parse(t);
  }
  async function getDoc(path) {
    const r = await fetch(path, { credentials: "include", signal: sig(20000) });
    if (r.status !== 200) throw new Error("院內回應 " + r.status);
    const t = await r.text();
    if (LOGIN.test(t.slice(0, 5000)) && !/CurrentChartno/.test(t)) throw new Error("院內登入已逾時");
    return new DOMParser().parseFromString(t, "text/html");
  }
  const cellText = (td) => String(td ? td.textContent : "").replace(/\s+/g, " ").trim();

  // 就醫歷史：上一次門診的 SOAP
  async function soap(arg) {
    const table = document.querySelector("#MedicalHistorys");
    if (!table) throw new Error("就醫歷史頁沒有就醫清單");
    const heads = [...table.querySelectorAll("thead th")].map(cellText);
    const col = (name, dflt) => { const i = heads.indexOf(name); return i >= 0 ? i : dflt; };
    const iSrc = col("來源", 1), iDate = col("就醫日", 2), iDept = col("科別", 3), iDoc = col("醫師", 4);
    const rows = [...table.querySelectorAll("tbody tr")].filter((tr) => tr.dataset && tr.dataset.seqno !== undefined).map((tr) => {
      const td = tr.querySelectorAll("td");
      return { source: cellText(td[iSrc]), date: cellText(td[iDate]), dept: cellText(td[iDept]), doctor: cellText(td[iDoc]),
        attrs: { hospcode: tr.dataset.hospcode, chartno: tr.dataset.chartno, seqno: tr.dataset.seqno, deptcode: tr.dataset.deptcode, yn: tr.dataset.yn, ischinese: tr.dataset.ischinese } };
    });
    mustBe(document, arg.chart, "就醫歷史頁");
    const prev = C.pickPrevVisit(rows, arg.before, { dept: arg.dept, deptName: arg.deptName, doctor: arg.doctor });
    if (!prev) return { none: true, first: true, visits: rows.length };   // 沒有老闆、也沒有本科的門診 → 本科初診
    if (!C.sameChart(prev.attrs.chartno, arg.chart)) throw new Error("就醫清單不是這位病人");
    const h = C.parseHistory(await postJSON("/WEB/MRN/MedicalHistory/MedicalHistoryAllData", C.historyRequest(prev)));
    if (h.error) throw new Error(h.error);
    return { visit: { date: C.fmtDate(C.ymd(prev.date)), dept: prev.dept, doctor: prev.doctor, tier: prev.tier }, soap: h.soap, dx: h.dx };
  }

  // 檢驗：最近一次抽血那一天的全部報告（院內 Single 模式明細）
  async function labs(arg) {
    mustBe(document, arg.chart, "檢驗頁");
    const dates = [...document.querySelectorAll(".date-item[data-datekey]")].map((el) => {
      let reports = [];
      try { reports = JSON.parse(el.getAttribute("data-report") || "[]"); } catch (e) { reports = []; }
      return { key: String(el.getAttribute("data-datekey") || "").trim(), reports: Array.isArray(reports) ? reports : [] };
    });
    const draw = C.pickLatestDraw(dates);
    if (!draw) return { none: true, dates: dates.length };
    const form = document.querySelector("#inspectionReportForm");
    const pairs = form ? [...new FormData(form).entries()].map(([k, v]) => [k, String(v)]) : [];
    const fd = C.formDates(pairs);
    // 年齡、性別（msg658：門診清單的性別欄是空的）：生日取病歷頁抬頭，性別看身分證字號第 2 碼；字號只在這個框裡用，不回傳
    const grp = [...document.querySelectorAll(".input-group")].find((g) => /生\s*日/.test((g.querySelector(".input-group-text") || {}).textContent || ""));
    const birth = (grp && grp.querySelector("input") ? String(grp.querySelector("input").value || grp.querySelector("input").getAttribute("value") || "").trim() : "") || arg.birth || "";
    const idEl = document.querySelector("#inPATIENT_ID_NO");
    const sex = C.sexFromId(idEl ? idEl.value || idEl.getAttribute("value") : "") || C.sexOf(arg.sex);
    // 一年內「項目 × 日期」（msg658）：每種報告類別取一年內最新那筆，用院內「整合」（Mix）模式查一次，回來就是跨日期的表
    const to = /^\d{8}$/.test(arg.today || "") ? arg.today : C.todayKey();
    const from = String(+to.slice(0, 4) - 1) + to.slice(4);
    const byKind = new Map();
    for (const d of dates.filter((x) => /^\d{8}$/.test(x.key) && x.key >= from && x.key <= to).sort((a, b) => (a.key < b.key ? 1 : -1)))
      for (const r of d.reports) { const k = String(r["報告類別"] || ""); if (k && !C.NOT_BLOOD.test(k) && !byKind.has(k)) byKind.set(k, r); }
    if (byKind.size) {
      const results = []; let ok = true;
      for (const [kind, r] of byKind) {
        const res = await postJSON("/WEB/MRN/InspectionReport/GetInspectionReportDetail", Object.assign(C.detailRequest(r, fd), { in_TableStatus: "Mix" }));
        if (!res || !Array.isArray(res.columnsDateTime) || !Array.isArray(res.mixTableData)) { ok = false; break; }
        results.push({ kind, res });
      }
      if (ok) {
        const m = C.mixMerge(results, from, to);
        if (m.dates.length) return { mix: true, from: C.fmtDate(from), dates: m.dates, items: m.items, derived: C.mixDerive(m, birth, sex, arg.age), missing: C.mixMissing(m, arg.want), kinds: [...byKind.keys()], requests: results.length };
      }
    }
    // 院內沒有回整合格式時，退回原本「最近一次抽血＋補查」
    const lines = [], seen = new Set(), kinds = [];
    for (const r of draw.reports) {
      const kind = String(r["報告類別"] || "");
      const res = await postJSON("/WEB/MRN/InspectionReport/GetInspectionReportDetail", C.detailRequest(r, fd));
      kinds.push(kind);
      for (const x of C.parseDetail(res, kind)) {
        const k = [x.name, x.value, x.sampled, x.code].join("|");
        if (!seen.has(k)) { seen.add(k); lines.push(x); }
      }
    }
    const sorted = C.sortLabs(lines);
    // 甲狀腺病人（老闆 msg583）：最近一次沒驗到的 TSH／free T4（甲癌加 Tg、anti-Tg）往前找最近一次；最多查 12 筆報告
    // 補查（eGFR、UACR 固定要，msg631；甲狀腺項目 msg583）：最多看 6 個其他日期、多查 8 筆明細；UACR 連驗尿那天也找
    let miss = C.missingKeys(sorted, arg.want), budget = 8, looked = 0;
    const extra = [], isUrine = (r) => /尿液|體液/.test(String(r["報告類別"] || ""));
    const needUrine = () => miss.includes("UACR"), needBlood = () => miss.some((k) => k !== "UACR");
    for (const d of miss.length ? C.otherDraws(dates, draw.key, 6, { blood: needBlood(), urine: needUrine() }) : []) {
      looked++;
      for (const r of d.reports) {
        if (!miss.length || budget <= 0) break;
        if (isUrine(r) ? !needUrine() : !needBlood()) continue;
        budget--;
        const res = await postJSON("/WEB/MRN/InspectionReport/GetInspectionReportDetail", C.detailRequest(r, fd));
        const got = C.parseDetail(res, String(r["報告類別"] || ""));
        for (const k of miss.slice()) {
          if (!C.hasKey(got, k)) continue;
          for (const x of C.linesFor(got, k)) extra.push(Object.assign({}, x, { date: C.fmtDate(d.key), key: true }));
          miss = miss.filter((m) => m !== k);
        }
      }
      if (!miss.length || budget <= 0) break;
    }
    // 院內沒報的 eGFR、UACR 自己算（msg639），標「外掛計算」；最近一次那天的值優先（sorted 在前）
    const today = sorted.map((x) => Object.assign({}, x, { date: x.date || C.fmtDate(draw.key) }));
    const derived = C.deriveRenal(today.concat(extra), birth ? C.ageAt(birth, draw.key) : arg.age, sex);
    return { date: C.fmtDate(draw.key), kinds: [...new Set(kinds)], lines: sorted, extra: C.sortLabs(extra), derived, missing: miss, looked, scanned: 8 - budget };
  }

  // 檢查報告頁：一年內的眼底攝影（列格式同甲狀腺外掛：第 3 個 tbody 裡 onclick=showReport 的列，報告在 data-content）
  // 檢查報告頁（老闆 msg621：v0.4.1 以前用 fetch 重送表單，院內回來的頁面核對不到病歷號）。
  // v0.4.2 起照老闆手動的做法：讀取框真的打開檢查報告頁（帶病歷網址的 id），在這頁上把「查詢區間」選成 2年（結節病人選全部），
  // 由瀏覽器原生送出表單、整頁重新載入，再讀載入後的這一頁。兩次載入工作台都會核對 #CurrentChartno。
  function examWant(form, arg) {
    const options = [...form.querySelectorAll('select[name="CustromDate"] option')].map((o) => ({ value: o.getAttribute("value") || "", text: o.textContent || "" }));
    const sent = C.examRangeForm([], options, arg.today, !!arg.nodule);
    const get = (k) => (sent.find(([n]) => n === k) || [])[1] || "";
    return { value: get("CustromDate"), start: get("NQuery_startdate"), end: get("NQuery_enddate"), hasOption: options.some((o) => String(o.value).trim() === get("CustromDate")) };
  }
  async function examSubmit(arg) {
    mustBe(document, arg.chart, "檢查報告頁");
    const form = document.querySelector("#EXAMReportForm");
    if (!form) return { submitted: false, format: true };
    const action = new URL(form.getAttribute("action") || location.href, location.href);
    if (action.origin !== location.origin || !/\/mrn\/examreport\/?$/i.test(action.pathname)) throw new Error("檢查報告頁查詢網址不對");
    const w = examWant(form, arg), sel = form.querySelector('select[name="CustromDate"]');
    if (sel && w.hasOption && String(sel.value).trim() === w.value) return { submitted: false };   // 已經是要的區間
    if (sel && w.hasOption) sel.value = w.value; else if (sel) sel.value = "";
    for (const n of ["NQuery_startdate", "NQuery_enddate"]) { const e = form.querySelector(`[name="${n}"]`); if (e) e.value = n === "NQuery_startdate" ? w.start : w.end; }
    setTimeout(() => HTMLFormElement.prototype.submit.call(form), 50);   // 先回覆，再讓整頁送出
    return { submitted: true };
  }
  async function exam(arg) {
    const doc = document;
    mustBe(doc, arg.chart, "檢查報告頁");
    const form = doc.querySelector("#EXAMReportForm");
    let range = "預設";
    if (form) {
      const w = examWant(form, arg), sel = form.querySelector('select[name="CustromDate"]');
      range = sel && String(sel.value).trim() === w.value ? (arg.nodule ? "全部" : "2年") : "未確認";
    }
    const tb = doc.querySelectorAll("tbody");
    if (tb.length < 3) return { format: true };
    const rows = [...tb[2].querySelectorAll('tr[onclick*="showReport"]')].map((tr) => ({ text: tr.textContent || "", content: tr.getAttribute("data-content") || "" }));
    const f = C.pickFundus(rows, arg.today);
    // 最近一次甲狀腺超音波、細胞學（老闆 msg587）：v0.3.3 起有就顯示（不再只限診斷是結節的人，老闆 msg601）；結節病人另外查全部年份
    let thy = null;
    {
      const us = C.latestRow(rows, C.isThyUS, arg.today).latest, cy = C.latestRow(rows, C.isThyCyto, arg.today).latest;
      if (arg.nodule || us || cy) thy = { nodule: !!arg.nodule, us: us ? { date: C.fmtDate(us.date), conclusion: C.conclusion(us.report), report: us.report.slice(0, 4000) } : null,
        cyto: cy ? { date: C.fmtDate(cy.date), diagnosis: C.cytoDiagnosis(cy.report), category: C.cytoCategory(C.cytoDiagnosis(cy.report)), report: cy.report.slice(0, 4000) } : null };
    }
    return { range, thy, rows: rows.length, latest: f.latest ? { date: C.fmtDate(f.latest.date), name: f.latest.name.slice(0, 120), conclusion: C.conclusion(f.latest.report), report: f.latest.report.slice(0, 4000) } : null, count: f.count };
  }

  // 疫苗頁：表頭有「施打日」「疫苗種類」的那張表
  async function vaccine(arg) {
    const doc = await getDoc("/WEB/MRN/Vaccine");
    mustBe(doc, arg.chart, "疫苗頁");
    const table = [...doc.querySelectorAll("table")].find((t) => { const h = [...t.querySelectorAll("th")].map(cellText); return h.includes("施打日") && h.includes("疫苗種類"); });
    if (!table) return { format: true };
    const h = [...table.querySelectorAll("th")].map(cellText);
    const at = (name) => h.indexOf(name);
    const rows = [...table.querySelectorAll("tbody tr")].map((tr) => { const td = tr.querySelectorAll("td");
      return { date: cellText(td[at("施打日")]), kind: cellText(td[at("疫苗種類")]), desc: at("疫苗說明") >= 0 ? cellText(td[at("疫苗說明")]) : "", source: at("上傳來源") >= 0 ? cellText(td[at("上傳來源")]) : "", dose: at("劑別") >= 0 ? cellText(td[at("劑別")]) : "" }; })
      .filter((r) => r.date);
    const s = C.vaccineSummary(rows, arg.today);
    const pick = (r) => (r ? { date: C.fmtDate(r.key), kind: r.kind, desc: r.desc, dose: r.dose } : null);
    return { season: C.fmtDate(s.season), flu: pick(s.flu), covid: pick(s.covid), others: s.others.map(pick), total: s.total };
  }

  // 用藥頁（含雲端藥歷，老闆 msg591／592）：表 #medListTable，欄位依表頭名稱找
  async function meds(arg) {
    const doc = await getDoc("/WEB/MRN/MedicineInfo");
    mustBe(doc, arg.chart, "用藥頁");
    const table = doc.querySelector("#medListTable");
    if (!table) return { format: true };
    const h = [...table.querySelectorAll("thead th")].map((th) => cellText(th).replace(/\s+/g, ""));
    const at = (name) => h.indexOf(name);
    const need = ["藥名", "結束日"];
    if (need.some((n) => at(n) < 0)) return { format: true };
    const get = (td, name) => (at(name) >= 0 ? cellText(td[at(name)]) : "");
    const rows = [...table.querySelectorAll("tbody tr")].map((tr) => { const td = tr.querySelectorAll("td");
      return { hosp: get(td, "院區"), src: get(td, "來源"), drug: get(td, "藥名"), atc: get(td, "ATCCODE"), code: get(td, "健保碼"), start: get(td, "起始日"), end: get(td, "結束日"), days: get(td, "應領天數"), left: get(td, "剩餘天數") }; })
      .filter((r) => r.drug);
    return C.currentMeds(rows, arg.today, 30, arg.lastVisit);
  }

  const ACTIONS = { soap, labs, exam, examSubmit, vaccine, meds };
  window.addEventListener("message", (e) => {
    if (e.source !== window.parent || e.origin !== location.origin) return;
    const d = e.data || {};
    if (d.ns !== "opdwb-connect" || !e.ports || !e.ports[0]) return;
    const port = e.ports[0], requestId = d.requestId;
    port.onmessage = async (m) => {
      const { action, arg } = m.data || {};
      const f = ACTIONS[action];
      if (!f) return port.postMessage({ requestId, action, error: "不認得的動作" });
      try { port.postMessage({ requestId, action, chart: chartHere(document), data: await f(arg || {}) }); }
      catch (err) { port.postMessage({ requestId, action, chart: chartHere(document), error: String(err && err.message || err).slice(0, 80) }); }
    };
    port.postMessage({ requestId, action: "ready", chart: chartHere(document) });
  });
})();
