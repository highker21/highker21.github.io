// 讓門診頁的工作台（content script）可以用 chrome.storage.session 暫存讀過的結果（老闆 msg609：不要每次都全部重跑）。
// storage.session 只在記憶體、瀏覽器關掉就清空，網頁本身讀不到；預設只開放給外掛自己的頁面，這裡開放給 content script。
// 這個背景程式只做這一件事：不連網、不讀分頁。
const open = () => chrome.storage.session.setAccessLevel({ accessLevel: "TRUSTED_AND_UNTRUSTED_CONTEXTS" }).catch(() => {});
chrome.runtime.onInstalled.addListener(open);
chrome.runtime.onStartup.addListener(open);
open();
