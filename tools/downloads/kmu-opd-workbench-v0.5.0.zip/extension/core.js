// 門診工作台：純函式（content script 與 node 測試共用）。不連網、不存資料。
// 院內資料格式依老闆 2026-11-21 msg548（OPD_Main）、msg552（檢驗）、msg559（就醫歷史）三份存檔與急診工作台 1.16.1 對照。
var OPDWB = (function () {
  const HOSPS = {
    "intraweb.server.kmuh.org.tw": { name: "高醫附院", exam: "/WEB/MRN/EXAMReport" },
    "intraweb.kmugh.org.tw": { name: "高醫岡山", exam: "/web/MRN/ExamReport" },
  };
  const hospOf = (host) => HOSPS[String(host || "").toLowerCase()] || null;

  // 病歷號比對：去掉非英數、去掉開頭的 0
  const bareChart = (c) => String(c || "").replace(/[^A-Za-z0-9]/g, "").replace(/^0+/, "").toUpperCase();
  const sameChart = (a, b) => !!bareChart(a) && bareChart(a) === bareChart(b);

  // OPD_Main 清單一列的儲存格文字 → 病人（欄位依院內程式 fn_selecOPDTableRow：td0 inhospID、td3 看診日期、td4 病歷號、
  // td5 姓名、td6 性別、td7 年齡（表頭）、td8 看診序號、td9 看診狀態、td11 科別代碼）
  function patientFromCells(cells) {
    const c = (i) => String(cells[i] == null ? "" : cells[i]).trim();
    const chart = c(4);
    if (!/^[A-Za-z0-9]{4,15}$/.test(chart)) return null;
    // 院內實際：性別欄是空的、「年齡」欄放的是生日（yyyy/mm/dd），年齡在最後一個隱藏欄「61 歲」（msg658 eGFR 空白的原因）
    const all = cells.map((x) => String(x == null ? "" : x).trim());
    const ageCell = all.find((x) => /^\d{1,3}\s*歲$/.test(x)) || (/^\d{1,3}$/.test(c(7)) ? c(7) : "");
    const birth = /^\d{4}\/\d{1,2}\/\d{1,2}$/.test(c(7)) ? c(7) : "";
    return { inhospId: c(0), visitDate: c(3), chart, name: c(5), sex: /^(男|女)$/.test(c(6)) ? c(6) : "", age: ageCell, birth, seq: c(8), status: c(9), dept: c(11) };
  }
  const seqNum = (s) => { const n = parseInt(String(s).replace(/\D/g, ""), 10); return isNaN(n) ? 1e9 : n; };
  const sortPatients = (ps) => ps.slice().sort((a, b) => seqNum(a.seq) - seqNum(b.seq));

  // 頁面程式碼裡的登入帳號（院內 inline script：inLoginUser: '…'）
  function loginUserFrom(scriptText) {
    const m = String(scriptText || "").match(/inLoginUser\s*[:=]\s*["']([^"']+)["']/i);
    return m ? m[1].trim() : "";
  }

  // GetMRNUrl 回應 → 病歷網址（只接受 https、同一個院內網域、/WEB/MRN 開頭；查無病歷號時院內回空值密文）
  function mrnUrlFrom(text, origin) {
    let t = String(text || "").trim();
    if (t.startsWith('"') && t.endsWith('"')) { try { t = JSON.parse(t); } catch (e) { t = t.slice(1, -1); } }
    t = String(t).trim();
    if (/<html|<!doctype/i.test(t)) return { error: "login" };
    let u;
    try { u = new URL(t, origin + "/"); } catch (e) { return { error: "notfound" }; }
    const dom = "." + new URL(origin).hostname.split(".").slice(-3).join(".");
    if (u.protocol !== "https:" || !("." + u.hostname.toLowerCase()).endsWith(dom)) return { error: "notfound" };
    if (!/^\/web\/mrn/i.test(u.pathname)) return { error: "notfound" };
    if (/id=50FB72297079EEFA/i.test(u.search) || /[?&]id=(?:&|$)/i.test(u.search)) return { error: "notfound" };
    return { url: u.href };
  }
  // 同一個病歷 session 改開別頁：保留網址參數（院內的病人代碼），只換路徑（同急診工作台）
  function mrnPage(url, path) { const u = new URL(url); u.pathname = path; return u.href; }

  // ---------- 就醫歷史：上一次門診的 SOAP ----------
  // rows：#MedicalHistorys tbody tr 的 {source（來源）, date（就醫日 yyyy/mm/dd）, dept, doctor, attrs:{hospcode, chartno, seqno, deptcode, yn, ischinese}}
  // today：yyyymmdd。取「今天以前」最近一次、來源是門診、不是敏感（yn=Y 要密碼）、不是中醫的那一列
  const ymd = (s) => { const m = String(s || "").match(/(\d{3,4})[\/\-.](\d{1,2})[\/\-.](\d{1,2})/); if (!m) return ""; let y = +m[1]; if (y < 1911) y += 1911; return y + String(m[2]).padStart(2, "0") + String(m[3]).padStart(2, "0"); };
  // 同一天有好幾個門診時，優先取和今天這個診同科（deptcode）的那一列（B 審 Minor）
  // 上一次門診（老闆 msg579）：①老闆自己上次寫的 ②沒有就找本科（內分泌新陳代謝科）的 ③都沒有回 null，畫面顯示「本科初診」
  // opt：{dept: 今天門診的科別代碼, deptName: 今天門診的科別名稱, doctor: 今天門診的主治醫師姓名}；舊呼叫法第三個參數是科別代碼
  const nameKey = (s) => String(s || "").replace(/\s+/g, "");
  // 科別名稱去掉代碼與診別：「0103 內分泌新陳代謝內科1診」「內分泌新陳代謝內科2」→「內分泌新陳代謝內科」（同科不同診的代碼不同：0103／0104）
  const deptKey = (s) => String(s || "").replace(/\s+/g, "").replace(/^\d{3,5}/, "").replace(/\d*診?$/, "");
  const HOME_DEPT = /^內分泌新陳代謝/;   // 只在今天門診的科別名稱讀不到時用（B 審 Minor 1：不能把小兒內分泌、生殖內分泌當本科）
  function isHomeDept(dept, homeName) {
    const k = deptKey(dept), h = deptKey(homeName);
    if (!k) return false;
    return h ? k === h : HOME_DEPT.test(k);
  }
  function pickPrevVisit(rows, today, opt) {
    const o = opt && typeof opt === "object" ? opt : { dept: opt };
    const ok = (rows || []).filter((r) => /門診/.test(r.source || "") && ymd(r.date) && ymd(r.date) < today &&
      String(r.attrs && r.attrs.yn || "").toUpperCase() !== "Y" && String(r.attrs && r.attrs.ischinese || "").toUpperCase() !== "Y");
    const same = (r) => (o.dept && String(r.attrs && r.attrs.deptcode || "").trim() === String(o.dept).trim() ? 0 : 1);
    ok.sort((a, b) => (ymd(b.date) > ymd(a.date) ? 1 : ymd(b.date) < ymd(a.date) ? -1 : same(a) - same(b)));
    const me = nameKey(o.doctor);
    const mine = me ? ok.find((r) => nameKey(r.doctor) === me) : null;
    if (mine) return Object.assign({}, mine, { tier: "mine" });
    const home = ok.find((r) => isHomeDept(r.dept, o.deptName));
    return home ? Object.assign({}, home, { tier: "dept" }) : null;
  }
  function historyRequest(row) {
    const a = row.attrs || {};
    return { in_HospCode: a.hospcode, in_ChartNo: a.chartno, in_SeqNo: a.seqno, in_deptcode: a.deptcode, in_Password: "", in_YN: a.yn };
  }
  // MedicalHistoryAllData 回應 → {soap:[{title,text}], dx:[…]}；院內換行記號 (char[13])
  function parseHistory(result) {
    if (!result || !result.VALIDATE_STATUS || result.VALIDATE_STATUS.CODE !== "000") return { error: "院內回覆不是成功（" + (result && result.VALIDATE_STATUS ? result.VALIDATE_STATUS.CODE : "格式不符") + "）" };
    const soap = [];
    for (const v of result.medHistorySOAP || []) {
      const title = String(v.TITLE || "").trim(), text = String(v.CONTENT_TEXT || "").replace(/\(char\[13\]\)/g, "\n").replace(/\r\n?/g, "\n").trim();
      if (title) soap.push({ title, text });
      else if (text) { if (soap.length) soap[soap.length - 1].text += (soap[soap.length - 1].text ? "\n" : "") + text; else soap.push({ title: "", text }); }
    }
    const dx = (result.medHistoryDiagnosis || []).map((d) => [d["診斷碼"], d["中文名"] || d["英文名"]].filter(Boolean).join(" ")).filter(Boolean);
    return { soap, dx };
  }

  // ---------- 檢驗：最近一次抽血 ----------
  // 不算「抽血」的報告類別（培養、鏡檢、糞便、新冠、結核基因、血庫）
  const NOT_BLOOD = /培養|鏡檢|糞便|COVID|GeneXpert|抗酸菌|革蘭|血庫/i;
  const URINE_ONLY = /尿液|體液/;   // 只有尿液、體液的那一天不算「抽血」，但抽血那天的尿液報告一起列（UACR）
  // dates：[{key: yyyymmdd, reports:[data-report 的每一筆]}] → 最新、且有至少一筆不是 NOT_BLOOD 的那一天；那天所有不是 NOT_BLOOD 的報告
  function pickLatestDraw(dates) {
    const ds = (dates || []).filter((d) => /^\d{8}$/.test(d.key)).sort((a, b) => (a.key < b.key ? 1 : a.key > b.key ? -1 : 0));
    for (const d of ds) {
      const reps = (d.reports || []).filter((r) => !NOT_BLOOD.test(String(r["報告類別"] || "")));
      if (reps.some((r) => !URINE_ONLY.test(String(r["報告類別"] || "")))) return { key: d.key, reports: reps };
    }
    return null;
  }
  // 照院內 ClickInspectionReportTable 組明細查詢（Single 模式）
  function detailRequest(row, form) {
    let ctl = row.CHARGE_TIME_LIST;
    if (typeof ctl === "string") { try { ctl = JSON.parse(ctl); } catch (e) { ctl = []; } }
    return { in_HospCode: row.HOSP_CODE, in_ChargeDate: row.charge_date, in_ChargeTimeList: ctl || [], in_PatientID: row.Patient_ID,
      in_CKNO: row.ckno, in_RequestCode: row.request_code, in_kind: row["報告類別"] || "",
      in_BeginDate: form.startdate, in_EndDate: form.enddate, in_TableStatus: "Single" };
  }
  // 院內 GetInspectionReportFormParameter：表單欄位 → startdate／enddate
  function formDates(pairs) {
    const d = {};
    for (const [k, v] of pairs || []) d[k] = k === "HOSP_CODE" && d[k] !== undefined ? d[k] + "," + v : v;
    if (d.CustromDate && d.CustromDate.indexOf(",") >= 0) { const p = d.CustromDate.split(","); d.startdate = p[0]; d.enddate = p[1]; }
    else if (d.NQuery_startdate) { d.startdate = d.NQuery_startdate; d.enddate = d.NQuery_enddate; }
    return { startdate: d.startdate, enddate: d.enddate };
  }
  const FLAG = /^(H|L|HH|LL|A|Y|\*)$/i;
  function parseDetail(result, kind) {
    return ((result && result.detailReport) || []).map((r) => ({
      name: String(r["項目"] || "").trim(), value: String(r["結果值"] == null ? "" : r["結果值"]).trim(),
      flag: FLAG.test(String(r.ABNORMAL_FLAG || "").trim()) ? String(r.ABNORMAL_FLAG).trim().toUpperCase() : "",
      critical: String(r["危急值通報"] || "").trim() && !/^(N|否|0)$/i.test(String(r["危急值通報"]).trim()) ? String(r["危急值通報"]).trim() : "",
      ref: String(r["標準值"] || "").trim(), sampled: String(r["採檢日"] || "").trim(), reported: String(r["報告日"] || "").trim(),
      code: String(r.DETAIL_CODE || "").trim(), kind: kind || "", unit: String(r["單位"] || "").trim(),
    })).filter((x) => x.name && !/^收到檢體$/.test(x.name));   // 「收到檢體」是採檢時間列，不是檢驗項目
  }
  const ANTI_TG = /anti.{0,3}(tg|thyroglobulin)|thyroglobulin.{0,3}(ab\b|antibod)|甲狀腺球蛋白抗體|\btg\s*-?\s*ab\b|ATA\b/i;
  // 糖尿病／內分泌門診常看的項目排前面（依項目名稱比對；代碼待院內實測補）
  const KEY_ITEMS = [
    ["HbA1c", /hba1c|a1c|glycated|醣化/i], ["Glucose", /glucose|sugar|血糖/i], ["Creatinine", /^(?!.*(albumin|ratio|urine|尿|micro)).*(creatinine|肌酸酐)|^cr$/i],
    ["eGFR", /egfr|gfr/i], ["UACR", /uacr|\bacr\b|albumin\s*\/\s*creat|白蛋白\s*\/\s*肌酸酐/i], ["LDL", /ldl/i], ["TG", { test: (n) => /triglycer|三酸甘油/i.test(n) || /^\s*TG\s*$/.test(n) }],
    ["Cholesterol", /^(t-?)?chol|cholesterol(?!.*(hdl|ldl))|總膽固醇/i], ["HDL", /hdl/i], ["K", /^k$|^k\+|potassium|鉀/i],
    ["ALT", /alt|gpt/i], ["TSH", /^(?!.*(receptor|trab|tsi|抗體)).*tsh/i], ["Free T4", /free\s*t4|ft4/i],
    // Tg：全大寫 TG 是三酸甘油脂、Tg 是 thyroglobulin（B 審 Minor 3；院內實際項目名稱待確認）；抗體另列 Anti-Tg
    ["Tg", { test: (n) => !ANTI_TG.test(n) && (/thyroglobulin|甲狀腺球蛋白/i.test(n) || /^\s*Tg\s*$/.test(n)) }], ["Anti-Tg", { test: (n) => ANTI_TG.test(n) }],
  ];
  // kind：報告類別；尿液報告裡的「Creatinine」是尿肌酸酐，不當血清 Cr（msg639 自己算 eGFR 時不能拿錯）
  function keyRank(name, kind) {
    for (let i = 0; i < KEY_ITEMS.length; i++) if (KEY_ITEMS[i][1].test(name)) return KEY_ITEMS[i][0] === "Creatinine" && URINE_ONLY.test(kind || "") ? KEY_ITEMS.length : i;
    return KEY_ITEMS.length;
  }
  function sortLabs(lines) {
    return lines.map((x, i) => ({ x, i, k: keyRank(x.name, x.kind) })).sort((a, b) => a.k - b.k || a.i - b.i).map((o) => Object.assign({}, o.x, { key: o.k < KEY_ITEMS.length }));
  }

  // 甲狀腺病人（老闆 msg583）：依上次門診診斷判斷；甲狀腺病人要看 TSH、free T4，甲狀腺癌再加 thyroglobulin（連 anti-Tg，Tg 要配 anti-Tg 才能判讀）
  const THY_DX = /^(E0[0-7]|E890|D34|C73|Z8585)/i, THY_CA = /^(C73|Z8585)/i;
  const THY_CA_NAME = /甲狀腺.{0,8}(癌|惡性)|thyroid\s*(cancer|carcinoma)|malignant\s+neoplasm\s+of\s+thyroid/i, THY_NAME = /甲狀腺|thyroid/i, PARA = /副甲狀腺|parathyroid/i;
  const thyName = (d) => THY_NAME.test(d) && !PARA.test(d);   // 副甲狀腺不算（B 審 Minor 4）
  function thyroidWant(dx) {
    const list = (dx || []).map((d) => String(d || ""));
    const code = (d) => d.replace(/[.\s]/g, "");
    const ca = list.some((d) => THY_CA.test(code(d)) || (THY_CA_NAME.test(d) && !PARA.test(d)));
    const thy = ca || list.some((d) => THY_DX.test(code(d)) || thyName(d));
    return !thy ? [] : ca ? ["TSH", "Free T4", "Tg", "Anti-Tg"] : ["TSH", "Free T4"];
  }
  // 甲狀腺結節病人（老闆 msg587）：看最近一次甲狀腺超音波與細胞學報告；甲狀腺癌追蹤也算
  const THY_NODULE = /^(E04|D34|D440|C73|Z8585)/i, THY_NODULE_NAME = /結節|nodule|goiter|腫|癌|惡性|cancer|carcinoma|neoplasm/i;
  function thyroidNodule(dx) {
    return (dx || []).map((d) => String(d || "")).some((d) => THY_NODULE.test(d.replace(/[.\s]/g, "")) || (thyName(d) && THY_NODULE_NAME.test(d)));   // 名稱要同時是甲狀腺（肺結節不算）
  }
  const keyName = (name, kind) => { const k = keyRank(name, kind); return k < KEY_ITEMS.length ? KEY_ITEMS[k][0] : ""; };
  // ---------- eGFR、UACR 自己算（老闆 msg639：院內沒有直接報，「更多資訊／圖表」只給圖片）----------
  // 院內公式說明：18 歲以上用 EPI 公式（未滿 18 歲用 Schwartz，要身高，不算）；ACR＝尿 Albumin／尿 Creatinine×1000（mg/gm）
  const unitOf = (x) => { const r = typeof x === "object" && x ? (x.unit || "") + " " + (x.ref || "") : String(x || ""); return /[µμu]mol/i.test(r) ? "umol/L" : /mg\s*\/\s*dl/i.test(r) ? "mg/dL" : /mg\s*\/\s*l\b/i.test(r) ? "mg/L" : ""; };
  const isUrineKind = (x) => URINE_ONLY.test(x.kind || "") || /urine|尿|\(u\)|^u[-\s]/i.test(x.name || "");
  const isUrineAlb = (x) => isUrineKind(x) && /albumin|白蛋白|micro\s*alb/i.test(x.name || "") && !/ratio|\/|globulin|球蛋白/i.test(x.name || "");
  const isUrineCr = (x) => isUrineKind(x) && /creatinine|肌酸酐|\bcre\b|^\s*cr\s*$/i.test(x.name || "") && !/ratio|\/|clearance|廓清/i.test(x.name || "");
  const isSerumCr = (x) => keyName(x.name, x.kind) === "Creatinine";
  const num = (v) => { const m = String(v == null ? "" : v).replace(/,/g, "").match(/-?\d+(\.\d+)?/); return m && !/[<>]/.test(String(v)) ? parseFloat(m[0]) : NaN; };
  // CKD-EPI（肌酸酐，mg/dL）：2021 版不分種族；2009 版不含種族係數（台灣不用黑人係數）
  function ckdEpi(cr, age, sex, version) {
    const f = sex === "F";
    if (!(cr > 0) || !(age >= 18) || (sex !== "F" && sex !== "M")) return NaN;
    if (version === "2009") {
      const k = f ? 0.7 : 0.9, a = f ? -0.329 : -0.411;
      return 141 * Math.pow(Math.min(cr / k, 1), a) * Math.pow(Math.max(cr / k, 1), -1.209) * Math.pow(0.993, age) * (f ? 1.018 : 1);
    }
    const k = f ? 0.7 : 0.9, a = f ? -0.241 : -0.302;
    return 142 * Math.pow(Math.min(cr / k, 1), a) * Math.pow(Math.max(cr / k, 1), -1.2) * Math.pow(0.9938, age) * (f ? 1.012 : 1);
  }
  // MDRD-S（院內 GFR 圖用的；存檔反推：男 46 歲 Cr 0.98 → 82.34，msg645／648）
  function mdrd(cr, age, sex) {
    if (!(cr > 0) || !(age >= 18) || (sex !== "F" && sex !== "M")) return NaN;
    return 175 * Math.pow(cr, -1.154) * Math.pow(age, -0.203) * (sex === "F" ? 0.742 : 1);
  }
  const EGFR_VERSION = "2021";   // 院內只寫「EPI」，待老闆提供一例反推是 2009 還是 2021（msg643）
  // 身分證字號第 2 碼：1／8／A／C 男，2／9／B／D 女（只在讀取框裡用，不回傳字號）
  const sexFromId = (id) => { const c = String(id || "").trim().toUpperCase().charAt(1); return /[18AC]/.test(c) ? "M" : /[29BD]/.test(c) ? "F" : ""; };
  // 生日（yyyy/mm/dd 或民國）到某天（yyyymmdd）的足歲
  function ageAt(birth, key) {
    const b = ymd(birth); if (!b || !/^\d{8}$/.test(key || "")) return NaN;
    return +key.slice(0, 4) - +b.slice(0, 4) - (key.slice(4) < b.slice(4) ? 1 : 0);
  }
  const sexOf = (s) => (/女|^f/i.test(String(s || "")) ? "F" : /男|^m/i.test(String(s || "")) ? "M" : "");
  const ageOf = (s) => { const m = String(s || "").match(/\d+/); return m ? +m[0] : NaN; };
  // 同一張尿液報告（同報告類別、同採檢日）裡的尿白蛋白與尿肌酸酐 → UACR（mg/g）。單位：白蛋白 mg/L 先換成 mg/dL；Cr 是 µmol/L 就不算；
  // 沒寫單位時照院內公式的假設（兩者都是 mg/dL）
  function pairUACR(lines) {
    const groups = new Map();
    for (const x of lines || []) {
      if (!isUrineAlb(x) && !isUrineCr(x)) continue;
      const g = (x.kind || "") + "|" + (x.sampled || x.date || "");
      if (!groups.has(g)) groups.set(g, { alb: null, cr: null });
      const o = groups.get(g); if (isUrineAlb(x) && !o.alb) o.alb = x; else if (isUrineCr(x) && !o.cr) o.cr = x;
    }
    for (const o of groups.values()) {
      if (!o.alb || !o.cr) continue;
      let alb = num(o.alb.value); const cr = num(o.cr.value), ua = unitOf(o.alb), uc = unitOf(o.cr);
      if (uc === "umol/L" || ua === "umol/L" || !(cr > 0) || !(alb >= 0)) return { pair: o, value: NaN, why: "單位或數值無法計算" };
      if (ua === "mg/L") alb = alb / 10;
      return { pair: o, value: alb / cr * 1000, date: o.alb.date || o.alb.sampled || "", assumed: !ua || !uc };
    }
    return null;
  }
  // 補查是否已經有：eGFR 有院內值或有血清 Cr（可以算）就算有；UACR 有院內值或有同一張尿液報告的白蛋白＋肌酸酐就算有
  function hasKey(lines, k) {
    const has = (x, n) => keyName(x.name, x.kind) === n && !isNaN(num(x.value));
    if (k === "eGFR") return (lines || []).some((x) => has(x, "eGFR") || (isSerumCr(x) && !isNaN(num(x.value))));
    if (k === "UACR") return (lines || []).some((x) => has(x, "UACR")) || !!pairUACR(lines);
    return (lines || []).some((x) => keyName(x.name, x.kind) === k);
  }
  // 補查時，一張報告裡跟 k 有關的那幾行
  function linesFor(lines, k) {
    if (k === "eGFR") return (lines || []).filter((x) => keyName(x.name, x.kind) === "eGFR" || isSerumCr(x));
    if (k === "UACR") { const r = (lines || []).filter((x) => keyName(x.name, x.kind) === "UACR"); if (r.length) return r; const p = pairUACR(lines); return p ? [p.pair.alb, p.pair.cr] : []; }
    return (lines || []).filter((x) => keyName(x.name, x.kind) === k);
  }
  // 院內沒報 eGFR／UACR 時自己算，標「外掛計算」
  function deriveRenal(lines, age, sex, version) {
    const out = [], ver = version || EGFR_VERSION, a = ageOf(age), sx = sexOf(sex);
    const reported = (k) => (lines || []).some((x) => keyName(x.name, x.kind) === k && !isNaN(num(x.value)));   // 院內那一列是空白、—、* 都當沒報（B 審）
    if (!reported("eGFR")) {
      const crl = (lines || []).find(isSerumCr);
      if (crl) {
        const cr = num(crl.value), u = unitOf(crl);
        const why = u === "umol/L" ? "Cr 單位是 µmol/L，未計算" : !(cr > 0) ? "Cr 數值無法判讀，未計算" : !(a >= 18) ? "未滿 18 歲（院內用 Schwartz，需身高），未計算" : !sx ? "性別不明，未計算" : "";
        // 兩個都列（老闆 msg652）：CKD-EPI 2021 與 MDRD（＝院內 GFR 圖）
        const src = `Cr ${crl.value}${crl.date ? "（" + crl.date + "）" : ""}`;
        const v = why ? NaN : ckdEpi(cr, a, sx, ver), m = why ? NaN : mdrd(cr, a, sx);
        out.push({ name: `eGFR（EPI ${ver}）`, value: why ? "—" : v.toFixed(1), flag: !why && v < 60 ? "L" : "", calc: true, note: why || `外掛計算：CKD-EPI ${ver}，${src}`, date: crl.date || "" });
        if (!why) out.push({ name: "eGFR（MDRD，同院內圖）", value: m.toFixed(1), flag: m < 60 ? "L" : "", calc: true, note: `外掛計算：MDRD-S 175×Cr^-1.154×年齡^-0.203${sx === "F" ? "×0.742" : ""}，${src}`, date: crl.date || "" });
      }
    }
    if (!reported("UACR")) {
      const p = pairUACR(lines);
      if (p) out.push({ name: "UACR", value: isNaN(p.value) ? "—" : p.value.toFixed(1), flag: p.value >= 30 ? "H" : "", calc: true,
        note: isNaN(p.value) ? p.why : `外掛計算：尿白蛋白 ${p.pair.alb.value} ÷ 尿肌酸酐 ${p.pair.cr.value} × 1000（mg/g）` + (p.assumed ? "，單位依院內公式視為 mg/dL" : ""), date: p.date });
    }
    return out;
  }
  // ---------- 一年內「項目 × 日期」（老闆 msg658；院內檢驗頁「整合」Mix 模式）----------
  // 民國日期標籤：20260612 → 115年6月12日
  const rocLabel = (key) => (/^\d{8}$/.test(key || "") ? (+key.slice(0, 4) - 1911) + "年" + +key.slice(4, 6) + "月" + +key.slice(6, 8) + "日" : "");
  // results：[{kind, res}]，res 是院內 Mix 回應 {columnsDateTime:["yyyymmdd…"], rowItems:["項目@檢體"], mixTableData:[{COLLECT_DATE_N, 項目, CHART_VALUE}]}
  // 同一天多次採檢併成一欄（取第一個有值的）；from／to：yyyymmdd 範圍（一年內）
  function mixMerge(results, from, to) {
    const items = new Map(), days = new Set();
    for (const { kind, res } of results || []) {
      if (!res || !Array.isArray(res.columnsDateTime) || !Array.isArray(res.mixTableData)) continue;
      const order = Array.isArray(res.rowItems) ? res.rowItems : [];
      for (const raw of order) {
        const [name, spec] = String(raw || "").split("@");
        const nm = String(name || "").trim(); if (!nm || /^收到檢體$/.test(nm)) continue;
        const urine = /urine|尿/i.test(spec || "");
        const k = nm + "@" + (spec || "") + "@" + (urine ? "U" : kind);
        if (!items.has(k)) items.set(k, { name: nm, spec: String(spec || "").trim(), kind: urine ? "尿液檢驗" : kind, values: {}, raw: String(raw) });
      }
      for (const d of res.mixTableData) {
        const day = String(d.COLLECT_DATE_N || "").replace(/\D/g, "").slice(0, 8);
        if (!/^\d{8}$/.test(day) || (from && day < from) || (to && day > to)) continue;
        const v = String(d.CHART_VALUE == null ? "" : d.CHART_VALUE).trim(); if (!v) continue;
        const [name, spec] = String(d["項目"] || "").split("@");
        const urine = /urine|尿/i.test(spec || "");
        const it = items.get(String(name || "").trim() + "@" + (spec || "") + "@" + (urine ? "U" : kind));
        if (!it) continue;
        if (!(day in it.values)) it.values[day] = v;
        days.add(day);
      }
    }
    const list = [...items.values()].filter((x) => Object.keys(x.values).length)
      .map((x, i) => ({ x, i, k: keyRank(x.name, x.kind) })).sort((a, b) => a.k - b.k || a.i - b.i)
      .map((o) => Object.assign(o.x, { key: o.k < KEY_ITEMS.length, label: o.x.name + (o.x.kind === "尿液檢驗" && !/^u[-\s]|urine|尿|\(u\)/i.test(o.x.name) ? "（尿）" : "") }));
    return { dates: [...days].sort(), items: list };
  }
  // 每一天各自算 eGFR（EPI 2021、MDRD）與 UACR（同一天的尿液報告）；年齡用生日算到那天
  function mixDerive(m, birth, sex, ageFallback) {
    const rows = { epi: { name: "eGFR（EPI 2021）", values: {}, notes: {} }, mdrd: { name: "eGFR（MDRD，同院內圖）", values: {}, notes: {} }, uacr: { name: "UACR", values: {}, notes: {} } };
    for (const day of m.dates) {
      const lines = m.items.filter((x) => day in x.values).map((x) => ({ name: x.name, value: x.values[day], kind: x.kind, sampled: day }));
      const a0 = birth ? ageAt(birth, day) : NaN, age = isNaN(a0) ? ageOf(ageFallback) : a0;   // 生日讀不懂時退回清單上的年齡（B 審 Minor 1）
      for (const d of deriveRenal(lines, age, sex)) {
        const r = /^eGFR（EPI/.test(d.name) ? rows.epi : /MDRD/.test(d.name) ? rows.mdrd : d.name === "UACR" ? rows.uacr : null;
        if (r) { r.values[day] = d.value + (d.flag ? " " + d.flag : ""); r.notes[day] = d.note; }
      }
    }
    return [rows.epi, rows.mdrd, rows.uacr].filter((r) => Object.keys(r.values).length);
  }
  // want 裡還沒在 lines 出現的項目
  const missingKeys = (lines, want) => (want || []).filter((k) => !hasKey(lines, k));
  // Mix 一年內完全沒有的（eGFR 有 Cr 就算有；UACR 有院內值或同一天的白蛋白＋肌酸酐）
  function mixMissing(m, want) {
    return (want || []).filter((k) => !m.dates.some((day) => hasKey(m.items.filter((x) => day in x.values).map((x) => ({ name: x.name, value: x.values[day], kind: x.kind, sampled: day })), k)));
  }
  // 最近一次抽血以前、可能有 want 項目的日期（新到舊）：排除培養等、只有尿液的那天；最多 maxDates 天
  // 補查用（msg631：eGFR、UACR 固定顯示；甲狀腺項目）：最近一次抽血那天以外的日期（新到舊），排除培養等。
  // urine：要找 UACR 時連只有尿液的報告也找（驗尿常和抽血不同天，前後都可能，B 提醒）；blood：要找血液項目時找非尿液報告
  function otherDraws(dates, skipKey, maxDates, opt) {
    const o = opt || { blood: true, urine: false };
    const ds = (dates || []).filter((d) => /^\d{8}$/.test(d.key) && d.key !== skipKey).sort((a, b) => (a.key < b.key ? 1 : -1));
    const out = [];
    for (const d of ds) {
      const reps = (d.reports || []).filter((r) => { const k = String(r["報告類別"] || ""); if (NOT_BLOOD.test(k)) return false; return URINE_ONLY.test(k) ? !!o.urine : !!o.blood; });
      if (reps.length) out.push({ key: d.key, reports: reps });
      if (out.length >= (maxDates || 12)) break;
    }
    return out;
  }
  function olderDraws(dates, beforeKey, maxDates) {
    const ds = (dates || []).filter((d) => /^\d{8}$/.test(d.key) && d.key < beforeKey).sort((a, b) => (a.key < b.key ? 1 : -1));
    const out = [];
    for (const d of ds) {
      const reps = (d.reports || []).filter((r) => !NOT_BLOOD.test(String(r["報告類別"] || "")) && !URINE_ONLY.test(String(r["報告類別"] || "")));
      if (reps.length) out.push({ key: d.key, reports: reps });
      if (out.length >= (maxDates || 12)) break;
    }
    return out;
  }

  // ---------- 目前用藥（老闆 msg585／591／592）：用藥頁 /WEB/MRN/MedicineInfo（含雲端藥歷）----------
  // rows：[{hosp, src, drug, atc, code, start, end, days, left}]；同一個藥（健保碼，沒有就用藥名）取結束日最新的那筆，
  // 列出：①上次門診開的藥一律列（晚回診的慢性病人也看得到，B 審 Major）。
  //         lastVisit＝SOAP 選中的那次就醫日：取本院那天開始的藥；那天沒有藥（例如開始日記錄不同）就取那天以後本院開的藥。
  //         沒有 lastVisit（本科初診）才退回本院起始日最新那天。用「那天出現過的健保碼」判斷，不看去重後留下那筆的起始日（B 複審 Major／Minor）
  //       ②其他（含雲端）還沒到期或到期不超過 graceDays 天的。比較接近「有效處方」：上次停掉的藥若原處方未到期仍會列出。
  // 其餘算「已到期」，回傳筆數讓畫面註明。本院在前、外院（來源「其」＝雲端藥歷）在後
  function currentMeds(rows, today, graceDays, lastVisit) {
    const t = /^\d{8}$/.test(today || "") ? new Date(+today.slice(0, 4), +today.slice(4, 6) - 1, +today.slice(6, 8)) : new Date();
    const f = new Date(t); f.setDate(f.getDate() - (graceDays == null ? 30 : graceDays));
    const lim = f.getFullYear() + String(f.getMonth() + 1).padStart(2, "0") + String(f.getDate()).padStart(2, "0");
    const last = new Map(), td = /^\d{8}$/.test(today || "") ? today : "99999999";
    const isCloud = (r) => /其|雲/.test(String(r.src || ""));
    const keyOf = (r) => String(r.code || "").trim() || String(r.drug || "").replace(/\s+/g, " ").trim().replace(/\s*\d+\s*天$/, "");
    const own = (rows || []).filter((r) => !isCloud(r) && ymd(r.start) && ymd(r.start) <= td && String(r.drug || "").trim());
    const lv = ymd(lastVisit);
    let lastRx = "", rxRows = [];
    if (lv) {
      rxRows = own.filter((r) => ymd(r.start) === lv);
      if (!rxRows.length) rxRows = own.filter((r) => ymd(r.start) >= lv);
      lastRx = lv;
    } else {
      for (const r of own) if (ymd(r.start) > lastRx) lastRx = ymd(r.start);
      rxRows = own.filter((r) => ymd(r.start) === lastRx);
    }
    const rxKeys = new Set(rxRows.map(keyOf));
    for (const r of rows || []) {
      const drug = String(r.drug || "").replace(/\s+/g, " ").trim(), end = ymd(r.end);
      if (!drug || !end) continue;
      const k = keyOf(r);
      const prev = last.get(k);
      if (!prev || end > prev._end) last.set(k, { hosp: String(r.hosp || "").trim(), src: String(r.src || "").trim(), drug, atc: String(r.atc || "").trim(), code: String(r.code || "").trim(),
        start: fmtDate(ymd(r.start)), end: fmtDate(end), days: String(r.days || "").trim(), left: parseInt(r.left, 10) || 0, cloud: isCloud(r), _end: end, _k: k });
    }
    const all = [...last.values()];
    for (const x of all) x.lastRx = !x.cloud && rxKeys.has(x._k);
    const list = all.filter((x) => x.lastRx || x._end >= lim).sort((a, b) => (a.cloud - b.cloud) || (b.lastRx - a.lastRx) || (a.drug < b.drug ? -1 : a.drug > b.drug ? 1 : 0));
    return { list: list.map(({ _end, _k, ...x }) => x), total: (rows || []).length, lastRx: fmtDate(lastRx), fromVisit: !!lv, expired: all.length - list.length };
  }

  // ---------- 檢查：一年內眼底攝影 ----------
  const FUNDUS = /眼底|fundus|retina|視網膜/i, NOT_FUNDUS = /\bOCT\b|光學同調|黃斑部斷層/i;
  // rows：檢查報告頁第 3 個 tbody 裡 onclick=showReport 的列 {text, content}；today：yyyymmdd
  function pickFundus(rows, today) {
    const t = new Date(+today.slice(0, 4), +today.slice(4, 6) - 1, +today.slice(6, 8));
    const from = new Date(t); from.setFullYear(t.getFullYear() - 1);
    const lim = from.getFullYear() + String(from.getMonth() + 1).padStart(2, "0") + String(from.getDate()).padStart(2, "0");
    // 只看檢查名稱那一列的文字，不看報告內文（內文提到 retina 的 OCT 不算，B 審 Minor）
    const hits = (rows || []).filter((r) => FUNDUS.test(r.text || "") && !NOT_FUNDUS.test(r.text || ""))
      .map((r) => ({ date: ymd(r.text) || ymd(r.content), name: String(r.text || "").replace(/\s+/g, " ").trim(), report: String(r.content || "").replace(/\r\n?/g, "\n").trim() }))
      .filter((r) => r.date && r.date >= lim && r.date <= today);
    hits.sort((a, b) => (a.date < b.date ? 1 : a.date > b.date ? -1 : 0));
    return { latest: hits[0] || null, count: hits.length };
  }
  // 檢查報告頁預設查詢區間太短（老闆 msg575：要選「2年」才抓得到一年內的眼底攝影）。
  // 照院內頁面「查詢區間」下拉選 2年 時送出的表單：其他欄位照抄（含 AjaxRequestKey、院區），只換日期三欄。
  // options：下拉選單 [{value, text}]；優先用院內「2年」那一項的值，找不到才自己算 today 往前 2 年
  // all=true（甲狀腺結節病人要「最近一次」超音波、細胞學，不限 2 年）：照院內選「全部」的做法，1990/01/01 到下個月
  function examRangeForm(pairs, options, today, all) {
    const RANGE = /^\d{4}\/\d{2}\/\d{2},\d{4}\/\d{2}\/\d{2}$/;
    const t = /^\d{8}$/.test(today || "") ? new Date(+today.slice(0, 4), +today.slice(4, 6) - 1, +today.slice(6, 8)) : new Date();
    const fmt = (d) => d.getFullYear() + "/" + String(d.getMonth() + 1).padStart(2, "0") + "/" + String(d.getDate()).padStart(2, "0");
    let val, start, end;
    if (all) {
      const e = new Date(t); e.setMonth(e.getMonth() + 1);
      val = "ALL"; start = "1990/01/01"; end = fmt(e);
    } else {
      const opt = (options || []).find((o) => /^\s*2\s*年/.test(o.text || "") && RANGE.test(String(o.value || "").trim()));
      if (opt) val = String(opt.value).trim();
      else { const f = new Date(t); f.setFullYear(t.getFullYear() - 2); val = fmt(f) + "," + fmt(t); }
      [start, end] = val.split(",");
    }
    const out = (pairs || []).filter(([k]) => !["CustromDate", "NQuery_startdate", "NQuery_enddate"].includes(k));
    out.push(["CustromDate", val], ["NQuery_startdate", start], ["NQuery_enddate", end]);
    return out;
  }
  // 甲狀腺超音波：列文字（報告類別）含「甲狀腺超音波」；細胞學：同細胞學外掛，列文字含「病理報告」且報告含「Thyroid aspiration」
  const THY_US = /甲狀腺.{0,4}超音波|thyroid.{0,12}(sono|ultrasound|echo)/i;
  const isThyUS = (r) => THY_US.test(r.text || "");
  const isThyCyto = (r) => /病理報告/.test(r.text || "") && /thyroid\s+aspiration/i.test(r.content || "");
  function latestRow(rows, test, today) {
    const hits = (rows || []).filter(test).map((r) => ({ date: ymd(r.text) || ymd(r.content), name: String(r.text || "").replace(/\s+/g, " ").trim(), report: String(r.content || "").replace(/\r\n?/g, "\n").trim() }))
      .filter((r) => r.date && (!today || r.date <= today));
    hits.sort((a, b) => (a.date < b.date ? 1 : a.date > b.date ? -1 : 0));
    return { latest: hits[0] || null, count: hits.length };
  }
  // 細胞學診斷：Diagnosis 到 Specimen adequacy 之間（同細胞學外掛）；找不到就用結論段
  function cytoDiagnosis(report) {
    const c = String(report || "").replace(/\r\n?/g, "\n");
    const m = c.match(/Diagnosis:\s*([\s\S]*?)\n\s*Specimen adequacy:/i);
    return (m ? m[1] : conclusion(c)).trim().slice(0, 400);
  }
  // 細胞學結果分類（老闆 msg629：只顯示日期和結果 benign、atypia…）：先看 Bethesda 分級，沒有就看 Diagnosis 用字
  // 否定句（negative for…、no evidence of…）先刪掉再判斷（同細胞學外掛），避免「Negative for malignancy」被當成 malignant
  const BETHESDA = { I: "Nondiagnostic (I)", II: "Benign (II)", III: "AUS/atypia (III)", IV: "Follicular neoplasm (IV)", V: "Suspicious for malignancy (V)", VI: "Malignant (VI)" };
  function cytoCategory(diagnosis) {
    const raw = String(diagnosis || "");
    const b = raw.match(/bethesda\s*(?:category\s*|class\s*|系統\s*)?[:：]?\s*(VI|IV|V|III|II|I)\b/i) || raw.match(/\b(?:category|class)\s*(VI|IV|V|III|II|I)\b/i);
    if (b) return BETHESDA[b[1].toUpperCase()];
    if (/non-?diagnostic|unsatisfactory|insufficient|inadequate/i.test(raw)) return BETHESDA.I;
    if (/cannot\s+(be\s+)?(rule[ds]?\s+out|excluded?)|\br\/o\b/i.test(raw)) return BETHESDA.V;
    const d = raw.replace(/\b(negative\s+for|no\s+evidence\s+of|no|without|free\s+of)\b[^.;\n]*?(?=\bbut\b|\bhowever\b|[.;\n]|$)/gi, " ");
    if (/suspicious\s+for/i.test(d)) return BETHESDA.V;
    if (/malignan|carcinoma|cancer|metasta|lymphoma/i.test(d)) return BETHESDA.VI;
    if (/follicular\s+neoplasm|hurthle|oncocytic\s+neoplasm/i.test(d)) return BETHESDA.IV;
    if (/atypi|\bAUS\b|\bFLUS\b/i.test(d)) return BETHESDA.III;
    if (/benign|nodular\s+goiter|colloid|thyroiditis|hyperplastic/i.test(d)) return BETHESDA.II;
    return "";
  }
  // SOAP 分欄（老闆 msg629：S、A、P 三欄）：依院內 TITLE 歸類；O 與認不得的另外放
  function soapColumns(soap) {
    const out = { S: [], O: [], A: [], P: [], other: [] };
    const kind = (t) => {
      const x = String(t || "").trim();
      if (/^(s\b|s\s*[:：.)]|subj|主訴|病史|現病史|chief\s*complaint|present\s*illness)/i.test(x)) return "S";
      if (/^(o\b|o\s*[:：.)]|obj|理學|physical|身體檢查)/i.test(x)) return "O";
      if (/^(a\s*[&＆\/+]\s*p|a\b|a\s*[:：.)]|assess|診斷|impression)/i.test(x)) return "A";   // 院內常見「A&P」
      if (/^(p\b|p\s*[:：.)]|plan|處置|計畫|計劃|治療)/i.test(x)) return "P";
      return "other";
    };
    for (const v of soap || []) { const k = kind(v.title); out[k].push(k === "other" && v.title ? v.title + "：\n" + v.text : v.text); }
    const j = (a) => a.filter(Boolean).join("\n").trim();
    return { S: j(out.S), O: j(out.O), A: j(out.A), P: j(out.P), other: j(out.other) };
  }
  // 用藥字串拆成藥名與用法（院內「Metformin (Glucophage 500mg/Tab) 1 Tab PO BID 28天」）：最後一個「)」之前是藥名
  function splitDrug(text) {
    const t = String(text || "").replace(/\s+/g, " ").trim(), i = t.lastIndexOf(")");
    if (i > 0 && i < t.length - 1) return { name: t.slice(0, i + 1).trim(), use: t.slice(i + 1).trim() };
    return { name: t, use: "" };
  }
  // 報告裡的結論段（Impression／結論／診斷），找不到就回全文
  function conclusion(report) {
    const m = String(report || "").match(/(impression|conclusion|結論|診斷|diagnosis)\s*[:：]?\s*([\s\S]{1,400})/i);
    return (m ? m[2] : String(report || "")).trim().slice(0, 400);
  }

  // ---------- CSV（老闆 msg569）：只在按鈕按下時產生；沒有身分證字號；防公式注入；UTF-8 BOM 讓 Excel 認得中文 ----------
  function csvCell(v) {
    let t = v == null ? "" : String(v);
    // 開頭是 = + @ Tab CR 的一律加 '；開頭是 - 的只有不是單純數字時才加（檢驗值 -1.5 保持數字）
    if (/^[=+@\t\r]/.test(t) || (/^-/.test(t) && !/^-\d+(\.\d+)?$/.test(t))) t = "'" + t;
    return /[",\r\n]/.test(t) ? '"' + t.replace(/"/g, '""') + '"' : t;
  }
  const CSV_HEAD = ["序號", "病歷號", "姓名", "性別", "年齡", "看診日", "上次門診日", "上次門診科別", "上次門診醫師", "SOAP", "診斷", "目前用藥",
    "抽血日", "抽血類別", "重點檢驗", "其他異常", "其他項目", "眼底攝影日", "一年內眼底次數", "眼底結論", "甲狀腺超音波日", "超音波結論", "細胞學日", "細胞學診斷", "本季流感", "本季新冠", "今年其他疫苗", "讀取狀態"];
  const drugTxt = (x) => x.drug + (x.cloud ? "［" + x.hosp + "］" : "") + (x.left > 0 ? "（剩 " + x.left + " 天）" : "（" + x.end + " 到期）");
  // 一年內「項目 × 日期」的 CSV：抽血日（民國）、類別、重點項目（含外掛計算）每次的值、其他項目
  function mixCsv(d) {
    const one = (label, values) => label + "：" + d.dates.filter((k) => values[k]).map((k) => values[k] + "（" + rocLabel(k) + "）").join("、");
    return [d.dates.map(rocLabel).join("、"), (d.kinds || []).join("、"),
      d.items.filter((x) => x.key).map((x) => one(x.label, x.values)).concat((d.derived || []).map((x) => one(x.name + "（外掛計算）", x.values)),
        d.missing && d.missing.length ? [(d.full === false ? "這段期間查無：" : "一年內查無：") + d.missing.join("、")] : []).join("\n"),
      "", d.items.filter((x) => !x.key).map((x) => one(x.label, x.values)).join("\n")];
  }
  const labTxt = (x) => x.name + " " + x.value + (x.flag ? " " + x.flag : "") + (x.critical ? "（危急值）" : "");
  const fail = (r) => (r && r.error ? "（讀取失敗：" + r.error + "）" : "");
  function csvRow(p, d) {
    d = d || {};
    const so = d.soap, lb = d.labs, fu = d.fundus, va = d.vac, md = d.meds;
    const soOk = so && so.data && !so.data.none, lbOk = lb && lb.data && !lb.data.none, fuOk = fu && fu.data && !fu.data.format, vaOk = va && va.data && !va.data.format;
    const lines = lbOk ? lb.data.lines : [];
    return [p.seq, p.chart, p.name, p.sex, p.age, p.visitDate,
      soOk ? so.data.visit.date : fail(so) || (so && so.data && so.data.none ? "本科初診" : ""), soOk ? so.data.visit.dept : "", soOk ? so.data.visit.doctor + (so.data.visit.tier === "dept" ? "（本科其他醫師）" : "") : "",
      soOk ? so.data.soap.map((x) => (x.title ? x.title + "：\n" : "") + x.text).join("\n") : "", soOk ? (so.data.dx || []).join("；") : "", md && md.data && md.data.list ? md.data.list.map(drugTxt).concat(md.data.expired ? ["另有 " + md.data.expired + " 項已到期超過 30 天"] : []).join("\n") : fail(md),
      ...(lbOk && lb.data.mix ? mixCsv(lb.data) : [
      lbOk ? lb.data.date : fail(lb) || (lb && lb.data && lb.data.none ? "（查無抽血報告）" : ""), lbOk ? lb.data.kinds.join("、") : "",
      lines.filter((x) => x.key).map(labTxt).concat(lbOk ? (lb.data.derived || []).map((x) => labTxt(x) + "（" + x.note + "）") : [], lbOk ? (lb.data.extra || []).map((x) => labTxt(x) + "（" + x.date + "）") : [],
        lbOk && lb.data.missing && lb.data.missing.length ? ["另查 " + (lb.data.looked || 0) + " 次檢驗仍查無：" + lb.data.missing.join("、")] : []).join("; "), lines.filter((x) => !x.key && (x.flag || x.critical)).map(labTxt).join("; "),
      lines.filter((x) => !x.key && !x.flag && !x.critical).map(labTxt).join("; ")]),
      fuOk ? (fu.data.latest ? fu.data.latest.date : "一年內無") : fail(fu), fuOk ? fu.data.count : "", fuOk && fu.data.latest ? fu.data.latest.conclusion : "",
      fuOk && fu.data.thy ? (fu.data.thy.us ? fu.data.thy.us.date : "查無") : "", fuOk && fu.data.thy && fu.data.thy.us ? fu.data.thy.us.conclusion : "",
      fuOk && fu.data.thy ? (fu.data.thy.cyto ? fu.data.thy.cyto.date : "查無") : "", fuOk && fu.data.thy && fu.data.thy.cyto ? [fu.data.thy.cyto.category, fu.data.thy.cyto.diagnosis].filter(Boolean).join("｜") : "",
      vaOk ? (va.data.flu ? va.data.flu.date : "未打") : fail(va), vaOk ? (va.data.covid ? va.data.covid.date : "未打") : "",
      vaOk ? va.data.others.map((o) => o.kind + " " + o.date).join("; ") : "", d.status || "未讀取"];
  }
  // 病歷號開頭的 0 在 Excel 雙擊打開時會被吃掉（B 審 Minor 1）：病歷號那一欄寫成 ="00123456"，Excel 會當文字顯示。
  // 只有病歷號是純英數字時才這樣寫（外掛自己驗過的值，不會變成別的公式），其他一律走 csvCell
  const chartCell = (c) => (/^[A-Za-z0-9]{1,15}$/.test(String(c || "")) ? '="' + c + '"' : csvCell(c));
  function toCSV(list) {
    const rows = (list || []).map((x) => csvRow(x.p, x.d));
    const body = rows.map((r) => r.map((v, i) => (i === 1 ? chartCell(v) : csvCell(v))).join(","));
    return "\uFEFF" + [CSV_HEAD.map(csvCell).join(",")].concat(body).join("\r\n") + "\r\n";
  }
  // 檔名只放院區、看診日、科別、午別、時間（不放病人資料）；去掉檔名不能用的字元
  function csvName(hosp, visitDate, dept, noon, now) {
    const t = now || new Date(), hm = String(t.getHours()).padStart(2, "0") + String(t.getMinutes()).padStart(2, "0");
    return ["門診工作台", hosp, ymd(visitDate) || todayKey(t), dept, noon, hm].filter(Boolean).join("_").replace(/[\\/:*?"<>|\s]+/g, "") + ".csv";
  }

  // ---------- 疫苗：本季流感／新冠、今年打過的 ----------
  // rows：/WEB/MRN/Vaccine 表格（表頭 施打日、疫苗種類、疫苗說明、上傳來源、劑別、距今時間）每列 {date, kind, desc, source, dose}
  // 本季＝今年 10/1 起（今天還沒到 10/1 就從去年 10/1 起），台灣流感、新冠疫苗每年 10 月開打
  const FLU = /流感|influenza|\bflu\b/i, COVID = /cov|covid|新冠/i;
  function seasonStart(today) { const y = +today.slice(0, 4), md = today.slice(4); return (md >= "1001" ? y : y - 1) + "1001"; }
  function vaccineSummary(rows, today) {
    const vs = (rows || []).map((r) => Object.assign({}, r, { key: ymd(r.date) })).filter((r) => r.key && r.key <= today)
      .sort((a, b) => (a.key < b.key ? 1 : a.key > b.key ? -1 : 0));
    const from = seasonStart(today), year = today.slice(0, 4);
    const isFlu = (r) => FLU.test(r.kind || "") || FLU.test(r.desc || ""), isCov = (r) => !isFlu(r) && (COVID.test(r.kind || "") || COVID.test(r.desc || ""));
    const flu = vs.find((r) => isFlu(r) && r.key >= from) || null, cov = vs.find((r) => isCov(r) && r.key >= from) || null;
    const others = vs.filter((r) => r.key.slice(0, 4) === year && !isFlu(r) && !isCov(r));
    return { season: from, flu, covid: cov, others, total: vs.length };
  }

  const fmtDate = (k) => (/^\d{8}$/.test(k) ? k.slice(0, 4) + "/" + k.slice(4, 6) + "/" + k.slice(6, 8) : String(k || ""));
  function todayKey(d) { d = d || new Date(); return d.getFullYear() + String(d.getMonth() + 1).padStart(2, "0") + String(d.getDate()).padStart(2, "0"); }

  // 頁面文字裡的病歷號（同甲狀腺外掛）：「病歷號：00123456」；回傳找到的號碼陣列
  function chartsInText(text) {
    return [...String(text || "").matchAll(/病歷號(?:碼)?\s*[：:]?\s*([A-Za-z]{0,2}\d{6,13}(?:[-－]\d)?)(?![\d\/\-.])/g)].map((m) => m[1].replace(/[-－]/g, ""));
  }

  // ---------- 存到病人管理（v0.5.0，老闆 msg858／860／864）：加密匯出檔 .pmx ----------
  // 院內電腦連不到家裡的病人管理網站 → 把卡片已讀到的資料組成資料包，用病人管理的「公鑰」加密後下載，回家上傳。
  // 加密：ECDH P-256（每個檔一把一次性金鑰）→ HKDF-SHA256(info="pmx-v1"‖epk‖收件人公鑰) → AES-256-GCM(AAD=全部標頭)
  // 身分證字號不放（工作台隱私設計不變）。只用卡片已讀到的資料，不另外查院內系統。
  const PMX_HOSP = { "高醫附院": "KMUH", "高醫岡山": "KMUGH" };
  const pmxHosp = (name) => PMX_HOSP[name] || "";
  const pmxDone = (p) => !!(p && p.data && /^完成/.test(p.data.status || ""));
  const ok = (r) => r && r.data && !r.data.none && !r.data.format && !r.error;
  function pmxRecord(p, d, hosp, rid) {
    d = d || {};
    const rec = { rid, patient: { name: p.name, birth: p.birth || "", sex: p.sex || "", hosp, chart: p.chart },
      visit: { date: ymd(p.visitDate) || "", dept: p.deptName || p.dept || "", doctor: p.doctor || "" }, ap: {}, dx: [], meds: [], labs: [], exams: [] };
    if (ok(d.soap)) {
      const v = d.soap.data.visit || {}, cols = soapColumns(d.soap.data.soap);
      rec.ap = { date: v.date || "", dept: v.dept || "", doctor: v.doctor || "", A: cols.A, P: cols.P };
      rec.dx = (d.soap.data.dx || []).map((t) => ({ text: String(t) }));
    }
    if (d.meds && d.meds.data && Array.isArray(d.meds.data.list)) {
      rec.meds = d.meds.data.list.map((x) => { const s = splitDrug(x.drug); return { name: s.name, usage: s.use, start: x.start, end: x.end, days: x.days, cloud: !!x.cloud, hosp: x.cloud ? x.hosp : "" }; });
    }
    if (ok(d.labs)) {
      const L = d.labs.data;
      if (L.mix) {
        for (const it of L.items || []) for (const [day, v] of Object.entries(it.values || {})) rec.labs.push({ item: it.label || it.name, value: String(v), date: day, kind: it.kind || "" });
      } else {
        for (const x of L.lines || []) rec.labs.push({ item: x.name, value: String(x.value), date: L.date, flag: x.flag || "", kind: (L.kinds || []).join("、").slice(0, 40) });
        for (const x of L.extra || []) rec.labs.push({ item: x.name, value: String(x.value), date: x.date, flag: x.flag || "" });
      }
    }
    if (d.fundus && d.fundus.data && !d.fundus.data.format) {
      const F = d.fundus.data;
      if (F.latest) rec.exams.push({ type: "fundus", date: F.latest.date, conclusion: F.latest.conclusion || "" });
      if (F.thy && F.thy.us) rec.exams.push({ type: "thyroid_us", date: F.thy.us.date, conclusion: F.thy.us.conclusion || "" });
      if (F.thy && F.thy.cyto) rec.exams.push({ type: "cytology", date: F.thy.cyto.date, conclusion: F.thy.cyto.diagnosis || "", category: F.thy.cyto.category || "" });
    }
    return rec;
  }
  const b64 = (u8) => { let s = ""; for (const c of u8) s += String.fromCharCode(c); return btoa(s); };
  const unb64 = (t) => Uint8Array.from(atob(String(t || "").replace(/\s+/g, "")), (c) => c.charCodeAt(0));
  const hex = (u8) => [...u8].map((x) => x.toString(16).padStart(2, "0")).join("");
  // 公鑰：65 bytes 未壓縮 P-256 點的 base64；回傳 {raw, kid} 或 null
  async function pmxKey(pubB64, subtle) {
    let raw;
    try { raw = unb64(pubB64); } catch (e) { return null; }
    if (raw.length !== 65 || raw[0] !== 4) return null;
    try { await subtle.importKey("raw", raw, { name: "ECDH", namedCurve: "P-256" }, false, []); } catch (e) { return null; }
    return { raw, kid: hex(new Uint8Array(await subtle.digest("SHA-256", raw))).slice(0, 16) };
  }
  const pmxFp = (kid) => String(kid || "").replace(/(.{4})(?=.)/g, "$1 ");
  // 加密：回傳檔案內容（JSON 字串）。crypto 由呼叫端傳入（瀏覽器 window.crypto，Node 測試用 webcrypto）
  async function pmxEncrypt(records, pubB64, opt) {
    const cr = opt.crypto, subtle = cr.subtle;
    const key = await pmxKey(pubB64, subtle);
    if (!key) throw new Error("病人管理公鑰格式不對，請到工作台設定重新貼上");
    const recip = await subtle.importKey("raw", key.raw, { name: "ECDH", namedCurve: "P-256" }, false, []);
    const eph = await subtle.generateKey({ name: "ECDH", namedCurve: "P-256" }, false, ["deriveBits"]);
    const epk = new Uint8Array(await subtle.exportKey("raw", eph.publicKey));
    const shared = await subtle.deriveBits({ name: "ECDH", public: recip }, eph.privateKey, 256);
    const salt = cr.getRandomValues(new Uint8Array(16)), iv = cr.getRandomValues(new Uint8Array(12));
    const info = new Uint8Array([...new TextEncoder().encode("pmx-v1"), ...epk, ...key.raw]);
    const hk = await subtle.importKey("raw", shared, "HKDF", false, ["deriveKey"]);
    const aes = await subtle.deriveKey({ name: "HKDF", hash: "SHA-256", salt, info }, hk, { name: "AES-GCM", length: 256 }, false, ["encrypt"]);
    const h = { pmx: 1, kid: key.kid, fid: opt.fid || cr.randomUUID(), created: opt.created, app: opt.app };
    const aad = new TextEncoder().encode(`pmx-v1|${h.kid}|${h.fid}|${h.created}|${h.app}`);
    const pt = new TextEncoder().encode(JSON.stringify({ schema: "pmx-payload-1", records }));
    const ct = new Uint8Array(await subtle.encrypt({ name: "AES-GCM", iv, additionalData: aad }, aes, pt));
    return JSON.stringify(Object.assign(h, { epk: b64(epk), salt: b64(salt), iv: b64(iv), ct: b64(ct) }));
  }
  // 檔名只放日期＋隨機碼（B 審 m11：不放病人資料、不放精確時間）
  const pmxName = (today, rand) => "病人管理_" + today + "_" + rand + ".pmx";
  const isoDay = (d) => { d = d || new Date(); return d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0") + "-" + String(d.getDate()).padStart(2, "0"); };

  return { csvCell, drugTxt, CSV_HEAD, csvRow, toCSV, csvName, chartsInText, HOSPS, hospOf, bareChart, sameChart, patientFromCells, sortPatients, loginUserFrom, mrnUrlFrom, mrnPage, ymd, pickPrevVisit, deptKey, isHomeDept, historyRequest, thyroidWant, thyroidNodule, currentMeds, isThyUS, isThyCyto, latestRow, cytoDiagnosis, cytoCategory, soapColumns, splitDrug, keyName, missingKeys, hasKey, linesFor, ckdEpi, mdrd, sexFromId, ageAt, rocLabel, mixMerge, mixDerive, mixMissing, pairUACR, deriveRenal, isUACRPart: (x) => isUrineAlb(x) || isUrineCr(x), sexOf, ageOf, EGFR_VERSION, olderDraws, otherDraws, examRangeForm,
    parseHistory, NOT_BLOOD, pmxHosp, pmxDone, pmxRecord, pmxKey, pmxFp, pmxEncrypt, pmxName, isoDay, pickLatestDraw, detailRequest, formDates, parseDetail, KEY_ITEMS, keyRank, sortLabs, FUNDUS, pickFundus, conclusion, seasonStart, vaccineSummary, fmtDate, todayKey };
})();
if (typeof module !== "undefined") module.exports = OPDWB;
