// 門診工作台設定頁（v0.5.0）：存到病人管理的開關與公鑰。只存在這台電腦的 chrome.storage.local。
(function () {
  const $ = (id) => document.getElementById(id);
  const C = OPDWB;
  async function check() {
    const v = $("pub").value.trim();
    if (!v) { $("fp").textContent = "—"; $("msg").textContent = ""; return null; }
    const k = await C.pmxKey(v, crypto.subtle);
    $("fp").textContent = k ? C.pmxFp(k.kid) : "—";
    $("msg").textContent = k ? "" : "公鑰格式不對";
    $("msg").className = k ? "" : "err";
    return k;
  }
  chrome.storage.local.get(["pmxOn", "pmxPub"]).then((v) => { $("on").checked = !!v.pmxOn; $("pub").value = v.pmxPub || ""; check(); });
  $("pub").addEventListener("input", () => { $("saved").textContent = ""; check(); });
  $("save").addEventListener("click", async () => {
    const pub = $("pub").value.trim(), k = pub ? await check() : null;
    if ($("on").checked && !k) { $("saved").textContent = ""; $("msg").textContent = "要打開前請先貼上正確的公鑰"; $("msg").className = "err"; return; }
    await chrome.storage.local.set({ pmxOn: $("on").checked && !!k, pmxPub: k ? pub : "" });
    $("saved").textContent = "已儲存";
  });
})();
