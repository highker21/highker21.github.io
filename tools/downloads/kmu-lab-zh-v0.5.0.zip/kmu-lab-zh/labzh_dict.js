// 由 tools/build_dict.py 從 data/lab_zh.json 產生，請改 json 不要改這裡
var LABZH_DICT = [
{
"match": [
"^(?:uacr)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"^acr$",
"^(?:albumin\\s*/\\s*creatinine)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"^(?:alb(umin)?\\s*/\\s*cre)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"^(?:micro\\s*alb(umin)?\\s*/\\s*cr)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$"
],
"zh": "尿液白蛋白／肌酸酐比值",
"en": "Urine albumin/creatinine ratio (UACR)",
"cat": "尿液",
"what": "尿中白蛋白流失量，評估腎臟有無早期受損"
},
{
"match": [
"^(?:albumin.?creatinine ratio)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$"
],
"zh": "尿液白蛋白／肌酸酐比值",
"en": "Urine albumin/creatinine ratio (UACR)",
"cat": "尿液",
"what": "尿中白蛋白流失量，評估腎臟有無早期受損",
"spec": "urine"
},
{
"match": [
"^(?:upcr)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"^(?:protein\\s*/\\s*creatinine)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"^tp\\s*/\\s*cre"
],
"zh": "尿液蛋白／肌酸酐比值",
"en": "Urine protein/creatinine ratio (UPCR)",
"cat": "尿液",
"what": "尿中蛋白質流失量的估算"
},
{
"match": [
"^(?:protein.?creatinine ratio)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$"
],
"zh": "尿液蛋白／肌酸酐比值",
"en": "Urine protein/creatinine ratio (UPCR)",
"cat": "尿液",
"what": "尿中蛋白質流失量的估算",
"spec": "urine"
},
{
"match": [
"^(?:micro\\s*-?alb(umin)?)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"^(?:(u|urine|ur)[\\s\\-_.:]*alb(umin)?\\b)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$"
],
"zh": "尿液微量白蛋白",
"en": "Urine microalbumin",
"cat": "尿液",
"what": "尿中少量白蛋白的濃度"
},
{
"match": [
"^(?:alb(umin)?)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$"
],
"zh": "尿液微量白蛋白",
"en": "Urine microalbumin",
"cat": "尿液",
"what": "尿中少量白蛋白的濃度",
"spec": "urine"
},
{
"match": [
"^(?:creatinine clearance)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"^ccr$"
],
"zh": "肌酸酐清除率",
"en": "Creatinine clearance (CCr)",
"cat": "腎功能",
"what": "用24小時尿液與血液肌酸酐計算腎臟過濾能力",
"note": "需收集24小時尿液"
},
{
"match": [
"^(?:(u|urine|ur)[\\s\\-_.:]*(cr|crea|creatinine)\\b)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"^(?:creatinine.*(urine|ur\\b))(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"^(?:24\\s*h(r|our)?.*creatinine)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$"
],
"zh": "尿液肌酸酐",
"en": "Urine creatinine",
"cat": "尿液",
"what": "尿中肌酸酐濃度，常用來校正其他尿液數值"
},
{
"match": [
"^(?:(cr|crea|cre|creatinine))(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$"
],
"zh": "尿液肌酸酐",
"en": "Urine creatinine",
"cat": "尿液",
"what": "尿中肌酸酐濃度，常用來校正其他尿液數值",
"spec": "urine"
},
{
"match": [
"^(?:(u|urine|ur)[\\s\\-_.:]*(t\\.?p|total protein|protein)\\b.*(24|quant|mg/dl))(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"^(?:24\\s*h(r|our)?.*protein)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"^(?:(u|urine|ur)[\\s\\-_.:]*total protein)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$"
],
"zh": "尿液總蛋白（定量）",
"en": "Urine total protein (quantitative)",
"cat": "尿液",
"what": "尿中蛋白質的實際含量",
"note": "可能需收集24小時尿液"
},
{
"match": [
"^(?:(u|urine|ur)[\\s\\-_.:]*(na|sodium)\\b)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$"
],
"zh": "尿液鈉",
"en": "Urine sodium",
"cat": "尿液",
"what": "尿中排出的鈉量"
},
{
"match": [
"^(?:(u|urine|ur)[\\s\\-_.:]*(k|potassium)\\b)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$"
],
"zh": "尿液鉀",
"en": "Urine potassium",
"cat": "尿液",
"what": "尿中排出的鉀量"
},
{
"match": [
"^(?:(u|urine|ur)[\\s\\-_.:]*(ca|calcium)\\b)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"^(?:24\\s*h(r|our)?.*calcium)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$"
],
"zh": "尿液鈣",
"en": "Urine calcium",
"cat": "尿液",
"what": "尿中排出的鈣量",
"note": "可能需收集24小時尿液"
},
{
"match": [
"^(?:(u|urine|ur)[\\s\\-_.:]*(p|ip|phosph(orus|ate))\\b)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$"
],
"zh": "尿液磷",
"en": "Urine phosphorus",
"cat": "尿液",
"what": "尿中排出的磷量"
},
{
"match": [
"^(?:(u|urine|ur)[\\s\\-_.:]*(ua|uric acid)\\b)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$"
],
"zh": "尿液尿酸",
"en": "Urine uric acid",
"cat": "尿液",
"what": "尿中排出的尿酸量"
},
{
"match": [
"^(?:(u|urine|ur)[\\s\\-_.:]*osm)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"^(?:osmolality.*urine)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$"
],
"zh": "尿液滲透壓",
"en": "Urine osmolality",
"cat": "尿液",
"what": "尿液濃縮或稀釋的程度"
},
{
"match": [
"^(?:urine.*free cortisol)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"^ufc$",
"^(?:(u|urine|ur)[\\s\\-_.:]*cortisol)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"^(?:24\\s*h(r|our)?.*cortisol)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$"
],
"zh": "尿液游離皮質醇",
"en": "Urine free cortisol (UFC)",
"cat": "荷爾蒙",
"what": "24小時內腎上腺分泌皮質醇的總量",
"note": "需收集24小時尿液"
},
{
"match": [
"normetanephrine"
],
"zh": "正腎上腺素代謝物（正變腎上腺素）",
"en": "Normetanephrine",
"cat": "荷爾蒙",
"what": "正腎上腺素的代謝產物"
},
{
"match": [
"metanephrine"
],
"zh": "腎上腺素代謝物（變腎上腺素）",
"en": "Metanephrine",
"cat": "荷爾蒙",
"what": "腎上腺素的代謝產物"
},
{
"match": [
"^(?:catecholamine)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"^(nor)?epinephrine$",
"^(?:dopamine)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$"
],
"zh": "兒茶酚胺",
"en": "Catecholamines",
"cat": "荷爾蒙",
"what": "腎上腺髓質與神經分泌的荷爾蒙"
},
{
"match": [
"^(?:vma)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"^(?:vanillylmandelic)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$"
],
"zh": "香草扁桃酸",
"en": "Vanillylmandelic acid (VMA)",
"cat": "荷爾蒙",
"what": "兒茶酚胺在尿中的代謝產物",
"note": "需收集24小時尿液"
},
{
"match": [
"^(?:specific gravity)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"^sp\\.?\\s*gr"
],
"zh": "尿比重",
"en": "Specific gravity",
"cat": "尿液",
"what": "尿液濃縮的程度"
},
{
"match": [
"^s\\.?g\\.?$"
],
"zh": "尿比重",
"en": "Specific gravity",
"cat": "尿液",
"what": "尿液濃縮的程度",
"spec": "urine"
},
{
"match": [
"^(?:(u|urine|ur)[\\s\\-_.:]*ph\\b)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$"
],
"zh": "酸鹼值",
"en": "pH",
"cat": "尿液",
"what": "尿液的酸鹼程度"
},
{
"match": [
"^ph$"
],
"zh": "酸鹼值",
"en": "pH",
"cat": "尿液",
"what": "尿液的酸鹼程度",
"spec": "urine"
},
{
"match": [
"^(?:(u|urine|ur)[\\s\\-_.:]*colou?r)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$"
],
"zh": "顏色",
"en": "Color",
"cat": "尿液",
"what": "尿液外觀顏色"
},
{
"match": [
"^colou?r$"
],
"zh": "顏色",
"en": "Color",
"cat": "尿液",
"what": "尿液外觀顏色",
"spec": "urine"
},
{
"match": [
"^(?:turbidity)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"^(?:clarity)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$"
],
"zh": "清澈度",
"en": "Turbidity / Clarity",
"cat": "尿液",
"what": "尿液外觀是否混濁"
},
{
"match": [
"^(?:appearance)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$"
],
"zh": "清澈度",
"en": "Turbidity / Clarity",
"cat": "尿液",
"what": "尿液外觀是否混濁",
"spec": "urine"
},
{
"match": [
"^(?:(u|urine|ur)[\\s\\-_.:]*pro(tein)?$)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$"
],
"zh": "尿蛋白（試紙）",
"en": "Urine protein (dipstick)",
"cat": "尿液",
"what": "試紙初步檢測尿中有無蛋白質"
},
{
"match": [
"^(u[\\-\\s.]?)?pro(tein)?$"
],
"zh": "尿蛋白（試紙）",
"en": "Urine protein (dipstick)",
"cat": "尿液",
"what": "試紙初步檢測尿中有無蛋白質",
"spec": "urine"
},
{
"match": [
"^(?:(u|urine|ur)[\\s\\-_.:]*(glu|glucose|sugar))(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"(glucose|sugar).*urine"
],
"zh": "尿糖",
"en": "Urine glucose",
"cat": "尿液",
"what": "尿中有無葡萄糖"
},
{
"match": [
"^(u[\\-\\s.]?)?(glu|glucose|sugar)$"
],
"zh": "尿糖",
"en": "Urine glucose",
"cat": "尿液",
"what": "尿中有無葡萄糖",
"spec": "urine"
},
{
"match": [
"^(?:(u|urine|ur)[\\s\\-_.:]*ket)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$"
],
"zh": "尿酮體",
"en": "Urine ketone",
"cat": "尿液",
"what": "尿中有無脂肪分解產生的酮體"
},
{
"match": [
"^(u[\\-\\s.]?)?ket(one)?s?$"
],
"zh": "尿酮體",
"en": "Urine ketone",
"cat": "尿液",
"what": "尿中有無脂肪分解產生的酮體",
"spec": "urine"
},
{
"match": [
"^(?:urobilinogen)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"^ubg$"
],
"zh": "尿膽素原",
"en": "Urobilinogen",
"cat": "尿液",
"what": "膽紅素在腸道代謝後回到尿中的產物"
},
{
"match": [
"^uro$"
],
"zh": "尿膽素原",
"en": "Urobilinogen",
"cat": "尿液",
"what": "膽紅素在腸道代謝後回到尿中的產物",
"spec": "urine"
},
{
"match": [
"^(?:(u|urine|ur)[\\s\\-_.:]*bil)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$"
],
"zh": "尿膽紅素",
"en": "Urine bilirubin",
"cat": "尿液",
"what": "尿中有無膽紅素"
},
{
"match": [
"^(u[\\-\\s.]?)?bil(irubin)?$"
],
"zh": "尿膽紅素",
"en": "Urine bilirubin",
"cat": "尿液",
"what": "尿中有無膽紅素",
"spec": "urine"
},
{
"match": [
"^(?:nitrite)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$"
],
"zh": "亞硝酸鹽",
"en": "Nitrite",
"cat": "尿液",
"what": "某些細菌分解尿液產生的物質"
},
{
"match": [
"^nit$"
],
"zh": "亞硝酸鹽",
"en": "Nitrite",
"cat": "尿液",
"what": "某些細菌分解尿液產生的物質",
"spec": "urine"
},
{
"match": [
"^(?:leu(kocyte)?\\s*esterase)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$"
],
"zh": "白血球酯酶",
"en": "Leukocyte esterase",
"cat": "尿液",
"what": "試紙檢測尿中白血球的酵素"
},
{
"match": [
"^leu$",
"^le$"
],
"zh": "白血球酯酶",
"en": "Leukocyte esterase",
"cat": "尿液",
"what": "試紙檢測尿中白血球的酵素",
"spec": "urine"
},
{
"match": [
"^(?:(u|urine|ur)[\\s\\-_.:]*(blood|ob)\\b)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$"
],
"zh": "潛血",
"en": "Occult blood",
"cat": "尿液",
"what": "試紙檢測尿中有無血紅素"
},
{
"match": [
"^(?:occult blood)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"^o\\.?b\\.?$",
"^blood$"
],
"zh": "潛血",
"en": "Occult blood",
"cat": "尿液",
"what": "試紙檢測尿中有無血紅素",
"spec": "urine"
},
{
"match": [
"^(?:rbc.*(hpf|sed))(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"^(?:(u|urine|ur)[\\s\\-_.:]*rbc)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$"
],
"zh": "尿沉渣紅血球",
"en": "Urine RBC (sediment)",
"cat": "尿液",
"what": "顯微鏡下每高倍視野的紅血球數"
},
{
"match": [
"^(?:rbc)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$"
],
"zh": "尿沉渣紅血球",
"en": "Urine RBC (sediment)",
"cat": "尿液",
"what": "顯微鏡下每高倍視野的紅血球數",
"spec": "urine"
},
{
"match": [
"^(?:wbc.*(hpf|sed))(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"^(?:(u|urine|ur)[\\s\\-_.:]*wbc)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"^(?:pus cells?)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$"
],
"zh": "尿沉渣白血球",
"en": "Urine WBC (sediment)",
"cat": "尿液",
"what": "顯微鏡下每高倍視野的白血球數"
},
{
"match": [
"^(?:wbc)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$"
],
"zh": "尿沉渣白血球",
"en": "Urine WBC (sediment)",
"cat": "尿液",
"what": "顯微鏡下每高倍視野的白血球數",
"spec": "urine"
},
{
"match": [
"epith"
],
"zh": "上皮細胞",
"en": "Epithelial cells",
"cat": "尿液",
"what": "顯微鏡下看到的泌尿道表皮細胞"
},
{
"match": [
"cast"
],
"zh": "圓柱體",
"en": "Casts",
"cat": "尿液",
"what": "在腎小管內形成的圓柱狀沉積物"
},
{
"match": [
"crystal"
],
"zh": "結晶",
"en": "Crystals",
"cat": "尿液",
"what": "尿中析出的礦物或化學結晶"
},
{
"match": [
"^(?:bacteria)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$"
],
"zh": "細菌",
"en": "Bacteria",
"cat": "尿液",
"what": "顯微鏡下看到的細菌量"
},
{
"match": [
"^(?:yeast)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$"
],
"zh": "酵母菌",
"en": "Yeast",
"cat": "尿液",
"what": "顯微鏡下看到的酵母菌"
},
{
"match": [
"^(?:i?fobt)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"^(?:\\bfit\\b)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"^(?:stool.*occult)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"^(?:occult.*stool)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"^(?:fecal.*occult)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$"
],
"zh": "糞便潛血",
"en": "Fecal occult blood (iFOBT)",
"cat": "其他",
"what": "檢查糞便中肉眼看不到的血"
},
{
"match": [
"^(?:hb\\s*a1c)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"^a1c$",
"^(?:glycated h(a)?emoglobin)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"^(?:glycohemoglobin)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"^(?:glycosylated h(a)?emoglobin)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$"
],
"zh": "糖化血色素",
"en": "HbA1c",
"cat": "血糖",
"what": "反映過去約2到3個月的平均血糖"
},
{
"match": [
"^(?:glycated albumin)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"^ga$",
"^(?:glycoalbumin)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$"
],
"zh": "糖化白蛋白",
"en": "Glycated albumin",
"cat": "血糖",
"what": "反映過去約2到3週的平均血糖"
},
{
"match": [
"^(?:fructosamine)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$"
],
"zh": "果糖胺",
"en": "Fructosamine",
"cat": "血糖",
"what": "反映過去約2到3週的平均血糖"
},
{
"match": [
"^(?:ogtt)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"^(?:oral glucose tolerance)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$"
],
"zh": "口服葡萄糖耐受試驗",
"en": "OGTT",
"cat": "血糖",
"what": "喝75克葡萄糖後分次抽血看血糖變化",
"note": "需空腹"
},
{
"match": [
"^(glucose|glu|bs|sugar|g)[\\s\\-_.]*(\\()?(ac|fasting)",
"^(?:fasting (plasma )?glucose)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"^fpg$",
"^(?:glucose.*fasting)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$"
],
"zh": "空腹血糖",
"en": "Fasting glucose (Glucose AC)",
"cat": "血糖",
"what": "空腹時血液中的葡萄糖濃度",
"note": "需空腹8小時以上"
},
{
"match": [
"^(glucose|glu|bs|sugar)[\\s\\-_.]*(\\()?(pc|2\\s*h)",
"^(?:post.?prandial)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"^(?:glucose.*2\\s*h)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$"
],
"zh": "飯後血糖",
"en": "Postprandial glucose (Glucose PC)",
"cat": "血糖",
"what": "進食後約2小時的血糖濃度",
"note": "依醫囑時間抽血"
},
{
"match": [
"^(glucose|glu|bs|blood sugar)\\b",
"^(?:random glucose)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"^glucose"
],
"zh": "血糖",
"en": "Glucose",
"cat": "血糖",
"what": "抽血當下血液中的葡萄糖濃度",
"spec": "blood"
},
{
"match": [
"^(?:c[\\s\\-]?peptide)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$"
],
"zh": "C 胜肽",
"en": "C-peptide",
"cat": "血糖",
"what": "反映身體自己分泌胰島素的能力"
},
{
"match": [
"^insulin",
"^(?:insulin.*(ac|fasting|level))(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$"
],
"zh": "胰島素",
"en": "Insulin",
"cat": "血糖",
"what": "血液中胰島素濃度"
},
{
"match": [
"^(?:homa(-?ir)?)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$"
],
"zh": "胰島素阻抗指數",
"en": "HOMA-IR",
"cat": "血糖",
"what": "用空腹血糖與胰島素估算胰島素阻抗程度",
"note": "需空腹"
},
{
"match": [
"^(?:(anti[\\s\\-]?)?gad(65)?)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"glutamic acid decarboxylase"
],
"zh": "抗麩胺酸脫羧酶抗體",
"en": "Anti-GAD antibody",
"cat": "血糖",
"what": "與第1型糖尿病相關的自體抗體"
},
{
"match": [
"^(?:ia.?2)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"islet",
"^(?:ica)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$"
],
"zh": "胰島細胞相關抗體",
"en": "IA-2 / Islet cell antibody",
"cat": "血糖",
"what": "攻擊胰島細胞的自體抗體"
},
{
"match": [
"hydroxybutyr",
"^(?:[βb]eta.?hb)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"^b-?ohb$",
"^(?:blood ketone)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"^(?:serum ketone)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$"
],
"zh": "血酮（β-羥丁酸）",
"en": "Beta-hydroxybutyrate",
"cat": "血糖",
"what": "身體分解脂肪產生的酮體濃度",
"spec": "blood"
},
{
"match": [
"^bun$",
"^(?:blood urea nitrogen)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"^(?:urea nitrogen)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"^urea$"
],
"zh": "血中尿素氮",
"en": "Blood urea nitrogen (BUN)",
"cat": "腎功能",
"what": "蛋白質代謝產物，由腎臟排出"
},
{
"match": [
"^(?:egfr)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"^(?:estimated gfr)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"^gfr$",
"^(?:ckd-?epi)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"^(?:mdrd)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$"
],
"zh": "估算腎絲球過濾率",
"en": "eGFR",
"cat": "腎功能",
"what": "由肌酸酐、年齡、性別推算腎臟過濾能力"
},
{
"match": [
"^(s[\\-\\s.]?)?(cr|crea|cre|crtn|creatinine)$",
"^(?:creatinine.*(serum|blood|\\(b\\)))(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"^creatinine"
],
"zh": "肌酸酐",
"en": "Creatinine (serum)",
"cat": "腎功能",
"what": "肌肉代謝產物，用來評估腎臟過濾功能",
"spec": "blood"
},
{
"match": [
"^(?:cystatin\\s*-?\\s*c)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$"
],
"zh": "胱抑素 C",
"en": "Cystatin C",
"cat": "腎功能",
"what": "另一種評估腎臟過濾功能的血液指標"
},
{
"match": [
"^(?:uric acid)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"^ua$",
"^urate$"
],
"zh": "尿酸",
"en": "Uric acid",
"cat": "腎功能",
"what": "體內嘌呤代謝後的產物",
"spec": "blood"
},
{
"match": [
"^na\\+?$",
"^(?:sodium)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$"
],
"zh": "鈉",
"en": "Sodium (Na)",
"cat": "電解質",
"what": "血中鈉離子，與體內水分平衡有關",
"spec": "blood"
},
{
"match": [
"^k\\+?$",
"^(?:potassium)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$"
],
"zh": "鉀",
"en": "Potassium (K)",
"cat": "電解質",
"what": "血中鉀離子，與心臟和肌肉功能有關",
"spec": "blood"
},
{
"match": [
"^cl-?$",
"^(?:chloride)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$"
],
"zh": "氯",
"en": "Chloride (Cl)",
"cat": "電解質",
"what": "血中氯離子，與酸鹼與水分平衡有關",
"spec": "blood"
},
{
"match": [
"^(?:ionized ca)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"^(?:free ca(lcium)?)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"^i-?ca",
"^(?:ca\\s*(\\+\\+|2\\+))(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$"
],
"zh": "游離鈣",
"en": "Ionized calcium",
"cat": "電解質",
"what": "血中未與蛋白結合、具活性的鈣",
"spec": "blood"
},
{
"match": [
"^(?:ca)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"^(?:calcium)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"^(?:total calcium)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$"
],
"zh": "鈣",
"en": "Calcium (total)",
"cat": "電解質",
"what": "血中鈣濃度，與骨骼及副甲狀腺有關",
"spec": "blood"
},
{
"match": [
"^(p|ip|i\\.p\\.)$",
"^(?:phosphorus)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"^(?:inorganic phosph)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"^phosphate$"
],
"zh": "磷",
"en": "Phosphorus",
"cat": "電解質",
"what": "血中磷濃度，與骨骼和腎功能有關",
"spec": "blood"
},
{
"match": [
"^mg$",
"^(?:magnesium)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$"
],
"zh": "鎂",
"en": "Magnesium (Mg)",
"cat": "電解質",
"what": "血中鎂離子，與神經肌肉功能有關",
"spec": "blood"
},
{
"match": [
"^(?:hco3)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"^(?:bicarbonate)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"^(?:total co2)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"^t?co2$"
],
"zh": "碳酸氫根",
"en": "Bicarbonate (HCO3)",
"cat": "電解質",
"what": "血液中的鹼性物質，反映酸鹼平衡",
"spec": "blood"
},
{
"match": [
"^(?:osmolality)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"^osm"
],
"zh": "血清滲透壓",
"en": "Serum osmolality",
"cat": "電解質",
"what": "血液中溶質的濃度",
"spec": "blood"
},
{
"match": [
"^(?:(s\\.?)?got)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"^(?:ast)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"aspartate amino"
],
"zh": "天門冬胺酸轉胺酶（GOT）",
"en": "AST (GOT)",
"cat": "肝功能",
"what": "存在於肝臟、心臟、肌肉細胞內的酵素"
},
{
"match": [
"^(?:(s\\.?)?gpt)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"^(?:alt)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"alanine amino"
],
"zh": "丙胺酸轉胺酶（GPT）",
"en": "ALT (GPT)",
"cat": "肝功能",
"what": "主要存在肝細胞內的酵素"
},
{
"match": [
"^alk",
"alkaline phos",
"^alp$",
"^alk-?p"
],
"zh": "鹼性磷酸酶",
"en": "Alkaline phosphatase (ALP)",
"cat": "肝功能",
"what": "來自肝膽與骨骼的酵素"
},
{
"match": [
"^(?:ggt)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"^(?:[γr]-?gt\\b)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"^(?:gamma.?gt)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"glutamyl"
],
"zh": "丙麩胺酸轉移酶",
"en": "Gamma-GT (GGT)",
"cat": "肝功能",
"what": "肝膽系統的酵素，也會受飲酒影響"
},
{
"match": [
"^d[\\-.\\s]?bil",
"^(?:direct bilirubin)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"^(?:conjugated bilirubin)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"^(?:bilirubin.*direct)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$"
],
"zh": "直接膽紅素",
"en": "Direct bilirubin",
"cat": "肝功能",
"what": "經肝臟處理過的膽紅素",
"spec": "blood"
},
{
"match": [
"^t[\\-.\\s]?bil",
"^(?:total bilirubin)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"^(?:bilirubin.*total)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"^bilirubin$"
],
"zh": "總膽紅素",
"en": "Total bilirubin",
"cat": "肝功能",
"what": "紅血球分解後的產物，由肝臟處理排出",
"spec": "blood"
},
{
"match": [
"^alb(umin)?$",
"^(?:albumin.*(serum|blood))(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"^s[\\-.\\s]?alb"
],
"zh": "白蛋白",
"en": "Albumin (serum)",
"cat": "肝功能",
"what": "肝臟製造的主要血中蛋白，與營養狀態有關",
"spec": "blood"
},
{
"match": [
"^t[\\-.\\s]?p(rotein)?$",
"^total protein"
],
"zh": "總蛋白",
"en": "Total protein",
"cat": "肝功能",
"what": "血中白蛋白與球蛋白的總量",
"spec": "blood"
},
{
"match": [
"^(?:globulin$)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"^glob"
],
"zh": "球蛋白",
"en": "Globulin",
"cat": "肝功能",
"what": "血中除白蛋白以外的蛋白，含抗體",
"spec": "blood"
},
{
"match": [
"^(?:ammonia)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"^nh3$"
],
"zh": "血氨",
"en": "Ammonia",
"cat": "肝功能",
"what": "蛋白質代謝產物，主要由肝臟清除"
},
{
"match": [
"^(?:ldh)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"^ld$",
"^(?:lactate dehydrogenase)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$"
],
"zh": "乳酸脫氫酶",
"en": "LDH",
"cat": "其他",
"what": "存在多種組織細胞內的酵素"
},
{
"match": [
"^ck$",
"^(?:cpk)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"^(?:creatine kinase)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"^ck-?total"
],
"zh": "肌酸激酶",
"en": "Creatine kinase (CK)",
"cat": "其他",
"what": "主要來自肌肉的酵素"
},
{
"match": [
"^(?:amylase)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$"
],
"zh": "澱粉酶",
"en": "Amylase",
"cat": "其他",
"what": "胰臟和唾液腺分泌的消化酵素"
},
{
"match": [
"^(?:lipase)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$"
],
"zh": "脂肪酶",
"en": "Lipase",
"cat": "其他",
"what": "胰臟分泌的消化酵素"
},
{
"match": [
"^(?:anti.?tg)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"^(?:tg\\s*-?ab)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"^atg$",
"^(?:anti.?thyroglobulin)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"^(?:thyroglobulin.*(ab|antibod))(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$"
],
"zh": "抗甲狀腺球蛋白抗體",
"en": "Anti-thyroglobulin antibody (anti-Tg)",
"cat": "甲狀腺",
"what": "甲狀腺自體免疫的抗體，也影響Tg判讀"
},
{
"match": [
"^(?:(anti[\\s\\-]?)?tpo)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"microsom",
"thyroid peroxidase"
],
"zh": "抗甲狀腺過氧化酶抗體",
"en": "Anti-TPO antibody",
"cat": "甲狀腺",
"what": "甲狀腺自體免疫的抗體"
},
{
"match": [
"^(?:tsi)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"thyroid stimulating immunoglobulin"
],
"zh": "甲狀腺刺激免疫球蛋白",
"en": "TSI",
"cat": "甲狀腺",
"what": "會刺激甲狀腺的自體抗體"
},
{
"match": [
"^(?:trab)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"^(?:tsh[\\s\\-]?r(ab)?)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"^(?:tbii)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"^(?:thyrotropin receptor)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"^(?:tsh receptor)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$"
],
"zh": "促甲狀腺素受體抗體",
"en": "TSH receptor antibody (TRAb)",
"cat": "甲狀腺",
"what": "針對甲狀腺刺激素受體的自體抗體"
},
{
"match": [
"^(?:tsh)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"^(?:thyroid stimulating hormone)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"^(?:thyrotropin)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$"
],
"zh": "甲狀腺刺激素",
"en": "TSH",
"cat": "甲狀腺",
"what": "腦下垂體分泌、調控甲狀腺的荷爾蒙"
},
{
"match": [
"^(?:free\\s*t4)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"^f\\.?\\s*-?t4",
"^(?:free thyroxine)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$"
],
"zh": "游離甲狀腺素",
"en": "Free T4",
"cat": "甲狀腺",
"what": "血中具活性的甲狀腺素"
},
{
"match": [
"^(?:free\\s*t3)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"^f\\.?\\s*-?t3",
"^(?:free triiodo)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$"
],
"zh": "游離三碘甲狀腺素",
"en": "Free T3",
"cat": "甲狀腺",
"what": "血中具活性的三碘甲狀腺素"
},
{
"match": [
"^t4$",
"^(?:total t4)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"^thyroxine"
],
"zh": "甲狀腺素（總量）",
"en": "Total T4",
"cat": "甲狀腺",
"what": "血中甲狀腺素的總量"
},
{
"match": [
"^t3$",
"^(?:total t3)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"^triiodothyronine",
"^(?:reverse t3)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$"
],
"zh": "三碘甲狀腺素（總量）",
"en": "Total T3",
"cat": "甲狀腺",
"what": "血中三碘甲狀腺素的總量"
},
{
"match": [
"^(?:thyroglobulin)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"^tg$"
],
"zh": "甲狀腺球蛋白",
"en": "Thyroglobulin (Tg)",
"cat": "甲狀腺",
"what": "甲狀腺細胞製造的蛋白，用於甲狀腺癌術後追蹤",
"units": [
"ng/mL",
"ug/L",
"μg/L"
]
},
{
"match": [
"^(?:(?<!pro)calcitonin)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$"
],
"zh": "抑鈣素",
"en": "Calcitonin",
"cat": "腫瘤標記",
"what": "甲狀腺C細胞分泌的荷爾蒙，用於髓質癌追蹤"
},
{
"match": [
"^(?:non[\\s\\-]?hdl)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$"
],
"zh": "非高密度脂蛋白膽固醇",
"en": "Non-HDL cholesterol",
"cat": "血脂",
"what": "總膽固醇扣掉好膽固醇後的量"
},
{
"match": [
"^(?:hdl)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$"
],
"zh": "高密度脂蛋白膽固醇",
"en": "HDL cholesterol",
"cat": "血脂",
"what": "俗稱好膽固醇，把膽固醇帶回肝臟"
},
{
"match": [
"^(?:(?<!v)ldl)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$"
],
"zh": "低密度脂蛋白膽固醇",
"en": "LDL cholesterol",
"cat": "血脂",
"what": "俗稱壞膽固醇，會堆積在血管壁"
},
{
"match": [
"^(?:vldl)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$"
],
"zh": "極低密度脂蛋白膽固醇",
"en": "VLDL cholesterol",
"cat": "血脂",
"what": "攜帶三酸甘油酯的脂蛋白"
},
{
"match": [
"^(?:triglyceride)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"^trig",
"^tg$"
],
"zh": "三酸甘油酯",
"en": "Triglyceride (TG)",
"cat": "血脂",
"what": "血液中的一種脂肪",
"note": "需空腹",
"units": [
"mg/dL",
"mmol/L"
]
},
{
"match": [
"^t[\\-.\\s]?cho",
"^(?:total cholesterol)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"^chol(esterol)?$"
],
"zh": "總膽固醇",
"en": "Total cholesterol",
"cat": "血脂",
"what": "血液中膽固醇的總量"
},
{
"match": [
"^(?:lp\\s*\\(?a\\)?$)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"^(?:lipoprotein\\s*\\(?a)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$"
],
"zh": "脂蛋白(a)",
"en": "Lipoprotein(a)",
"cat": "血脂",
"what": "與遺傳有關的一種脂蛋白"
},
{
"match": [
"^(?:apo\\s*-?\\s*b)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"^(?:apolipoprotein b)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$"
],
"zh": "載脂蛋白 B",
"en": "Apolipoprotein B",
"cat": "血脂",
"what": "壞膽固醇類粒子的數量指標"
},
{
"match": [
"^(?:apo\\s*-?\\s*a)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"^(?:apolipoprotein a)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$"
],
"zh": "載脂蛋白 A1",
"en": "Apolipoprotein A1",
"cat": "血脂",
"what": "好膽固醇粒子上的主要蛋白"
},
{
"match": [
"^(?:pthrp)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"^(?:pth.?related)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$"
],
"zh": "副甲狀腺素相關胜肽",
"en": "PTHrP",
"cat": "荷爾蒙",
"what": "結構類似副甲狀腺素的胜肽"
},
{
"match": [
"^(?:(intact|i)?[\\s\\-]?pth)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"parathyroid hormone",
"^(?:parathormone)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$"
],
"zh": "副甲狀腺素",
"en": "Parathyroid hormone (PTH)",
"cat": "荷爾蒙",
"what": "調節血鈣與血磷的荷爾蒙"
},
{
"match": [
"1\\s*,\\s*25",
"^(?:calcitriol)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"dihydroxy"
],
"zh": "1,25-二羥基維生素 D",
"en": "1,25-dihydroxyvitamin D",
"cat": "荷爾蒙",
"what": "腎臟活化後的維生素D"
},
{
"match": [
"25.?oh",
"25.?hydroxy",
"^(?:vit(amin)?\\.?\\s*d3?)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$"
],
"zh": "25-羥基維生素 D",
"en": "25-OH vitamin D",
"cat": "荷爾蒙",
"what": "反映體內維生素D的存量"
},
{
"match": [
"^(?:aldosterone\\s*/\\s*renin)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"^arr$",
"^(?:aldosterone.?renin ratio)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$"
],
"zh": "醛固酮／腎素比值",
"en": "Aldosterone/renin ratio (ARR)",
"cat": "荷爾蒙",
"what": "醛固酮與腎素的比例",
"note": "抽血前姿勢、用藥會影響結果"
},
{
"match": [
"^(?:aldosterone)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$"
],
"zh": "醛固酮",
"en": "Aldosterone",
"cat": "荷爾蒙",
"what": "腎上腺分泌、調節鈉鉀與血壓的荷爾蒙"
},
{
"match": [
"^(?:renin)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"^pra$",
"renin activity"
],
"zh": "腎素",
"en": "Renin / Plasma renin activity",
"cat": "荷爾蒙",
"what": "腎臟分泌、調節血壓的酵素"
},
{
"match": [
"^(?:acth)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"^(?:adrenocorticotrop)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$"
],
"zh": "促腎上腺皮質素",
"en": "ACTH",
"cat": "荷爾蒙",
"what": "腦下垂體分泌、刺激腎上腺的荷爾蒙"
},
{
"match": [
"cortisol"
],
"zh": "皮質醇",
"en": "Cortisol",
"cat": "荷爾蒙",
"what": "腎上腺分泌的荷爾蒙，與壓力、代謝有關",
"note": "抽血時間會影響數值，通常早上抽"
},
{
"match": [
"^(?:dhea(-?s|-?so4)?)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$"
],
"zh": "脫氫表雄固酮硫酸鹽",
"en": "DHEA-S",
"cat": "荷爾蒙",
"what": "腎上腺分泌的雄性素前驅物"
},
{
"match": [
"^(?:17.?oh.?p)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"^(?:17.?hydroxy.?progesterone)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$"
],
"zh": "17-羥基黃體素",
"en": "17-OH progesterone",
"cat": "荷爾蒙",
"what": "腎上腺製造皮質醇過程中的中間產物"
},
{
"match": [
"^(?:prolactin)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"^prl$"
],
"zh": "泌乳激素",
"en": "Prolactin",
"cat": "荷爾蒙",
"what": "腦下垂體分泌、與泌乳有關的荷爾蒙"
},
{
"match": [
"^(?:igf.?(1|i)\\b)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"^(?:somatomedin)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$"
],
"zh": "類胰島素生長因子-1",
"en": "IGF-1",
"cat": "荷爾蒙",
"what": "反映生長激素長期分泌量的指標"
},
{
"match": [
"^h?gh$",
"^(?:growth hormone)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$"
],
"zh": "生長激素",
"en": "Growth hormone (GH)",
"cat": "荷爾蒙",
"what": "腦下垂體分泌、促進生長代謝的荷爾蒙"
},
{
"match": [
"^(?:lh)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"luteinizing"
],
"zh": "黃體生成素",
"en": "LH",
"cat": "荷爾蒙",
"what": "腦下垂體分泌、調控性腺的荷爾蒙"
},
{
"match": [
"^(?:fsh)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"follicle stimulating"
],
"zh": "濾泡刺激素",
"en": "FSH",
"cat": "荷爾蒙",
"what": "腦下垂體分泌、調控性腺的荷爾蒙"
},
{
"match": [
"^e2$",
"^(?:estradiol)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$"
],
"zh": "雌二醇",
"en": "Estradiol (E2)",
"cat": "荷爾蒙",
"what": "主要的女性荷爾蒙"
},
{
"match": [
"progesterone"
],
"zh": "黃體素",
"en": "Progesterone",
"cat": "荷爾蒙",
"what": "卵巢與胎盤分泌的荷爾蒙"
},
{
"match": [
"^(?:free testosterone)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$"
],
"zh": "游離睪固酮",
"en": "Free testosterone",
"cat": "荷爾蒙",
"what": "血中未與蛋白結合、具活性的睪固酮"
},
{
"match": [
"testosterone"
],
"zh": "睪固酮",
"en": "Testosterone",
"cat": "荷爾蒙",
"what": "主要的男性荷爾蒙，女性也有少量",
"note": "通常早上抽血"
},
{
"match": [
"^(?:shbg)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"sex hormone binding"
],
"zh": "性荷爾蒙結合球蛋白",
"en": "SHBG",
"cat": "荷爾蒙",
"what": "血中攜帶性荷爾蒙的蛋白"
},
{
"match": [
"^(?:(beta[\\s\\-]?|b-?|β-?)?hcg)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"chorionic"
],
"zh": "人類絨毛膜促性腺激素",
"en": "hCG",
"cat": "荷爾蒙",
"what": "懷孕時胎盤分泌的荷爾蒙"
},
{
"match": [
"^(?:amh)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"m[uü]llerian"
],
"zh": "抗穆勒氏管荷爾蒙",
"en": "AMH",
"cat": "荷爾蒙",
"what": "反映卵巢內濾泡的庫存量"
},
{
"match": [
"^(?:wbc)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"^(?:white blood cell)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"^(?:leukocytes?$)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"^(?:leukocyte count)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$"
],
"zh": "白血球",
"en": "WBC",
"cat": "血球",
"what": "血液中白血球的總數，與免疫有關",
"spec": "blood"
},
{
"match": [
"^rbc",
"^(?:red blood cell)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"^(?:erythrocytes?$)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"^(?:erythrocyte count)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$"
],
"zh": "紅血球",
"en": "RBC",
"cat": "血球",
"what": "血液中紅血球的數量，負責運送氧氣",
"spec": "blood"
},
{
"match": [
"^hb$",
"^hgb",
"^h(a)?emoglobin"
],
"zh": "血紅素",
"en": "Hemoglobin (Hb)",
"cat": "血球",
"what": "紅血球內負責攜帶氧氣的蛋白"
},
{
"match": [
"^(?:hct)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"^(?:h(a)?ematocrit)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$"
],
"zh": "血球容積比",
"en": "Hematocrit (Hct)",
"cat": "血球",
"what": "紅血球占全部血液體積的比例"
},
{
"match": [
"^(?:mchc)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$"
],
"zh": "平均紅血球血紅素濃度",
"en": "MCHC",
"cat": "血球",
"what": "紅血球內血紅素的平均濃度"
},
{
"match": [
"^mch$"
],
"zh": "平均紅血球血紅素量",
"en": "MCH",
"cat": "血球",
"what": "每個紅血球平均含有的血紅素量"
},
{
"match": [
"^mcv$"
],
"zh": "平均紅血球體積",
"en": "MCV",
"cat": "血球",
"what": "紅血球的平均大小"
},
{
"match": [
"^(?:rdw)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$"
],
"zh": "紅血球分布寬度",
"en": "RDW",
"cat": "血球",
"what": "紅血球大小的差異程度"
},
{
"match": [
"^(?:retic(ulocytes?)?)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$"
],
"zh": "網狀紅血球",
"en": "Reticulocyte",
"cat": "血球",
"what": "剛從骨髓釋出的年輕紅血球"
},
{
"match": [
"^mpv$"
],
"zh": "平均血小板體積",
"en": "MPV",
"cat": "血球",
"what": "血小板的平均大小"
},
{
"match": [
"^(?:plt)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"^(?:platelet)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$"
],
"zh": "血小板",
"en": "Platelet (PLT)",
"cat": "血球",
"what": "血液中負責止血的細胞碎片"
},
{
"match": [
"^(?:bands?)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$"
],
"zh": "帶狀嗜中性球",
"en": "Band neutrophil",
"cat": "血球",
"what": "較年輕、尚未分節的嗜中性球"
},
{
"match": [
"^(?:neut(rophils?)?)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"^(?:seg(ment)?s?)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"^(?:anc)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$"
],
"zh": "嗜中性球",
"en": "Neutrophil",
"cat": "血球",
"what": "白血球的一種，主要對抗細菌"
},
{
"match": [
"^(?:lymph(ocytes?)?)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"^(?:lym)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$"
],
"zh": "淋巴球",
"en": "Lymphocyte",
"cat": "血球",
"what": "白血球的一種，負責免疫記憶與抗體"
},
{
"match": [
"^(?:mono(cytes?)?)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$"
],
"zh": "單核球",
"en": "Monocyte",
"cat": "血球",
"what": "白血球的一種，負責吞噬與清除"
},
{
"match": [
"^(?:eos(inophils?)?)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$"
],
"zh": "嗜酸性球",
"en": "Eosinophil",
"cat": "血球",
"what": "白血球的一種，與過敏及寄生蟲有關"
},
{
"match": [
"^(?:baso(phils?)?)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$"
],
"zh": "嗜鹼性球",
"en": "Basophil",
"cat": "血球",
"what": "白血球的一種，參與過敏反應"
},
{
"match": [
"^(?:esr)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"^(?:sed(imentation)?\\s*rate)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$"
],
"zh": "紅血球沉降速率",
"en": "ESR",
"cat": "發炎",
"what": "紅血球在試管中沉降的速度"
},
{
"match": [
"^(?:(pt[\\s\\-]?)?inr)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$"
],
"zh": "國際標準化比值",
"en": "INR",
"cat": "凝血",
"what": "把凝血酶原時間標準化，常用於抗凝血劑監測"
},
{
"match": [
"^pt$",
"^(?:prothrombin time)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"^pt\\s*\\(sec"
],
"zh": "凝血酶原時間",
"en": "Prothrombin time (PT)",
"cat": "凝血",
"what": "血液凝固所需的時間（外在途徑）"
},
{
"match": [
"^(?:a?ptt)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$"
],
"zh": "活化部分凝血活酶時間",
"en": "aPTT",
"cat": "凝血",
"what": "血液凝固所需的時間（內在途徑）"
},
{
"match": [
"^(?:fibrinogen)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$"
],
"zh": "纖維蛋白原",
"en": "Fibrinogen",
"cat": "凝血",
"what": "肝臟製造、形成血塊的凝血蛋白"
},
{
"match": [
"^(?:d.?dimer)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$"
],
"zh": "D-雙合體",
"en": "D-dimer",
"cat": "凝血",
"what": "血塊被分解後產生的片段"
},
{
"match": [
"^(?:hs.?crp)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"^(?:high.?sensitiv.*c.?reactive)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$"
],
"zh": "高敏感度 C 反應蛋白",
"en": "hs-CRP",
"cat": "發炎",
"what": "測量低濃度C反應蛋白的方法"
},
{
"match": [
"^(?:crp)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"^(?:c.?reactive)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$"
],
"zh": "C 反應蛋白",
"en": "CRP",
"cat": "發炎",
"what": "身體發炎時肝臟製造的蛋白"
},
{
"match": [
"^(?:procalcitonin)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"^pct$"
],
"zh": "前降鈣素原",
"en": "Procalcitonin",
"cat": "發炎",
"what": "常用來協助判斷是否為細菌感染的蛋白"
},
{
"match": [
"^(?:ferritin)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$"
],
"zh": "鐵蛋白",
"en": "Ferritin",
"cat": "其他",
"what": "反映體內鐵的儲存量"
},
{
"match": [
"^(?:tibc)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"total iron binding"
],
"zh": "總鐵結合能力",
"en": "TIBC",
"cat": "其他",
"what": "血中可攜帶鐵的能力"
},
{
"match": [
"^(?:tsat)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"transferrin sat",
"iron sat"
],
"zh": "運鐵蛋白飽和度",
"en": "Transferrin saturation",
"cat": "其他",
"what": "運鐵蛋白被鐵占用的比例"
},
{
"match": [
"^(?:transferrin)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$"
],
"zh": "運鐵蛋白",
"en": "Transferrin",
"cat": "其他",
"what": "血中負責運送鐵的蛋白"
},
{
"match": [
"^fe$",
"^iron$",
"^(?:serum iron)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$"
],
"zh": "血清鐵",
"en": "Serum iron",
"cat": "其他",
"what": "血液中的鐵濃度"
},
{
"match": [
"^(?:(vit(amin)?\\.?\\s*)?b\\s*-?12)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"cobalamin"
],
"zh": "維生素 B12",
"en": "Vitamin B12",
"cat": "其他",
"what": "造血與神經需要的維生素"
},
{
"match": [
"^(?:folate)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"^(?:folic acid)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$"
],
"zh": "葉酸",
"en": "Folate",
"cat": "其他",
"what": "造血需要的維生素"
},
{
"match": [
"homocyst"
],
"zh": "同半胱胺酸",
"en": "Homocysteine",
"cat": "其他",
"what": "蛋白質代謝的中間產物"
},
{
"match": [
"^(?:cea)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$"
],
"zh": "癌胚抗原",
"en": "CEA",
"cat": "腫瘤標記",
"what": "多種癌症追蹤時使用的蛋白"
},
{
"match": [
"^(?:afp)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"^(?:alpha.?feto)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$"
],
"zh": "甲型胎兒蛋白",
"en": "AFP",
"cat": "腫瘤標記",
"what": "肝臟相關的腫瘤標記"
},
{
"match": [
"^(?:ca\\s*-?\\s*19\\s*-?\\s*9)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$"
],
"zh": "醣類抗原 19-9",
"en": "CA 19-9",
"cat": "腫瘤標記",
"what": "胰臟膽道相關的腫瘤標記"
},
{
"match": [
"^(?:ca\\s*-?\\s*125)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$"
],
"zh": "醣類抗原 125",
"en": "CA 125",
"cat": "腫瘤標記",
"what": "卵巢相關的腫瘤標記"
},
{
"match": [
"^(?:ca\\s*-?\\s*15\\s*-?\\s*3)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$"
],
"zh": "醣類抗原 15-3",
"en": "CA 15-3",
"cat": "腫瘤標記",
"what": "乳癌相關的腫瘤標記"
},
{
"match": [
"^(?:free\\s*psa)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"^(?:f-?psa)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"^(?:%\\s*free psa)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$"
],
"zh": "游離攝護腺特異抗原",
"en": "Free PSA",
"cat": "腫瘤標記",
"what": "未與蛋白結合的PSA"
},
{
"match": [
"^(?:psa)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$"
],
"zh": "攝護腺特異抗原",
"en": "PSA",
"cat": "腫瘤標記",
"what": "攝護腺細胞製造的蛋白"
},
{
"match": [
"chromogranin"
],
"zh": "嗜鉻粒蛋白 A",
"en": "Chromogranin A",
"cat": "腫瘤標記",
"what": "神經內分泌細胞分泌的蛋白"
},
{
"match": [
"^(?:hbsag)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"^(?:hepatitis b surface antigen)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$"
],
"zh": "B 型肝炎表面抗原",
"en": "HBsAg",
"cat": "其他",
"what": "檢查有無B型肝炎病毒"
},
{
"match": [
"^(?:anti.?hbs)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"^(?:hbsab)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"^(?:hbs\\s*ab)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$"
],
"zh": "B 型肝炎表面抗體",
"en": "Anti-HBs",
"cat": "其他",
"what": "檢查有無B型肝炎保護抗體"
},
{
"match": [
"^(?:anti.?hbc)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"^(?:hbc\\s*ab)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$"
],
"zh": "B 型肝炎核心抗體",
"en": "Anti-HBc",
"cat": "其他",
"what": "檢查是否曾感染B型肝炎"
},
{
"match": [
"^(?:anti.?hcv)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$",
"^(?:hcv\\s*ab)(?:[\\s\\-_.]*(?:c|chol|cholesterol|level|total|serum|plasma|blood|quant|quantitative|conc|count|ratio|ab|antibody|antibodies|#|%|abs|absolute))?(?:\\s*[\\(\\[][^)\\]]*[\\)\\]])*\\s*$"
],
"zh": "C 型肝炎抗體",
"en": "Anti-HCV",
"cat": "其他",
"what": "檢查是否曾感染C型肝炎"
}
];
