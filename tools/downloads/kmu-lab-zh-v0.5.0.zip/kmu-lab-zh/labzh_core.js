// 中文檢驗報告：純函式（對照表比對、高低標示、組報告、輸出列印頁 HTML）。不碰網頁、不連網，Node 也能測。
// 院內明細欄位依體系病歷「檢驗」頁 renderRptDetailTable／門診工作台 parseDetail：項目、檢體、結果值、標準值、單位、ABNORMAL_FLAG、危急值通報、採檢日、報告日、DETAIL_CODE。
var LABZH = (function () {
  "use strict";
  const VERSION_DATE = "2026-11-24";   // v0.5.0
  const FOOTER = "非官方中文報告，翻譯僅供參考";   // 老闆 msg808 指定
  const CAT_ORDER = ["血糖", "腎功能", "肝功能", "血脂", "甲狀腺", "荷爾蒙", "電解質", "血球", "凝血", "發炎", "腫瘤標記", "尿液", "其他"];
  const UNKNOWN_CAT = "其他（無中文對照）";

  const esc = (s) => String(s == null ? "" : s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const str = (v) => String(v == null ? "" : v).trim();

  // ---------- 對照表 ----------
  function compileDict(entries) {
    const out = [];
    for (const e of Array.isArray(entries) ? entries : []) {
      if (!e || !e.zh) continue;
      const res = [];
      for (const m of [].concat(e.match || [])) { try { res.push(new RegExp(m, "i")); } catch (err) { /* 壞的規則跳過，build_dict 會先擋 */ } }
      out.push({ res, codes: [].concat(e.code || []).map((c) => str(c).toUpperCase()).filter(Boolean), zh: str(e.zh), en: str(e.en),
        cat: CAT_ORDER.includes(e.cat) ? e.cat : "其他", what: str(e.what), note: str(e.note), spec: e.spec === "urine" || e.spec === "blood" ? e.spec : "",
        units: [].concat(e.units || []).map((u) => str(u).toLowerCase().replace(/\s+/g, "")).filter(Boolean) });
    }
    return out;
  }
  const AMBIG_NO_UNIT = /^\s*tg\s*$/i;
  const CRIT_YES = /^(Y|YES|是|有|1|TRUE|V)$/i;   // 危急值通報：只認明確的「是」（B 審 m2）
  const isUrine = (x) => /尿|urine/i.test(str(x.spec) + " " + str(x.kind));
  function lookup(dict, x) {
    const urine = isUrine(x), code = str(x.code).toUpperCase(), name = str(x.name);
    // 有 units 的規則：報告有單位就要對得上。裸寫 TG（三酸甘油酯 mg/dL 或甲狀腺球蛋白 ng/mL）沒有單位時不猜，保留英文
    const unit = str(x.unit).toLowerCase().replace(/\s+/g, "");
    const ok = (e) => (!e.spec || (e.spec === "urine") === urine) && (!e.units.length || !unit || e.units.includes(unit));
    if (code) for (const e of dict) if (ok(e) && e.codes.includes(code)) return e;
    if (!unit && AMBIG_NO_UNIT.test(name)) return null;
    if (name) for (const e of dict) if (ok(e) && e.res.some((r) => r.test(name))) return e;
    return null;
  }

  // ---------- 結果、標示 ----------
  // 定性結果翻成中文，原文放括號；數字不動
  const VALUE_ZH = [
    [/^neg(ative)?$|^\(-\)$/i, "陰性"], [/^pos(itive)?$|^\(\+\)$/i, "陽性"], [/^trace$|^\(±\)$|^±$/i, "微量"],
    [/^non[- ]?reactive$/i, "無反應"], [/^reactive$/i, "有反應"], [/^not detected$|^undetected$/i, "未檢出"], [/^detected$/i, "檢出"],
    [/^normal$/i, "正常"], [/^abnormal$/i, "異常"], [/^none$|^nil$/i, "無"], [/^few$/i, "少量"], [/^many$/i, "多量"],
    [/^clear$/i, "清澈"], [/^turbid$/i, "混濁"], [/^sl(ightly)?\.? ?turbid$/i, "微混濁"], [/^cloudy$/i, "混濁"],
    [/^yellow$/i, "黃色"], [/^pale yellow$|^light yellow$/i, "淡黃色"], [/^straw$/i, "淡黃色"], [/^amber$/i, "琥珀色"], [/^dark yellow$/i, "深黃色"],
  ];
  function valueText(v) {
    const s = str(v);
    for (const [re, zh] of VALUE_ZH) if (re.test(s)) return { text: zh, orig: s };
    return { text: s, orig: "" };
  }
  // 高低以院內 ABNORMAL_FLAG 為準，不自己拿參考值重算
  function flagInfo(flag) {
    const f = str(flag).toUpperCase();
    if (f === "HH") return { cls: "hi", text: "↑↑偏高" };
    if (f === "H") return { cls: "hi", text: "↑偏高" };
    if (f === "LL") return { cls: "lo", text: "↓↓偏低" };
    if (f === "L") return { cls: "lo", text: "↓偏低" };
    if (f === "A" || f === "Y" || f === "*") return { cls: "ab", text: "＊異常" };
    return null;
  }
  const refText = (s) => str(s).replace(/\bMale\b|\bM\s*[:：]/g, "男：").replace(/\bFemale\b|\bF\s*[:：]/g, "女：");

  // 院內明細 → 一列
  function parseDetail(result, kind) {
    return ((result && result.detailReport) || []).map((r) => ({
      name: str(r["項目"]), spec: str(r["檢體"]), value: str(r["結果值"]), ref: str(r["標準值"]), unit: str(r["單位"]),
      flag: str(r.ABNORMAL_FLAG), critical: CRIT_YES.test(str(r["危急值通報"])),
      sampled: str(r["採檢日"]), reported: str(r["報告日"]), code: str(r.DETAIL_CODE), kind: str(kind),
    })).filter((x) => x.name && !/^收到檢體$/.test(x.name));   // 「收到檢體」是採檢時間列
  }

  // ---------- 組報告 ----------
  // reports：[{kind, hosp, rows:[parseDetail 結果]}]；patient：{name, chart}
  function buildReport(o) {
    const dict = o.dict || [], sections = new Map();
    const sampled = new Set(), reported = new Set(), hosps = new Set(), kinds = [];
    let unknown = 0, abnormal = 0, critical = 0;
    for (const rep of o.reports || []) {
      if (rep.hosp) hosps.add(str(rep.hosp));
      if (rep.kind && !kinds.includes(rep.kind)) kinds.push(rep.kind);
      for (const x of rep.rows || []) {
        const e = lookup(dict, x), cat = e ? e.cat : UNKNOWN_CAT;
        if (!e) unknown++;
        const fl = flagInfo(x.flag);
        if (fl) abnormal++;
        if (x.critical) critical++;
        if (x.sampled) sampled.add(x.sampled.split(/\s+/)[0]);
        if (x.reported) reported.add(x.reported.split(/\s+/)[0]);
        if (!sections.has(cat)) sections.set(cat, []);
        sections.get(cat).push({ hosp: str(rep.hosp), zh: e ? e.zh : "", name: x.name, value: valueText(x.value), unit: x.unit, ref: refText(x.ref), flag: fl, critical: !!x.critical,
          what: e ? e.what : "", note: e ? e.note : "", urine: isUrine(x) && !(e && e.cat === "尿液") });
      }
    }
    // eGFR、UACR 院方沒報就自己算（o.renal＝{birth, sex}；沒給就不算）
    if (o.renal) {
      const rows = [];
      for (const rep of o.reports || []) for (const x of rep.rows || []) rows.push(Object.assign({}, x, { hosp: str(rep.hosp) }));
      const calc = renalCalc({ dict, rows, birth: o.renal.birth, sex: o.renal.sex });
      const mt = metabCalc({ dict, rows, birth: o.renal.birth });
      for (const [cat, list] of [["腎功能", calc], ["肝功能", mt.liver], ["血糖", mt.glu]]) if (list.length) { if (!sections.has(cat)) sections.set(cat, []); sections.get(cat).push(...list); }
    }
    const order = [...CAT_ORDER, UNKNOWN_CAT];
    return {
      patient: { name: str(o.patient && o.patient.name), chart: str(o.patient && o.patient.chart) },
      hosp: [...hosps].join("、") || str(o.hospName), multi: hosps.size > 1, kinds, sampled: [...sampled].sort(), reported: [...reported].sort(),
      sections: order.filter((c) => sections.has(c)).map((c) => ({ cat: c, items: sections.get(c) })),
      count: [...sections.values()].reduce((a, b) => a + b.length, 0), unknown, abnormal, critical, printed: str(o.now), notes: (o.notes || []).map(str).filter(Boolean),
    };
  }

  // ---------- 列印頁 ----------
  const CSS = `@page{size:A4;margin:14mm 12mm 16mm}
*{box-sizing:border-box}body{margin:0;color:#000;background:#fff;font:15px/1.5 "Microsoft JhengHei","PingFang TC","Noto Sans TC",sans-serif}
h1{font-size:22px;margin:0 0 4px}.sub{font-size:13px;color:#333;margin-bottom:8px}
.pt{display:flex;flex-wrap:wrap;gap:4px 22px;border:1.5px solid #000;padding:6px 10px;margin:6px 0 8px;font-size:16px}.pt b{font-weight:700}
.tip{font-size:13.5px;margin:0 0 8px}
h2{font-size:17px;margin:12px 0 4px;padding:2px 8px;border-left:5px solid #000;background:#eee;-webkit-print-color-adjust:exact;print-color-adjust:exact}
table{width:100%;border-collapse:collapse;page-break-inside:auto}tr{page-break-inside:avoid}
th,td{border:1px solid #888;padding:4px 6px;vertical-align:top;text-align:left}th{background:#f3f3f3;font-size:13.5px;-webkit-print-color-adjust:exact;print-color-adjust:exact}
td.n{width:27%}td.n .en{display:block;font-size:12px;color:#444}td.v{width:17%;white-space:nowrap}td.u{width:10%;font-size:13px}td.r{width:16%;font-size:13px}td.w{font-size:13.5px}
.orig{font-size:12px;color:#444}.fl{font-weight:700;display:block}tr.hi td.v,tr.lo td.v,tr.ab td.v{font-weight:700}
tr.hi td.v,tr.lo td.v,tr.ab td.v{background:#f2f2f2;-webkit-print-color-adjust:exact;print-color-adjust:exact}
.hs{display:inline-block;border:1px solid #555;border-radius:3px;padding:0 4px;font-size:11.5px;margin-top:2px}
.crit{display:inline-block;border:1.5px solid #000;padding:0 3px;font-weight:700;font-size:12px;margin-top:2px}
.foot{margin-top:14px;border-top:1.5px solid #000;padding-top:6px;font-size:14px;font-weight:700}.ver{font-size:11.5px;color:#555;font-weight:400;margin-top:2px}
@media screen{body{padding:18px 22px;max-width:900px;margin:0 auto}}`;
  const TREND_CSS = `.it{page-break-inside:avoid;margin-bottom:10px}.it h2 .en{font-size:12.5px;font-weight:400;color:#444}.what,.meta{margin:2px 0;font-size:13.5px}
.tw{display:flex;gap:12px;align-items:flex-start}.tw svg{flex:1 1 auto}.tt{width:auto;min-width:190px}.tt th{white-space:nowrap}.tt td.v{font-weight:700}`;
  function renderHTML(m) {
    const row = (it) => {
      const cls = it.flag ? it.flag.cls : "";
      const hs = m.multi && it.hosp ? `<span class="hs">${esc(it.hosp)}</span>` : "";   // 多院區一起印時，每項標院區（老闆 msg823）
      const name = (it.zh ? `${esc(it.zh)}${it.urine ? "（尿）" : ""}<span class="en">${esc(it.name)}</span>` : `${esc(it.name)}<span class="en">（無中文對照）</span>`) + hs;
      const val = esc(it.value.text) + (it.value.orig ? ` <span class="orig">(${esc(it.value.orig)})</span>` : "") +
        (it.flag ? `<span class="fl">${esc(it.flag.text)}</span>` : "") + (it.critical ? `<span class="crit">危急值</span>` : "");
      const what = esc(it.what) + (it.note ? `<br><span class="orig">${esc(it.note)}</span>` : "");
      return `<tr${cls ? ` class="${cls}"` : ""}><td class="n">${name}</td><td class="v">${val}</td><td class="u">${esc(it.unit)}</td><td class="r">${esc(it.ref)}</td><td class="w">${what}</td></tr>`;
    };
    const sec = (s) => `<h2>${esc(s.cat)}</h2><table><thead><tr><th>項目</th><th>結果</th><th>單位</th><th>參考範圍</th><th>這項在看什麼</th></tr></thead><tbody>${s.items.map(row).join("")}</tbody></table>`;
    const pt = [["姓名", m.patient.name], ["病歷號", m.patient.chart], ["院區", m.hosp], ["採檢日", m.sampled.join("、")], ["報告日", m.reported.join("、")]]
      .filter((p) => p[1]).map((p) => `<span>${esc(p[0])}：<b>${esc(p[1])}</b></span>`).join("");
    return `<!doctype html><html lang="zh-Hant"><head><meta charset="utf-8"><title>檢驗報告（中文說明版）</title><style>${CSS}</style></head><body>
<h1>檢驗報告（中文說明版）</h1><div class="sub">${esc(m.kinds.join("、"))}</div>
<div class="pt">${pt}</div>
<p class="tip">結果旁標「↑偏高」「↓偏低」「＊異常」的項目，請和醫師討論。${m.multi ? "各院區的參考範圍可能不同，請對照同一列。" : ""}</p>
${(m.notes || []).map((n) => `<p class="tip">※ ${esc(n)}</p>`).join("")}
${m.sections.map(sec).join("\n")}
${m.trend ? `<style>${TREND_CSS}</style><h2>一年內變化</h2><p class="tip">期間 ${esc(fmtDay(m.trend.from))}～${esc(fmtDay(m.trend.to))}；少於 2 次的項目不畫圖。</p>${m.trend.short ? `<p class="tip">※ 院內查詢區間不到一年，只畫查得到的這段。</p>` : ""}${trendSections(m.trend)}` : ""}
<div class="foot">${esc(FOOTER)}<div class="ver">列印時間：${esc(m.printed)}　工具版本：${VERSION_DATE}</div></div>
</body></html>`;
  }

  // ---------- 單項一年變化（老闆 msg811；院內「整合」Mix 模式，格式同門診工作台 mixMerge）----------
  // 不做趨勢的報告類別（培養、鏡檢、糞便、新冠、結核基因、血庫）
  const NO_TREND = /培養|鏡檢|糞便|COVID|GeneXpert|抗酸菌|革蘭|血庫/i;
  const fmtDay = (k) => (/^\d{8}$/.test(k) ? k.slice(0, 4) + "/" + k.slice(4, 6) + "/" + k.slice(6, 8) : str(k));
  const dayKey = (s) => { const d = str(s).replace(/\D/g, ""); return d.length >= 8 ? d.slice(0, 8) : ""; };
  // v0.3.2（老闆 msg973／976「沒有自動畫圖」）：院內 Mix 的 CHART_VALUE 異常值會帶「 flag=H」（例「8.1 flag=H」，院內畫面 mixDetailDataFormatter 也是這樣拆）；
  // 舊版把整串當數值 → 數字解析失敗 → 異常的點全被丟掉，異常值多的項目少於 2 點就整張圖不畫。這裡拆成數值＋旗標
  // v0.3.3（老闆 msg981「數值會顯示 Flag=h」、B 審）：「flag=」大小寫都認、整個 token 才算，旗標轉大寫
  function splitFlag(raw) {
    const toks = str(raw).split(/\s+/).filter(Boolean), re = /^flag=(\S*)$/i;
    const f = toks.find((t) => re.test(t));
    return { v: toks.filter((t) => !re.test(t)).join(" "), flag: f ? f.replace(re, "$1").toUpperCase() : "" };
  }
  // results：[{kind, hosp, res}]，res = {columnsDateTime, rowItems:["項目@檢體"], mixTableData:[{COLLECT_DATE_N, 項目, CHART_VALUE}]}；每個院區各自一組
  function mixMerge(results) {
    const items = new Map();
    for (const { kind, hosp: h, res } of results || []) {
      const hosp = str(h);
      const keyOf = (raw, kind) => { const [n, sp] = str(raw).split("@"); const urine = /urine|尿/i.test(sp || ""); return { name: str(n), spec: str(sp), urine, k: hosp + "|" + str(n) + "@" + str(sp) + "@" + (urine ? "U" : kind) }; };
      if (!res || !Array.isArray(res.mixTableData)) continue;
      for (const raw of Array.isArray(res.rowItems) ? res.rowItems : []) {
        const o = keyOf(raw, kind);
        if (!o.name || /^收到檢體$/.test(o.name) || items.has(o.k)) continue;
        items.set(o.k, { id: "i" + items.size, hosp, name: o.name, spec: o.spec, kind: o.urine ? "尿液檢驗" : kind, values: {}, flags: {} });
      }
      for (const d of res.mixTableData) {
        const day = dayKey(d.COLLECT_DATE_N), { v, flag } = splitFlag(d.CHART_VALUE), o = keyOf(d["項目"], kind), it = items.get(o.k);
        if (!/^\d{8}$/.test(day) || !v || !it) continue;
        if (!(day in it.values)) { it.values[day] = v; if (flag) it.flags[day] = flag; }   // 同一天多次採檢取第一個
      }
    }
    return [...items.values()].filter((x) => Object.keys(x.values).length);
  }
  // 各院區同一項目合成一條線（同名、同尿／血、同單位）；單位不同就分開，不硬合（老闆 msg823）。每一點都記院區，同一天兩院都有就兩點都留
  function combineHosp(items) {
    const out = new Map();
    for (const x of items || []) {
      const k = str(x.name).toLowerCase() + "@" + (isUrine(x) ? "U" : "B") + "@" + str(x.unit).toLowerCase().replace(/\s+/g, "");
      if (!out.has(k)) out.set(k, { id: "c" + out.size, name: x.name, spec: x.spec, kind: x.kind, code: x.code || "", unit: str(x.unit), refs: [], hosps: [], points: [] });
      const o = out.get(k);
      if (!o.code && x.code) o.code = x.code;
      if (x.hosp && !o.hosps.includes(x.hosp)) o.hosps.push(x.hosp);
      if (str(x.ref) && !o.refs.some((r) => r.hosp === x.hosp)) o.refs.push({ hosp: str(x.hosp), ref: str(x.ref) });
      for (const day of Object.keys(x.values)) o.points.push({ day, v: x.values[day], hosp: str(x.hosp), flag: str((x.flags || {})[day]) });
    }
    for (const o of out.values()) o.points.sort((a, b) => (a.day < b.day ? -1 : a.day > b.day ? 1 : a.hosp < b.hosp ? -1 : 1));
    return [...out.values()];
  }
  const num = (v) => { const m = /^[<>≦≧]?\s*(-?\d+(?:\.\d+)?)\s*$/.exec(str(v)); return m ? +m[1] : null; };
  // 折線圖（黑白列印看得清楚）：x 依日期比例、y 自動範圍，每點標數值
  // 多院區：每個院區一種點的形狀＋圖例；同一天有兩點時，第二點的數值標在點下方，避免疊字
  const SHAPES = ["circle", "square", "triangle", "diamond"];
  function marker(shape, x, y) {
    const a = 'fill="#fff" stroke="#000" stroke-width="2"';
    if (shape === "square") return `<rect x="${x - 4}" y="${y - 4}" width="8" height="8" ${a}/>`;
    if (shape === "triangle") return `<polygon points="${x},${y - 5} ${x + 5},${y + 4} ${x - 5},${y + 4}" ${a}/>`;
    if (shape === "diamond") return `<polygon points="${x},${y - 5} ${x + 5},${y} ${x},${y + 5} ${x - 5},${y}" ${a}/>`;
    return `<circle cx="${x}" cy="${y}" r="4" ${a}/>`;
  }
  function trendSVG(points, hosps) {
    const hs = (hosps || []).length > 1 ? hosps : [];
    const shapeOf = (h) => SHAPES[Math.max(0, hs.indexOf(h)) % SHAPES.length];
    const pts = points.map((p) => ({ day: p.day, hosp: p.hosp, v: str(p.v), y: num(p.v), t: Date.UTC(+p.day.slice(0, 4), +p.day.slice(4, 6) - 1, +p.day.slice(6, 8)) })).filter((p) => p.y !== null).sort((a, b) => a.t - b.t);
    if (pts.length < 2) return "";
    const W = 640, H = 200, L = 46, R = 10, T = 24, B = 34;
    let lo = Math.min(...pts.map((p) => p.y)), hi = Math.max(...pts.map((p) => p.y));
    if (hi === lo) { hi += Math.abs(hi) * 0.1 || 1; lo -= Math.abs(lo) * 0.1 || 1; } else { const pad = (hi - lo) * 0.15; hi += pad; lo -= pad; }
    const t0 = pts[0].t, t1 = pts[pts.length - 1].t;
    const P = 26;   // 左右內縮，點的數值標籤才不會壓到 y 軸刻度、最後一個日期才不會被切掉
    const X = (t) => L + P + (t1 === t0 ? (W - L - R - 2 * P) / 2 : ((t - t0) / (t1 - t0)) * (W - L - R - 2 * P)), Y = (y) => T + (1 - (y - lo) / (hi - lo)) * (H - T - B);
    const g = (n) => +n.toFixed(1), lab = (y) => +y.toPrecision(3);
    const grid = [lo, (lo + hi) / 2, hi].map((y) => `<line x1="${L}" x2="${W - R}" y1="${g(Y(y))}" y2="${g(Y(y))}" stroke="#bbb" stroke-dasharray="3 3"/><text x="${L - 4}" y="${g(Y(y) + 4)}" text-anchor="end" font-size="11">${lab(y)}</text>`).join("");
    const line = `<polyline fill="none" stroke="#000" stroke-width="2" points="${pts.map((p) => g(X(p.t)) + "," + g(Y(p.y))).join(" ")}"/>`;
    const seen = new Map();
    const dots = pts.map((p) => {
      const nth = seen.get(p.day) || 0; seen.set(p.day, nth + 1);
      const x = g(X(p.t)), y = g(Y(p.y)), ly = nth % 2 ? g(Y(p.y) + 17) : g(Y(p.y) - 8);
      return marker(shapeOf(p.hosp), x, y) + `<text x="${x}" y="${ly}" text-anchor="middle" font-size="12" font-weight="700">${esc(p.v)}</text>` +
        (nth ? "" : `<text x="${x}" y="${H - 12}" text-anchor="middle" font-size="10.5">${esc(fmtDay(p.day).slice(2))}</text>`);
    }).join("");
    const legend = hs.map((h, i) => { const x = W - R - 8 - (hs.length - i) * 70; return marker(shapeOf(h), x + 6, 10) + `<text x="${x + 15}" y="14" font-size="11.5">${esc(h)}</text>`; }).join("");
    return `<svg viewBox="0 0 ${W} ${H}" width="100%" style="max-width:${W}px" role="img" aria-label="變化圖">${grid}${line}${dots}${legend}</svg>`;
  }
  // picked：combineHosp 的結果 [{name, spec, kind, unit, refs:[{hosp, ref}], hosps, points:[{day, v, hosp}]}]（ref／unit 取各院區最近一次單次報告）
  function buildTrend(o) {
    const dict = o.dict || [], all = new Set();
    const items = (o.items || []).map((x) => {
      const e = x.calc ? { zh: x.zh, cat: x.cat || "腎功能", what: x.what || "", note: "" } : lookup(dict, { name: x.name, spec: x.spec, kind: x.kind, code: x.code, unit: x.unit });
      (x.hosps || []).forEach((h) => all.add(h));
      const refs = [...new Set((x.refs || []).map((r) => refText(r.ref)))];
      const ref = refs.length <= 1 ? (refs[0] || "") : (x.refs || []).map((r) => r.hosp + "：" + refText(r.ref)).join("；");
      return { zh: e ? e.zh : "", name: x.name, cat: e ? e.cat : UNKNOWN_CAT, what: e ? e.what : "", note: e ? e.note : "", unit: str(x.unit), ref, hosps: x.hosps || [],
        urine: !x.calc && isUrine(x) && !(e && e.cat === "尿液"), rows: (x.points || []).map((p) => ({ day: p.day, v: p.v, hosp: p.hosp, value: valueText(p.v), flag: flagInfo(p.flag) })) };
    });
    return { patient: { name: str(o.patient && o.patient.name), chart: str(o.patient && o.patient.chart) }, hosp: [...all].join("、") || str(o.hosp), multi: all.size > 1,
      from: str(o.from), to: str(o.to), items, printed: str(o.now), notes: (o.notes || []).map(str).filter(Boolean) };
  }
  // v0.4.1（老闆 msg1022）：中文版附一年折線圖，五項各自開關：eGFR、UACR、UPCR（外掛計算）、HbA1c、空腹血糖（院內值）
  const TREND_KEYS = [["egfr", "eGFR"], ["uacr", "UACR"], ["upcr", "UPCR"], ["a1c", "HbA1c"], ["glu", "空腹血糖"]];
  function trendPick(o) {
    const dict = o.dict || [], items = o.items || [], on = o.on || {};
    const renal = renalTrend({ dict, items, birth: o.birth, sex: o.sex });
    const comb = combineHosp(items);
    const pick = { egfr: renal.filter((L) => L.zh === RENAL_EPI), uacr: renal.filter((L) => L.zh === RENAL_UACR), upcr: renal.filter((L) => L.zh === RENAL_UPCR),
      a1c: comb.filter((x) => !isUrine(x) && entryIs(dict, x, "糖化血色素")), glu: comb.filter((x) => isFastGlu(dict, x)) };
    const enough = (L) => L.points.filter((p) => num(p.v) !== null).length >= 2;   // 少於 2 點不畫（不留空圖框）
    return TREND_KEYS.filter(([k]) => on[k]).flatMap(([k]) => pick[k].filter(enough));
  }
  // ---------- v0.5.0「🧮 計算機」（老闆 msg1028／1030）：網頁版臨床計算機整頁包進外掛，自動貼上病人的檢驗值 ----------
  // 每項取查詢區間內最近一次有數字的值，寫成計算機「貼上檢驗資料」看得懂的一行：名稱 數值 單位 日期；尿液項目名稱前加 U-（計算機靠這個分尿／血）
  // UACR 用外掛自己的同一天配對（renalTrend），不讓計算機拿不同天的白蛋白和肌酸酐湊；eGFR 的年齡用肌酸酐那天
  function calcPrefill(o) {
    const dict = o.dict || [], items = o.items || [], lines = [];
    const latest = (it) => { const ds = Object.keys(it.values || {}).filter((d) => num(it.values[d]) !== null).sort(); return ds.length ? ds[ds.length - 1] : ""; };
    const multi = new Set(items.map((x) => str(x.hosp))).size > 1;
    // 計算機只吃 mg/dL：mmol/L、µmol/L 先換算（e2e 截圖抓到：同一天另一院區血糖 5.2 mmol/L 被當成 mg/dL）
    const CONV = { "空腹血糖": ["mmol", 18.016], "血糖": ["mmol", 18.016], "飯後血糖": ["mmol", 18.016], "總膽固醇": ["mmol", 38.67], "高密度脂蛋白膽固醇": ["mmol", 38.67],
      "低密度脂蛋白膽固醇": ["mmol", 38.67], "三酸甘油酯": ["mmol", 88.57], "肌酸酐": ["umol", 1 / 88.4] };
    const rows = [];
    for (const it of items) {
      const d = latest(it); if (!d) continue;
      let name = str(it.name).replace(/\s+/g, " ");
      if (isUrine(it) && !/^u[-\s]|urine|尿/i.test(name)) name = "U-" + name;
      let v = str(it.values[d]).replace(/≦/g, "<").replace(/≧/g, ">").replace(/\s+/g, ""), unit = str(it.unit).replace(/\s+/g, "");
      const e = isUrine(it) ? null : lookup(dict, it), c = e && CONV[e.zh], uk = unitKind(unit);
      if (c && ((c[0] === "mmol" && /mmol/i.test(unit)) || (c[0] === "umol" && uk === "umol"))) {
        const n = num(v); if (n === null) continue;
        v = String(Math.round(n * c[1] * 10) / 10); name += ` (換算自 ${c[0]})`; unit = "mg/dL";   // 名稱裡不能有數字或「/」（計算機的抓值規則）
      }
      if (multi && it.hosp) name += ` (${str(it.hosp)})`;   // 多院區：標院區（計算機會顯示「抓自」）
      rows.push({ d, pref: unit === str(it.unit).replace(/\s+/g, "") ? 0 : 1, line: `${name} ${v} ${unit} ${fmtDay(d)}`.replace(/\s+/g, " ") });
    }
    // 同一天同項有兩個院區時，計算機取先出現的那個：原本就是 mg/dL 的排前面
    rows.sort((a, b) => a.pref - b.pref);
    for (const r of rows) lines.push(r.line);
    const ua = renalTrend({ dict, items, birth: o.birth, sex: o.sex }).find((L) => L.zh === RENAL_UACR);
    if (ua && ua.points.length) { const p = ua.points[ua.points.length - 1]; lines.push(`UACR ${p.v} mg/g ${fmtDay(p.day)}`); }
    const crDays = items.filter((x) => isSerumCr(dict, x)).map(latest).filter(Boolean).sort();
    const day = crDays.length ? crDays[crDays.length - 1] : dayKey(o.to);
    const age = ageAt(o.birth, day);
    return { text: lines.join("\n"), n: lines.length, age: isNaN(age) ? null : age, sex: o.sex === "M" || o.sex === "F" ? o.sex : "",
      ageNote: isNaN(age) ? "" : `依病歷生日算到 ${fmtDay(day)}${crDays.length ? "（肌酸酐那天）" : ""}`, sexNote: o.sex ? "由身分證字號第 2 碼推得，請確認" : "",
      range: o.from && o.to ? `${fmtDay(dayKey(o.from))}～${fmtDay(dayKey(o.to))}` : "" };
  }
  // 計算機頁面＋自動填入腳本（在 sandbox iframe 裡跑；P 用 JSON 帶進去，< 跳脫）
  const CALC_GROUPS = [["FIB-4", ["ast", "alt", "plt"]], ["HOMA-IR／QUICKI", ["glu", "ins"]], ["TyG", ["tg", "glu"]], ["LDL 估算", ["tc", "tg", "hdl"]],
    ["FENa", ["una", "ucr", "na", "cr"]], ["校正鈣", ["ca", "alb"]], ["陰離子間隙", ["na", "cl", "hco3"]], ["NAFLD 纖維化分數", ["ast", "alt", "plt", "alb"]], ["APRI", ["ast", "plt"]]];
  function calcDoc(html, P) {
    const data = JSON.stringify(Object.assign({}, P, { groups: CALC_GROUPS })).replace(/</g, "\\u003c");
    const js = `<script>(function(){var P=${data};
try{
document.getElementById("paste").value=P.text;doParse();
if(P.age!==null){document.getElementById("f-age").value=P.age;document.getElementById("box-age").classList.add("filled");var a=document.getElementById("src-age");a.textContent=P.ageNote;a.classList.add("got");}
if(P.sex){document.getElementById("f-sex").value=P.sex;document.getElementById("box-sex").classList.add("filled");var x=document.getElementById("src-sex");x.textContent=P.sexNote;x.classList.add("got");}
calc();
var f=parse(P.text).found,nm=function(k){var o=F.filter(function(z){return z.k===k})[0];return o?o.n:k},warn=[];
P.groups.forEach(function(g){var ks=g[1].filter(function(k){return f[k]});if(ks.length<2)return;var ds={};ks.forEach(function(k){ds[f[k].date]=1});if(Object.keys(ds).length>1)warn.push(g[0]+"："+ks.map(function(k){return nm(k)+" "+f[k].date}).join("、"));});
var b=document.createElement("div");b.id="labzh-calc-note";b.style.cssText="background:#eef6ff;border:1px solid #9cc3f5;border-radius:8px;padding:8px 10px;margin:0 0 10px;font-size:13.5px;line-height:1.6";
b.innerHTML="";var t=document.createElement("div");t.textContent="已由「中文檢驗報告」外掛自動帶入：院內檢驗頁查詢區間 "+(P.range||"")+" 內，每一項最近一次的值（共 "+P.n+" 項，藍框；可以修改）。年齡、性別請確認；臨床狀況請自己勾。";b.appendChild(t);
if(warn.length){var w=document.createElement("div");w.style.cssText="color:#b45309;font-weight:700;margin-top:4px";w.textContent="⚠ 以下計算用到不同日期的值，請確認："+warn.join("；");b.appendChild(w);}
var wrap=document.querySelector(".wrap");wrap.insertBefore(b,wrap.children[1]||null);
}catch(e){var d=document.createElement("div");d.textContent="自動帶入失敗："+e.message+"（可以直接手動輸入）";d.style.color="#b00020";document.body.insertBefore(d,document.body.firstChild);}
})();<\/script>`;
    const i = html.lastIndexOf("</body>");
    return i < 0 ? html + js : html.slice(0, i) + js + html.slice(i);
  }
  // 一項一張圖＋數值表（v0.4.0 抽出來：中文版附 eGFR／UACR 一年折線圖也用）
  function trendSections(m) {
    const one = (it) => {
      const title = it.zh ? `${esc(it.zh)}${it.urine ? "（尿）" : ""} <span class="en">${esc(it.name)}</span>` : `${esc(it.name)} <span class="en">（無中文對照）</span>`;
      const meta = [m.multi ? "院區：" + esc(it.hosps.join("、")) : "", it.unit ? "單位：" + esc(it.unit) : "", it.ref ? "參考範圍：" + esc(it.ref) : ""].filter(Boolean).join("　");
      const rows = it.rows.map((r) => `<tr><td>${esc(fmtDay(r.day))}</td>${m.multi ? `<td>${esc(r.hosp)}</td>` : ""}<td class="v">${esc(r.value.text)}${r.value.orig ? ` <span class="orig">(${esc(r.value.orig)})</span>` : ""}${r.flag ? ` <span class="fl">${esc(r.flag.text)}</span>` : ""}</td></tr>`).join("");
      return `<section class="it"><h2>${title}</h2>${it.what ? `<p class="what">${esc(it.what)}${it.note ? `（${esc(it.note)}）` : ""}</p>` : ""}${meta ? `<p class="meta">${meta}</p>` : ""}
<div class="tw">${trendSVG(it.rows, m.multi ? it.hosps : [])}<table class="tt"><thead><tr><th>日期</th>${m.multi ? "<th>院區</th>" : ""}<th>結果</th></tr></thead><tbody>${rows}</tbody></table></div></section>`;
    };
    return m.items.map(one).join("\n");
  }
  function renderTrendHTML(m) {
    const pt = [["姓名", m.patient.name], ["病歷號", m.patient.chart], ["院區", m.hosp], ["期間", m.from && m.to ? fmtDay(m.from) + "～" + fmtDay(m.to) : ""]]
      .filter((p) => p[1]).map((p) => `<span>${esc(p[0])}：<b>${esc(p[1])}</b></span>`).join("");
    return `<!doctype html><html lang="zh-Hant"><head><meta charset="utf-8"><title>檢驗變化（中文說明版）</title><style>${CSS}
${TREND_CSS}</style></head><body>
<h1>檢驗數值變化（中文說明版）</h1>
<div class="pt">${pt}</div>
<p class="tip">數值高低的意義請和醫師討論；參考範圍以最近一次報告為準${m.multi ? "，各院區不同時分別列出" : ""}。</p>
${(m.notes || []).map((n) => `<p class="tip">※ ${esc(n)}</p>`).join("")}
${trendSections(m)}
<div class="foot">${esc(FOOTER)}<div class="ver">列印時間：${esc(m.printed)}　工具版本：${VERSION_DATE}</div></div>
</body></html>`;
  }

  // ---------- eGFR、UACR 自己算（老闆 msg900；院內檢驗報告沒有這兩項，算法同門診工作台 msg639／652）----------
  // 院內檢驗頁公式說明：18 歲以上用 EPI；MDRD-S＝院內 GFR 圖；ACR＝尿 Albumin／尿 Creatinine×1000（mg/g）
  // 院方已經有報的就用院方的，不重算。自己算的每一項都標「外掛計算」。
  const RENAL_EPI = "eGFR（CKD-EPI 2021）", RENAL_MDRD = "eGFR（MDRD，同院內 GFR 圖）", RENAL_UACR = "UACR（尿白蛋白／肌酸酐比值）";
  const RENAL_UPCR = "UPCR（尿蛋白／肌酸酐比值）";   // v0.4.0（老闆 msg1011）
  const numStrict = (v) => { const s = str(v).replace(/,/g, ""); return /^-?\d+(\.\d+)?$/.test(s) ? +s : NaN; };   // 「<0.3」這類不算
  const unitKind = (u) => { const r = str(u).toLowerCase().replace(/\s+/g, ""); return /[µμu]mol/.test(r) ? "umol" : /^mg\/dl$/.test(r) ? "mg/dL" : /^mg\/l$/.test(r) ? "mg/L" : r ? "other" : ""; };
  const entryIs = (dict, x, zh) => { const e = lookup(dict, x); return !!(e && e.zh === zh); };
  const isSerumCr = (dict, x) => !isUrine(x) && entryIs(dict, x, "肌酸酐");
  const isUrineAlb = (x) => isUrine(x) && /albumin|白蛋白|micro\s*-?\s*alb|malb|\balb\b/i.test(str(x.name)) && !/ratio|\/|globulin|球蛋白/i.test(str(x.name));
  // v0.4.1（老闆 msg1022「UACR 好像都沒有圖」）：院內尿肌酸酐叫「U-CRE」，舊式只認 Cr／Crea，U-CRE 配不到 → UACR 永遠算不出來
  const isUrineCr = (x) => isUrine(x) && /creatinine|肌酸酐|^\s*u?[-\s.]*(?:cr|cre|crea|crtn)\s*$/i.test(str(x.name)) && !/ratio|\/|clearance|廓清/i.test(str(x.name));
  const hasEgfr = (dict, x) => entryIs(dict, x, "估算腎絲球過濾率") && !isNaN(numStrict(x.value));
  const hasUacr = (dict, x) => entryIs(dict, x, "尿液白蛋白／肌酸酐比值") && !isNaN(numStrict(x.value));
  const hasUpcr = (dict, x) => entryIs(dict, x, "尿液蛋白／肌酸酐比值") && !isNaN(numStrict(x.value));
  // 尿總蛋白（定量）：只收 TP／Total protein 這類名稱；試紙「PRO」「Protein」是半定量，不收
  const isUrineProt = (x) => isUrine(x) && /^\s*(?:u[-\s.]*)?(?:t\.?\s*p\.?|total\s*protein|微量總蛋白)\s*$/i.test(str(x.name));
  // CKD-EPI 2021（不分種族）與 MDRD-S；Cr 單位 mg/dL；未滿 18 歲、性別不明都不算
  function ckdEpi2021(cr, age, sex) {
    if (!(cr > 0) || !(age >= 18) || (sex !== "F" && sex !== "M")) return NaN;
    const f = sex === "F", k = f ? 0.7 : 0.9, a = f ? -0.241 : -0.302;
    return 142 * Math.pow(Math.min(cr / k, 1), a) * Math.pow(Math.max(cr / k, 1), -1.2) * Math.pow(0.9938, age) * (f ? 1.012 : 1);
  }
  function mdrd(cr, age, sex) {
    if (!(cr > 0) || !(age >= 18) || (sex !== "F" && sex !== "M")) return NaN;
    return 175 * Math.pow(cr, -1.154) * Math.pow(age, -0.203) * (sex === "F" ? 0.742 : 1);
  }
  // 身分證字號第 2 碼：1、8 男；2、9 女；其他（含舊式居留證的英文字母）一律不明，不猜（B 審）。只在記憶體判斷，不回傳字號。
  const sexFromId = (id) => { const s = str(id).toUpperCase(); if (!/^[A-Z][0-9A-Z]\d{8}$/.test(s)) return ""; const c = s.charAt(1); return /[18]/.test(c) ? "M" : /[29]/.test(c) ? "F" : ""; };
  // 生日（西元 yyyy/mm/dd 或民國 yyy/mm/dd）→ yyyymmdd
  function birthKey(b) {
    const m = /^(\d{2,4})[\/\-.](\d{1,2})[\/\-.](\d{1,2})$/.exec(str(b));
    if (!m) return "";
    const y = m[1].length === 4 ? +m[1] : +m[1] + 1911, mo = +m[2], d = +m[3];
    if (y < 1900 || mo < 1 || mo > 12 || d < 1 || d > new Date(Date.UTC(y, mo, 0)).getUTCDate()) return "";   // 02/31 這種不存在的日期不收
    return String(y) + String(mo).padStart(2, "0") + String(d).padStart(2, "0");
  }
  function ageAt(birth, day) {
    const b = birthKey(birth), k = dayKey(day);
    if (!b || !k || k < b) return NaN;
    return +k.slice(0, 4) - +b.slice(0, 4) - (k.slice(4) < b.slice(4) ? 1 : 0);
  }
  const gStage = (v) => (v >= 90 ? "G1" : v >= 60 ? "G2" : v >= 45 ? "G3a" : v >= 30 ? "G3b" : v >= 15 ? "G4" : "G5");
  const aStage = (v) => (v < 30 ? "A1" : v <= 300 ? "A2" : "A3");
  // 一個 eGFR 值（或算不出來的原因）
  function egfrOf(kind, crRaw, crUnit, birth, sex, day) {
    const cr = numStrict(crRaw), age = ageAt(birth, day);
    if (unitKind(crUnit) !== "mg/dL" && unitKind(crUnit) !== "") return { why: "肌酸酐單位不是 mg/dL，不算" };
    if (isNaN(cr) || !(cr > 0)) return { why: "肌酸酐數值無法計算" };
    if (isNaN(age)) return { why: "讀不到生日，無法算年齡" };
    if (age < 18) return { why: "未滿 18 歲不適用（院內用 Schwartz 公式，需要身高）" };
    if (sex !== "M" && sex !== "F") return { why: "需要性別才能算" };
    const v = kind === "mdrd" ? mdrd(cr, age, sex) : ckdEpi2021(cr, age, sex);
    return { v, age };
  }
  // UACR（mg/g）＝尿白蛋白（mg/dL）÷尿肌酸酐（mg/dL）×1000；白蛋白 mg/L 先 ÷10。
  // 兩邊都要有單位（白蛋白 mg/L 或 mg/dL、肌酸酐 mg/dL）才算：單位空白時猜錯就是 10 倍誤差，而且會印給病人（B 審 m22，fail-closed）
  function uacrOf(alb, cr) {
    let a = numStrict(alb.value); const c = numStrict(cr.value), ua = unitKind(alb.unit), uc = unitKind(cr.unit);
    if (!ua || !uc) return { why: "報告沒寫單位，無法確定換算，不算" };
    if (ua === "umol" || uc === "umol" || ua === "other" || uc === "other" || uc === "mg/L") return { why: "單位無法換算" };
    if (isNaN(a) || isNaN(c) || !(c > 0) || a < 0) return { why: "數值無法計算" };
    if (ua === "mg/L") a = a / 10;
    return { v: a / c * 1000 };
  }
  const fix1 = (v) => (Math.round(v * 10) / 10).toFixed(1);
  const calcItem = (o) => Object.assign({ calc: true, value: { text: o.text, orig: "" }, critical: false, urine: false, note: "" }, o);
  // 單日報告：rows＝parseDetail 的結果（加上 hosp）；每個院區各自算（用各自的肌酸酐），院方已有的不算
  function renalCalc(o) {
    const dict = o.dict || [], rows = o.rows || [], out = [];
    const hosps = [...new Set(rows.map((x) => str(x.hosp)))];
    for (const h of hosps) {
      const rs = rows.filter((x) => str(x.hosp) === h);
      const cr = rs.find((x) => isSerumCr(dict, x) && !isNaN(numStrict(x.value)));
      if (cr && !rs.some((x) => hasEgfr(dict, x))) {
        const day = cr.sampled || o.day;
        for (const [kind, nm, how] of [["epi", RENAL_EPI, "CKD-EPI 2021（不分種族）"], ["mdrd", RENAL_MDRD, "MDRD-S 175×Cr^-1.154×年齡^-0.203（女×0.742）"]]) {
          const r = egfrOf(kind, cr.value, cr.unit, o.birth, o.sex, day);
          if (r.why) continue;   // v0.4.0（老闆 msg1011）：缺資料或算不出來就整列不顯示
          out.push(calcItem({ hosp: h, zh: nm, name: "外掛計算", text: r.why ? "—" : fix1(r.v), unit: r.why ? "" : "mL/min/1.73m²", ref: "≥60",
            flag: r.why ? null : r.v < 60 ? { cls: "lo", text: "↓偏低（外掛計算）" } : null,
            what: r.why ? r.why : `由肌酸酐 ${cr.value} mg/dL、抽血當天 ${r.age} 歲、性別推算（${how}）。腎功能分期 ${gStage(r.v)}（KDIGO：≥90 G1、60–89 G2、45–59 G3a、30–44 G3b、15–29 G4、<15 G5）` }));
        }
      }
      // UACR、UPCR（v0.4.0 加 UPCR，老闆 msg1011）：同一份尿液報告、同一次採檢；算不出來整列不顯示
      for (const [zh, isPart, has, cut, word, grade] of [
        [RENAL_UACR, isUrineAlb, hasUacr, 30, "白蛋白", (v) => `分級 ${aStage(v)}（A1 <30、A2 30–300、A3 >300 mg/g）`],
        [RENAL_UPCR, isUrineProt, hasUpcr, 150, "總蛋白", (v) => (v < 150 ? "正常範圍（<150 mg/g）" : v <= 500 ? "輕度蛋白尿（150–500 mg/g）" : "明顯蛋白尿（>500 mg/g）")]]) {
        if (rs.some((x) => has(dict, x))) continue;
        const groups = new Map();
        for (const x of rs) {
          if (!isPart(x) && !isUrineCr(x)) continue;
          const g = str(x.kind) + "|" + dayKey(x.sampled);
          if (!groups.has(g)) groups.set(g, { alb: null, cr: null });
          const gg = groups.get(g); if (isPart(x) && !gg.alb) gg.alb = x; else if (isUrineCr(x) && !gg.cr) gg.cr = x;
        }
        for (const gg of groups.values()) {
          if (!gg.alb || !gg.cr) continue;   // 只配同一份尿液報告、同一次採檢
          const r = uacrOf(gg.alb, gg.cr);
          if (r.why) continue;
          out.push(calcItem({ hosp: h, zh, name: "外掛計算", text: fix1(r.v), unit: "mg/g", ref: "<" + cut,
            flag: r.v >= cut ? { cls: "hi", text: "↑偏高（外掛計算）" } : null,
            what: `同一份尿液檢體：${word} ${gg.alb.value} ${gg.alb.unit || ""} ÷ 肌酸酐 ${gg.cr.value} ${gg.cr.unit || ""}。${grade(r.v)}` }));
          break;
        }
      }
    }
    return out;
  }
  // 多項變化：items＝mixMerge 的結果（已補 unit），各院區各自算，同一公式各院區合成一條線（點標院區）
  function renalTrend(o) {
    const dict = o.dict || [], items = o.items || [], lines = new Map();
    const add = (key, zh, unit, ref, what, hosp, day, v) => {
      if (!lines.has(key)) lines.set(key, { id: "calc-" + key, calc: true, zh, cat: "腎功能", name: "外掛計算", spec: "", kind: "", code: "", unit, refs: [{ hosp: "", ref }], hosps: [], points: [], what });
      const L = lines.get(key);
      if (hosp && !L.hosps.includes(hosp)) L.hosps.push(hosp);
      L.points.push({ day, v: fix1(v), hosp });
    };
    const hosps = [...new Set(items.map((x) => str(x.hosp)))];
    for (const h of hosps) {
      const its = items.filter((x) => str(x.hosp) === h);
      if (its.some((x) => entryIs(dict, x, "估算腎絲球過濾率"))) { /* 院方有報 eGFR：不重算 */ } else {
        // 同院區可能有兩種血清肌酸酐代碼（例如急件）：每一個都用，同一天只取第一個
        const done = new Set();
        for (const cr of its.filter((x) => isSerumCr(dict, x) && (unitKind(x.unit) === "mg/dL" || unitKind(x.unit) === ""))) for (const day of Object.keys(cr.values)) {
          if (done.has(day)) continue; done.add(day);
          const e = egfrOf("epi", cr.values[day], cr.unit, o.birth, o.sex, day), m = egfrOf("mdrd", cr.values[day], cr.unit, o.birth, o.sex, day);
          if (!e.why) add("epi", RENAL_EPI, "mL/min/1.73m²", "≥60", "外掛計算：CKD-EPI 2021（不分種族），用每次的肌酸酐和抽血當天年齡", h, day, e.v);
          if (!m.why) add("mdrd", RENAL_MDRD, "mL/min/1.73m²", "≥60", "外掛計算：MDRD-S（和院內 GFR 圖同一個公式）", h, day, m.v);
        }
      }
      if (!its.some((x) => entryIs(dict, x, "尿液白蛋白／肌酸酐比值"))) {
        // 同一天、白蛋白與肌酸酐各「剛好一筆」才配（同一天有 24 小時尿和隨機尿時不猜，B 審 m23）
        const albs = its.filter((x) => isUrineAlb(x)), ucrs = its.filter((x) => isUrineCr(x));
        const days = new Set(albs.flatMap((x) => Object.keys(x.values)));
        for (const day of days) {
          const a1 = albs.filter((x) => day in x.values), c1 = ucrs.filter((x) => day in x.values);
          if (a1.length !== 1 || c1.length !== 1) continue;
          const alb = a1[0], ucr = c1[0];
          const r = uacrOf({ value: alb.values[day], unit: alb.unit }, { value: ucr.values[day], unit: ucr.unit });
          if (!r.why) add("uacr", RENAL_UACR, "mg/g", "<30", "外掛計算：同一天尿液的白蛋白÷肌酸酐×1000", h, day, r.v);
        }
      }
      if (!its.some((x) => entryIs(dict, x, "尿液蛋白／肌酸酐比值"))) {   // UPCR（v0.4.0）：規則同 UACR
        const tps = its.filter((x) => isUrineProt(x)), ucrs = its.filter((x) => isUrineCr(x));
        for (const day of new Set(tps.flatMap((x) => Object.keys(x.values)))) {
          const a1 = tps.filter((x) => day in x.values), c1 = ucrs.filter((x) => day in x.values);
          if (a1.length !== 1 || c1.length !== 1) continue;
          const r = uacrOf({ value: a1[0].values[day], unit: a1[0].unit }, { value: c1[0].values[day], unit: c1[0].unit });
          if (!r.why) add("upcr", RENAL_UPCR, "mg/g", "<150", "外掛計算：同一天尿液的總蛋白÷肌酸酐×1000", h, day, r.v);
        }
      }
    }
    const out = [...lines.values()];
    for (const L of out) L.points.sort((a, b) => (a.day < b.day ? -1 : a.day > b.day ? 1 : a.hosp < b.hosp ? -1 : 1));
    return out;
  }

  // ---------- FIB-4（老闆 msg904）、HOMA-IR（msg905）：院內沒報時外掛計算 ----------
  // 規則同 eGFR／UACR：同院區、同一天、每一項各剛好一筆、單位認得才算；認不得就寫原因，不猜。
  const RENAL_FIB4 = "FIB-4（肝纖維化指數）", RENAL_HOMA = "HOMA-IR（胰島素阻抗指數）";
  const normU = (u) => str(u).toLowerCase().replace(/[µμ]/g, "u").replace(/\s+/g, "").replace(/[x×*]/g, "");
  const isUL = (u) => /^(i?u\/l|u\/l)$/.test(normU(u));   // AST、ALT：U/L 或 IU/L
  // 血小板 → 10⁹/L（＝10³/µL）的倍數；認不得回 0
  function pltFactor(u) {
    const n = normU(u).replace(/\^/g, "");
    if (/^(103\/ul|k\/ul|109\/l|1000\/ul|thou\/ul|千\/ul)$/.test(n)) return 1;
    if (/^(104\/ul|萬\/ul)$/.test(n)) return 10;
    if (/^(\/ul|\/mm3|cells\/ul)$/.test(n)) return 0.001;
    return 0;
  }
  const gluDiv = (u) => { const n = normU(u); return n === "mg/dl" ? 405 : n === "mmol/l" ? 22.5 : 0; };
  // 胰島素：µU/mL＝µIU/mL＝mU/L；pmol/L ÷6（6 pmol/L＝1 µU/mL）
  const insFactor = (u) => { const n = normU(u); return /^(uu\/ml|uiu\/ml|mu\/l|miu\/l)$/.test(n) ? 1 : n === "pmol/l" ? 1 / 6 : 0; };
  const isAST = (dict, x) => !isUrine(x) && entryIs(dict, x, "天門冬胺酸轉胺酶（GOT）");
  const isALT = (dict, x) => !isUrine(x) && entryIs(dict, x, "丙胺酸轉胺酶（GPT）");
  const isPLT = (dict, x) => !isUrine(x) && entryIs(dict, x, "血小板");
  const isFastGlu = (dict, x) => !isUrine(x) && entryIs(dict, x, "空腹血糖") && !OGTT_LATE.test(str(x.name));
  // OGTT 序列：0 分鐘以外的時點都不收；名字沒寫時點的胰島素當一般（空腹）抽血
  const OGTT_LATE = /(^|[^\d])(15|30|45|60|90|120|150|180|240)\s*(min|分|'|’|m\b)|\b[1-4]\s*(h|hr|hour)s?\b|\bpc\b|飯後|post/i;
  const isFastIns = (dict, x) => !isUrine(x) && entryIs(dict, x, "胰島素") && !OGTT_LATE.test(str(x.name));
  const hasFib4 = (dict, x) => /fib-?4/i.test(str(x.name)) && !isNaN(numStrict(x.value));
  const hasHoma = (dict, x) => entryIs(dict, x, "胰島素阻抗指數") && !isNaN(numStrict(x.value));
  function fib4Of(age, ast, alt, plt) {
    const a = numStrict(ast.value), l = numStrict(alt.value), p = numStrict(plt.value), f = pltFactor(plt.unit);
    if (!isUL(ast.unit) || !isUL(alt.unit)) return { why: "AST／ALT 單位不是 U/L（或沒寫），不算" };
    if (!f) return { why: "血小板單位認不得（或沒寫），不算" };
    if (isNaN(age)) return { why: "讀不到生日，無法算年齡" };
    if (age < 18) return { why: "未滿 18 歲不適用" };
    if (isNaN(a) || isNaN(l) || isNaN(p) || !(l > 0) || !(p > 0) || a < 0) return { why: "數值無法計算" };
    return { v: age * a / (p * f * Math.sqrt(l)), age };
  }
  function fib4Text(v, age) {
    const lo = age >= 65 ? 2.0 : 1.3, risk = v < lo ? "低風險" : v > 2.67 ? "高風險" : "不確定（建議進一步評估，例如肝臟彈性檢查）";
    return `年齡×AST÷（血小板×√ALT），抽血當天 ${age} 歲。判讀：<${lo} 低風險${age >= 65 ? "（65 歲以上低切點改用 2.0）" : ""}、${lo}–2.67 不確定、>2.67 高風險 → ${risk}` + (age < 35 ? "。35 歲以下準確度較差" : "");
  }
  function homaOf(glu, ins) {
    const g = numStrict(glu.value), i = numStrict(ins.value), d = gluDiv(glu.unit), f = insFactor(ins.unit);
    if (!d) return { why: "血糖單位認不得（或沒寫），不算" };
    if (!f) return { why: "胰島素單位認不得（或沒寫），不算" };
    if (isNaN(g) || isNaN(i) || g <= 0 || i < 0) return { why: "數值無法計算" };
    return { v: g * i * f / d, how: (d === 405 ? "血糖(mg/dL)×胰島素(µU/mL)÷405" : "血糖(mmol/L)×胰島素(µU/mL)÷22.5") + (f !== 1 ? "；胰島素 pmol/L 先 ÷6 換成 µU/mL" : "") };
  }
  const HOMA_NOTE = "僅適用空腹、未使用胰島素者（外掛讀不到用藥，請自行確認）。參考：>2.5 提示胰島素阻抗（切點依族群不同，非官方參考值）";
  // 同院區、同一天，每個 pred 各剛好一筆 → 回 [{day, picks}]；有任一項 0 筆就略過，>1 筆就回 why
  function dayGroups(rows, preds) {
    const days = new Map();
    for (const x of rows) { const d = dayKey(x.sampled); if (!d) continue; if (!days.has(d)) days.set(d, []); days.get(d).push(x); }
    const out = [];
    for (const [day, rs] of days) {
      const picks = preds.map((p) => rs.filter((x) => p(x) && !isNaN(numStrict(x.value))));
      if (picks.some((p) => !p.length)) continue;
      out.push(picks.every((p) => p.length === 1) ? { day, picks: picks.map((p) => p[0]) } : { day, why: "同一天同一項有兩筆以上，不知道該配哪一筆，不算" });
    }
    return out;
  }
  function metabCalc(o) {
    const dict = o.dict || [], rows = o.rows || [], liver = [], glu = [];
    for (const h of [...new Set(rows.map((x) => str(x.hosp)))]) {
      const rs = rows.filter((x) => str(x.hosp) === h);
      if (!rs.some((x) => hasFib4(dict, x))) for (const g of dayGroups(rs, [(x) => isAST(dict, x), (x) => isALT(dict, x), (x) => isPLT(dict, x)])) {
        const r = g.why ? { why: g.why } : fib4Of(ageAt(o.birth, g.day), g.picks[0], g.picks[1], g.picks[2]);
        if (r.why) continue;   // v0.4.0（老闆 msg1011）：缺資料不顯示
        liver.push(calcItem({ hosp: h, zh: RENAL_FIB4, name: "外掛計算", text: r.why ? "—" : r.v.toFixed(2), unit: "", ref: "<1.3（≥65 歲 <2.0）",
          flag: r.why ? null : r.v > 2.67 ? { cls: "hi", text: "↑高風險（外掛計算）" } : null, what: r.why || fib4Text(r.v, r.age) }));
      }
      if (!rs.some((x) => hasHoma(dict, x))) for (const g of dayGroups(rs, [(x) => isFastGlu(dict, x), (x) => isFastIns(dict, x)])) {
        const r = g.why ? { why: g.why } : homaOf(g.picks[0], g.picks[1]);
        if (r.why) continue;
        glu.push(calcItem({ hosp: h, zh: RENAL_HOMA, name: "外掛計算", text: r.why ? "—" : r.v.toFixed(2), unit: "", ref: "參考 ≤2.5",
          flag: r.why ? null : r.v > 2.5 ? { cls: "hi", text: "↑偏高（外掛計算）" } : null, what: r.why ? r.why : `同一次空腹採檢：${r.how}。${HOMA_NOTE}` }));
      }
    }
    return { liver, glu };
  }
  // 多項變化：同院區、同一天，各項目剛好一個 item 有值才算
  function metabTrend(o) {
    const dict = o.dict || [], items = o.items || [], lines = new Map();
    const add = (key, zh, cat, ref, what, hosp, day, v) => {
      if (!lines.has(key)) lines.set(key, { id: "calc-" + key, calc: true, zh, cat, name: "外掛計算", spec: "", kind: "", code: "", unit: "", refs: [{ hosp: "", ref }], hosps: [], points: [], what });
      const L = lines.get(key); if (hosp && !L.hosps.includes(hosp)) L.hosps.push(hosp); L.points.push({ day, v: v.toFixed(2), hosp });
    };
    const one = (list, day) => { const c = list.filter((x) => day in x.values && !isNaN(numStrict(x.values[day]))); return c.length === 1 ? { value: c[0].values[day], unit: c[0].unit } : null; };
    for (const h of [...new Set(items.map((x) => str(x.hosp)))]) {
      const its = items.filter((x) => str(x.hosp) === h);
      if (!its.some((x) => /fib-?4/i.test(str(x.name)))) {
        const A = its.filter((x) => isAST(dict, x)), L = its.filter((x) => isALT(dict, x)), P = its.filter((x) => isPLT(dict, x));
        for (const day of new Set(A.flatMap((x) => Object.keys(x.values)))) {
          const a = one(A, day), l = one(L, day), p = one(P, day);
          if (!a || !l || !p) continue;
          const r = fib4Of(ageAt(o.birth, day), a, l, p);
          if (!r.why) add("fib4", RENAL_FIB4, "肝功能", "<1.3（≥65 歲 <2.0）", "外掛計算：年齡×AST÷（血小板×√ALT），同一天抽血；<1.3 低風險（65 歲以上 <2.0）、>2.67 高風險", h, day, r.v);
        }
      }
      if (!its.some((x) => entryIs(dict, x, "胰島素阻抗指數"))) {
        const G = its.filter((x) => isFastGlu(dict, x)), I = its.filter((x) => isFastIns(dict, x));
        for (const day of new Set(G.flatMap((x) => Object.keys(x.values)))) {
          const g = one(G, day), i = one(I, day);
          if (!g || !i) continue;
          const r = homaOf(g, i);
          if (!r.why) add("homa", RENAL_HOMA, "血糖", "參考 ≤2.5", "外掛計算：同一天空腹血糖×空腹胰島素÷405。" + HOMA_NOTE, h, day, r.v);
        }
      }
    }
    const out = [...lines.values()];
    for (const L of out) L.points.sort((a, b) => (a.day < b.day ? -1 : a.day > b.day ? 1 : a.hosp < b.hosp ? -1 : 1));
    return out;
  }

  return { splitFlag, trendSections, trendPick, calcPrefill, calcDoc, CALC_GROUPS, TREND_KEYS, isUrineCr, VERSION_DATE, FOOTER, CAT_ORDER, UNKNOWN_CAT, NO_TREND, esc, compileDict, lookup, isUrine, valueText, flagInfo, refText, parseDetail, buildReport, renderHTML,
    fmtDay, dayKey, mixMerge, combineHosp, num, trendSVG, buildTrend, renderTrendHTML,
    ckdEpi2021, mdrd, sexFromId, birthKey, ageAt, gStage, aStage, renalCalc, renalTrend, RENAL_EPI, RENAL_MDRD, RENAL_UACR, RENAL_UPCR, isUrineProt,
    metabCalc, metabTrend, pltFactor, RENAL_FIB4, RENAL_HOMA };
})();
if (typeof module !== "undefined") module.exports = LABZH;
