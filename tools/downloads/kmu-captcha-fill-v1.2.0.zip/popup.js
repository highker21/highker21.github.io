(async () => {
  const s = await chrome.storage.local.get({ enabled: true, autoSubmit: true });
  for (const k of ["enabled", "autoSubmit"]) {
    const el = document.getElementById(k); el.checked = !!s[k];
    el.addEventListener("change", () => chrome.storage.local.set({ [k]: el.checked }));
  }
  document.getElementById("collect").addEventListener("click", async () => {
    const m = document.getElementById("cmsg");
    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      const r = await chrome.tabs.sendMessage(tab.id, { type: "collect", n: 40 });
      m.textContent = r && r.ok ? "收集中（約 30 秒），完成會自動下載，頁面上方會顯示進度。" : (r && r.why) || "收集失敗";
    } catch (e) { m.textContent = "這一頁不是單一入口登入頁（外掛沒有在這頁作用），請先打開登入頁再按。"; }
  });
})();
