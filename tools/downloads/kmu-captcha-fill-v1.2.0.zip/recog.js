// v1.1.0 院內驗證碼專用辨識（純函式，content script 與 node 測試共用；不連外、不用 tesseract）
// 依 2026-11-20 老闆傳回的 40 張院內真圖設計：圖分兩型
//   plain：單一底色（綠/紅/橘/藍/咖啡/深藍/黑）＋白字，字型每張不同（Times、Arial、Courier、Impact…）
//   noisy：白底＋灰色干擾線＋透明雜點，藍紫色粗斜體字
// 做法：分型二值化 → 依連通塊切成 4 個字 → 縮成 12×16 → 和「標準字型畫出來的範本」（templates.js，不含院內真圖）比最近的
var KMU_RECOG = (function () {
  const GW = 12, GH = 16, RATIO_W = 20, MAX_DIST = 30; // 30：真圖答對者最大 21.6、唯一錯例 32.7（B 審 Minor 1，看這批圖定的）

  // RGBA → 字的遮罩（1＝字）。透明像素先疊在白底上
  function inkMask(rgba, w, h) {
    const n = w * h, R = new Float32Array(n), G = new Float32Array(n), B = new Float32Array(n), cnt = new Map();
    for (let i = 0; i < n; i++) {
      const a = rgba[i * 4 + 3] / 255;
      R[i] = rgba[i * 4] * a + 255 * (1 - a); G[i] = rgba[i * 4 + 1] * a + 255 * (1 - a); B[i] = rgba[i * 4 + 2] * a + 255 * (1 - a);
      const k = (R[i] << 16) | (G[i] << 8) | B[i]; cnt.set(k, (cnt.get(k) || 0) + 1);
    }
    let bk = 0, bc = 0; for (const [k, c] of cnt) if (c > bc) { bc = c; bk = k; }
    const br = (bk >> 16) & 255, bg = (bk >> 8) & 255, bb = bk & 255;
    const plain = bc / n > 0.5 && !(br > 230 && bg > 230 && bb > 230);
    const m = new Uint8Array(n);
    for (let i = 0; i < n; i++) {
      if (plain) { // 比較像白色還是像底色
        const dw = (255 - R[i]) ** 2 + (255 - G[i]) ** 2 + (255 - B[i]) ** 2, db = (R[i] - br) ** 2 + (G[i] - bg) ** 2 + (B[i] - bb) ** 2;
        m[i] = dw < db ? 1 : 0;
      } else m[i] = G[i] < 110 && R[i] < 200 && B[i] - G[i] > 40 ? 1 : 0; // 藍紫字；灰線（192）與白底排除
    }
    if (!plain) { // 透明雜點打在字上的洞：原本透明、上下左右有 ≥2 個字的像素補回
      const src = m.slice();
      for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
        const i = y * w + x; if (rgba[i * 4 + 3] === 255 || src[i]) continue;
        let c = 0; if (x > 0) c += src[i - 1]; if (x < w - 1) c += src[i + 1]; if (y > 0) c += src[i - w]; if (y < h - 1) c += src[i + w];
        if (c >= 2) m[i] = 1;
      }
    }
    return { mask: m, type: plain ? "plain" : "noisy" };
  }

  function components(m, w, h, minA) {
    const lab = new Uint8Array(w * h), out = [];
    for (let i = 0; i < w * h; i++) if (m[i] && !lab[i]) {
      const st = [i], px = []; lab[i] = 1;
      while (st.length) {
        const j = st.pop(); px.push(j); const x = j % w, y = (j / w) | 0;
        for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) {
          const xx = x + dx, yy = y + dy; if (xx < 0 || yy < 0 || xx >= w || yy >= h) continue;
          const q = yy * w + xx; if (m[q] && !lab[q]) { lab[q] = 1; st.push(q); }
        }
      }
      if (px.length < minA) continue;
      let x0 = 1e9, x1 = -1; for (const j of px) { const x = j % w; if (x < x0) x0 = x; if (x > x1) x1 = x; }
      out.push({ x0, x1, px });
    }
    return out.sort((a, b) => a.x0 - b.x0);
  }

  // 切成 n 個字：x 範圍重疊一半以上的塊先合併（斷筆）；太多就合併間距最小的；太少就把最寬的從中段最細處切開
  function segment(m, w, h, n) {
    const cs = components(m, w, h, 4);
    const merge = (i) => { const a = cs[i], b = cs[i + 1]; cs.splice(i, 2, { x0: Math.min(a.x0, b.x0), x1: Math.max(a.x1, b.x1), px: a.px.concat(b.px) }); };
    for (let changed = true; changed;) {
      changed = false;
      for (let i = 0; i + 1 < cs.length; i++) {
        const a = cs[i], b = cs[i + 1], ov = Math.min(a.x1, b.x1) - Math.max(a.x0, b.x0);
        if (ov >= Math.min(a.x1 - a.x0, b.x1 - b.x0) * 0.5) { merge(i); changed = true; break; }
      }
    }
    while (cs.length > n) {
      let bi = 0, bg = 1e9;
      for (let i = 0; i + 1 < cs.length; i++) { const g = cs[i + 1].x0 - cs[i].x1 + Math.min(cs[i].px.length, cs[i + 1].px.length) * 0.01; if (g < bg) { bg = g; bi = i; } }
      merge(bi);
    }
    while (cs.length < n && cs.length) {
      let bi = 0; for (let i = 1; i < cs.length; i++) if (cs[i].x1 - cs[i].x0 > cs[bi].x1 - cs[bi].x0) bi = i;
      const c = cs[bi], col = new Array(c.x1 - c.x0 + 1).fill(0); for (const j of c.px) col[(j % w) - c.x0]++;
      const L = col.length; let cut = (L / 2) | 0, best = 1e9;
      for (let x = (L * 0.3) | 0; x <= (L * 0.7) | 0; x++) if (col[x] < best) { best = col[x]; cut = x; }
      const a = c.px.filter((j) => (j % w) - c.x0 < cut), b = c.px.filter((j) => (j % w) - c.x0 >= cut);
      if (!a.length || !b.length) break;
      cs.splice(bi, 1, { x0: c.x0, x1: c.x0 + cut - 1, px: a }, { x0: c.x0 + cut, x1: c.x1, px: b });
    }
    return cs.map((c) => {
      let y0 = 1e9, y1 = -1; for (const j of c.px) { const y = (j / w) | 0; if (y < y0) y0 = y; if (y > y1) y1 = y; }
      const gw = c.x1 - c.x0 + 1, gh = y1 - y0 + 1, b = new Uint8Array(gw * gh);
      for (const j of c.px) b[(((j / w) | 0) - y0) * gw + (j % w) - c.x0] = 1;
      return { w: gw, h: gh, b };
    });
  }

  // 裁好的字點陣 → 12×16 面積平均向量＋寬高比
  function norm(g) {
    const v = new Float32Array(GW * GH);
    for (let y = 0; y < GH; y++) for (let x = 0; x < GW; x++) {
      const sx0 = x * g.w / GW, sx1 = (x + 1) * g.w / GW, sy0 = y * g.h / GH, sy1 = (y + 1) * g.h / GH; let s = 0, a = 0;
      for (let yy = Math.floor(sy0); yy < Math.ceil(sy1); yy++) for (let xx = Math.floor(sx0); xx < Math.ceil(sx1); xx++) {
        const wt = (Math.min(xx + 1, sx1) - Math.max(xx, sx0)) * (Math.min(yy + 1, sy1) - Math.max(yy, sy0)); if (wt <= 0) continue;
        s += wt * (g.b[yy * g.w + xx] ? 1 : 0); a += wt;
      }
      v[y * GW + x] = a ? s / a : 0;
    }
    return { v, r: g.w / g.h };
  }

  // templates.js 的字串格式：每個範本 "字元|寬高比|192 個 0–f"
  let T = null;
  function templates() {
    if (T) return T;
    const src = typeof KMU_TEMPLATES !== "undefined" ? KMU_TEMPLATES : [];
    T = src.map((s) => { const [c, r, hex] = s.split("|"); const v = new Float32Array(GW * GH); for (let i = 0; i < v.length; i++) v[i] = parseInt(hex[i], 16) / 15; return { c, r: +r, v }; });
    return T;
  }
  function classify(g) {
    const per = {};
    for (const t of templates()) {
      let d = 0; for (let i = 0; i < t.v.length; i++) { const x = g.v[i] - t.v[i]; d += x * x; }
      const lr = Math.log(g.r / t.r); d += RATIO_W * lr * lr;
      if (per[t.c] == null || d < per[t.c]) per[t.c] = d;
    }
    let c = "", d = 1e9; for (const k in per) if (per[k] < d) { d = per[k]; c = k; }
    return { c, d };
  }

  // 主函式：回傳 { code: 4 碼或 ""、type、maxDist }。任何一個字和範本差太多（新字型／圖壞了）就回 ""，讓外層換圖
  function recognize(rgba, w, h) {
    if (!w || !h || !rgba || rgba.length < w * h * 4) return { code: "", type: "", maxDist: 0 };
    const { mask, type } = inkMask(rgba, w, h);
    const gs = segment(mask, w, h, 4);
    if (gs.length !== 4) return { code: "", type, maxDist: 0 };
    let code = "", maxDist = 0;
    for (const g of gs) { const r = classify(norm(g)); code += r.c; if (r.d > maxDist) maxDist = r.d; }
    return { code: maxDist > MAX_DIST || code.length !== 4 ? "" : code, type, maxDist };
  }
  return { recognize, inkMask, segment, norm, GW, GH, MAX_DIST, _reset: () => { T = null; } };
})();
if (typeof module !== "undefined") module.exports = KMU_RECOG;
