// 甲狀腺超音波名單：先送 4 次 getExamListData，再送 getExamRoomListDetail 取名單
// 要整段注入院內排程系統分頁執行（chrome.scripting 的 func），所以不能用外面的變數
// ymd：YYYY-MM-DD；noon：A 上午、P 下午、S 夜診；status：F 已執行、N 未執行
async function fetchExamList(base, dept, noon, ymd, status) {
  const LOGIN = /高醫體系資訊系統入口網|資訊系統入口網|kmuh-captcha|AuthServer|\/Account\/Login/i;
  const sig = () => (typeof AbortSignal !== "undefined" && AbortSignal.timeout ? AbortSignal.timeout(15000) : undefined);
  const d = ymd + "T00:00";
  // 五次查詢的欄位與順序
  const P = {
    1: [["in_MACHINClist", ""], ["EXAM_DEPT", dept], ["EXAM_NOON", noon], ["EXAM_DATE", d], ["ENDEXAM_DATE", d], ["EXAM_MACHINE", ""], ["EXAM_STATUS", status], ["EXAM_CPLT", "P"], ["in_SELECT_TYPE", "EXAM_DEPT"]],
    2: [["in_MACHINClist", ""], ["EXAM_DEPT", dept], ["EXAM_NOON", noon], ["EXAM_DATE", d], ["ENDEXAM_DATE", d], ["EXAM_STATUS", status], ["EXAM_CPLT", "P"], ["in_SELECT_TYPE", "EXAM_DEPT"]],
    3: [["in_MACHINClist", ""], ["EXAM_DEPT", dept], ["EXAM_KIND", "THYE"], ["EXAM_NOON", noon], ["EXAM_DATE", d], ["ENDEXAM_DATE", d], ["EXAM_MACHINE", ""], ["EXAM_STATUS", status], ["EXAM_CPLT", "P"], ["in_SELECT_TYPE", "EXAM_KIND"]],
    4: [["in_MACHINClist", ""], ["EXAM_DEPT", dept], ["EXAM_KIND", "THYE"], ["EXAM_NOON", noon], ["EXAM_DATE", d], ["ENDEXAM_DATE", d], ["EXAM_MACHINE", ""], ["EXAM_STATUS", status], ["EXAM_CPLT", "P"], ["in_SELECT_TYPE", "EXAM_MACHINE"]],
    5: [["in_MACHINClist", ""], ["EXAM_DEPT", dept], ["EXAM_KIND", "THYE"], ["EXAM_NOON", noon], ["CHECK_USER_ID", ""], ["EXAM_DATE", d], ["ENDEXAM_DATE", d], ["EXAM_MACHINE", ""], ["EXAM_STATUS", status], ["EXAM_CPLT", "P"], ["in_SELECT_TYPE", "EXAM_MACHINE"]],
  };
  const post = (path, pairs) => fetch(base + path, { method: "POST", credentials: "include", redirect: "manual", signal: sig(),
    headers: { "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8" }, body: new URLSearchParams(pairs).toString() });
  const moved = (r) => r.type === "opaqueredirect" || (r.status >= 300 && r.status < 400);
  try {
    for (const k of [1, 2, 3, 4]) {
      const r = await post("/WEB/EXAMScheduleWeb/EXAM/getExamListData", P[k]);
      if (moved(r)) return { stage: "login" };
      if (r.status !== 200) return { stage: "http", status: r.status };
    }
    const r = await post("/WEB/EXAMScheduleWeb/EXAM/getExamRoomListDetail", P[5]);
    if (moved(r)) return { stage: "login" };
    if (r.status !== 200) return { stage: "http", status: r.status };
    const t = await r.text();
    if (LOGIN.test(t)) return { stage: "login" };
    let data;
    try { data = JSON.parse(t); } catch (e) { return { stage: "format" }; }
    if (typeof data === "string") { try { data = JSON.parse(data); } catch (e) { return { stage: "format" }; } }
    if (!Array.isArray(data)) return { stage: "format" };
    const rows = data.map((x) => ({ seq: String(x.EXAM_SEQNO ?? ""), time: String(x.EXAM_TIME ?? ""), chartno: String(x.CHART_NO ?? "").trim(),
      name: String(x.PATIENT_NAME ?? ""), mrnUrl: String(x.MRN_URL ?? "").trim() })).filter((x) => x.chartno);
    return { stage: "ok", rows };
  } catch (e) {
    return { stage: "error", detail: "連不到院內排程系統或逾時（是否在院內網路？）" };
  }
}

if (typeof module !== "undefined") module.exports = { fetchExamList };
