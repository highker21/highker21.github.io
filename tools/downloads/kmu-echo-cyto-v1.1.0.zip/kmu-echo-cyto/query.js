// 查一位病人分三段：getChartUrl 取病歷網址 → batch.js 在背景分頁真的打開病歷頁（院內系統要頁面實際開起來才會切到這位病人）→ readExam 讀檢查報告頁
// 這裡的函式要能整段注入院內分頁執行（chrome.scripting 的 func），所以不能用外面的變數

// 1. 取病歷網址
async function getChartUrl(apiUrl, chartno, staff) {
  const LOGIN = /高醫體系資訊系統入口網|資訊系統入口網|kmuh-captcha|AuthServer|\/Account\/Login/i;
  // 每個請求最多等 8 秒，院外網路不會卡住整批
  const sig = () => (typeof AbortSignal !== "undefined" && AbortSignal.timeout ? AbortSignal.timeout(8000) : undefined);
  try {
    const r = await fetch(apiUrl, { method: "POST", credentials: "include", redirect: "manual", signal: sig(),
      headers: { "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8" },
      body: new URLSearchParams({ inChartno: chartno, inLoginUser: staff }).toString() });
    if (r.type === "opaqueredirect" || (r.status >= 300 && r.status < 400)) return { stage: "login" };
    if (r.status !== 200) return { stage: "http", status: r.status };
    let t = (await r.text()).trim();
    if (t.startsWith('"') && t.endsWith('"')) { try { t = JSON.parse(t); } catch (e) { t = t.slice(1, -1); } }
    t = t.trim();
    if (LOGIN.test(t) || /<html|<!doctype/i.test(t)) return { stage: "login" };
    if (!/^https?:\/\/\S+$/i.test(t)) return { stage: "notfound" };
    // 查無病歷號時後端回固定的空值密文，或 id= 後面是空的
    if (/id=50FB72297079EEFA/i.test(t) || /[?&]id=(?:$|&)/i.test(t)) return { stage: "notfound" };
    return { stage: "url", url: t };
  } catch (e) {
    return { stage: "error", detail: "連不到院內系統或逾時（是否在院內網路？）" };
  }
}

// 病歷分頁載完後注入：看它是不是被導到登入頁
function pageIsLogin() {
  const LOGIN = /高醫體系資訊系統入口網|資訊系統入口網|kmuh-captcha|AuthServer|\/Account\/Login/i;
  return LOGIN.test(location.href) || LOGIN.test(document.title || "") || LOGIN.test(document.body ? document.body.textContent.slice(0, 5000) : "");
}

// 3. 檢查報告頁（GET，不帶日期，由院內系統預設範圍）
async function readExam(examUrl, chartno) {
  const LOGIN = /高醫體系資訊系統入口網|資訊系統入口網|kmuh-captcha|AuthServer|\/Account\/Login/i;
  const sig = () => (typeof AbortSignal !== "undefined" && AbortSignal.timeout ? AbortSignal.timeout(8000) : undefined);
  try {
    const r = await fetch(examUrl, { credentials: "include", redirect: "manual", signal: sig() });
    if (r.type === "opaqueredirect" || (r.status >= 300 && r.status < 400)) return { stage: "login" };
    if (r.status !== 200) return { stage: "http", status: r.status };
    const html = await r.text();
    if (LOGIN.test(html)) return { stage: "login" };
    const doc = new DOMParser().parseFromString(html, "text/html");
    const title = doc.querySelector("title");
    if (title && title.textContent.trim() === "錯誤") return { stage: "error", detail: "院內系統回「錯誤」頁" };
    // 只取第 3 個 tbody 裡 onclick="showReport(this)" 的列；少於 3 個 tbody 代表頁面不是預期的報告頁
    const tbodies = doc.querySelectorAll("tbody");
    if (tbodies.length < 3) return { stage: "format" };
    const rows = [...tbodies[2].querySelectorAll('tr[onclick*="showReport"]')]
      .map((tr) => ({ text: tr.textContent || "", content: tr.getAttribute("data-content") || "" }));
    // 頁面上（頁首病人資訊等）看得到的病歷號，用來核對 session 有沒有切到這位病人
    // 號碼＝最多 2 個英文字母開頭＋至少 6 位數字：冒號可省略，「病歷號碼」後面接英文表頭（Date 之類）不能當成病歷號；
    // textContent 會把相鄰儲存格黏在一起（00012345Date），只取到數字結束；後面接 / - . 的是日期（病歷號碼2026/10/25），不算；「-一碼」是檢查碼寫法（0012345-6），一起抓
    const body = doc.body ? doc.body.textContent || "" : "";
    const pageCharts = [...body.matchAll(/病歷號(?:碼)?\s*[：:]?\s*([A-Za-z]{0,2}\d{6,13}(?:[-－]\d)?)(?![\d\/\-.])/g)].map((m) => m[1]);
    const bare = chartno.replace(/^0+/, "");
    // 頁面若寫成「0012345-6」，去掉檢查碼前的連字號再找
    const joined = body.replace(/(\d)[-－](\d)(?!\d)/g, "$1$2");
    const pageHasChart = new RegExp("(^|[^A-Za-z0-9])0*" + bare + "([^A-Za-z0-9]|$)", "i").test(joined);
    return { stage: "ok", rows, pageCharts, pageHasChart };
  } catch (e) {
    return { stage: "error", detail: "連不到院內系統或逾時（是否在院內網路？）" };
  }
}

if (typeof module !== "undefined") module.exports = { getChartUrl, pageIsLogin, readExam };
