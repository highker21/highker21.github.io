const $ = (id) => document.getElementById(id);
let results = [], stopping = false;

function say(text, cls) { $("msg").textContent = text; $("msg").className = cls || ""; }
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

const CHART_LOAD_MS = 15000, SETTLE_MS = 1500;
const chartTabs = new Set(); // 外掛自己開的病歷分頁，任何情況都要關掉

// 有開著的院內分頁就在分頁裡跑（同源最穩）；某個分頁已登出就換下一個，都不行再由外掛直接跑
async function inHosp(h, func, args) {
  const tabs = await chrome.tabs.query({ url: HOSPS[h].base + "/*" });
  for (const t of tabs) {
    if (chartTabs.has(t.id)) continue;
    try {
      const [res] = await chrome.scripting.executeScript({ target: { tabId: t.id }, args, func });
      if (res && res.result && res.result.stage !== "login") return res.result;
    } catch (e) { /* 分頁可能還在載入，換下一個 */ }
  }
  return func(...args);
}

const origin = (u) => { try { return new URL(u).origin; } catch (e) { return ""; } };
function closeChartTab(id) { chartTabs.delete(id); return chrome.tabs.remove(id).catch(() => {}); }

// 在背景分頁真的打開病歷頁（頁面上的程式會執行，院內系統才會切到這位病人）
// 回 { id, fail }：id 是開出來的分頁（呼叫端負責關），fail 是失敗原因
async function openChart(h, url) {
  if (origin(url) !== origin(HOSPS[h].base)) return { id: null, fail: { stage: "error", detail: `病歷網址不在${HOSPS[h].name}院內網域（${origin(url) || "無法解析"}），請回報` } };
  const done = new Set(); let id = null, wake = null;
  const onUpd = (tid, info) => { if (info.status === "complete") { done.add(tid); if (tid === id && wake) wake(true); } };
  chrome.tabs.onUpdated.addListener(onUpd);
  try {
    const tab = await chrome.tabs.create({ url, active: false });
    id = tab.id; chartTabs.add(id);
    const loaded = done.has(id) || await new Promise((res) => { wake = res; setTimeout(() => res(false), CHART_LOAD_MS); });
    if (!loaded) return { id, fail: { stage: "error", detail: `頁面 ${CHART_LOAD_MS / 1000} 秒內沒載完` } };
    await sleep(SETTLE_MS);
    // 被導到登入頁（SSO 會換網域，換了網域就讀不到網址）或頁面本身是登入頁 → 當成連線過期
    const t = await chrome.tabs.get(id);
    if (!t.url || origin(t.url) !== origin(url)) return { id, fail: { stage: "login" } };
    const [r] = await chrome.scripting.executeScript({ target: { tabId: id }, func: pageIsLogin });
    if (!r || r.result !== false) return { id, fail: { stage: "login" } };
    return { id, fail: null };
  } catch (e) {
    return { id, fail: { stage: "error", detail: "開不了病歷頁" } };
  } finally { chrome.tabs.onUpdated.removeListener(onUpd); }
}

// 排程頁被導到登入頁：把那個分頁切到前面，讓使用者自己登入（外掛不碰帳密、不填表），
// 每 2 秒看一次分頁回到院內網域、且不再是登入頁，就在同一分頁重開排程頁。回 null＝可以續抓；回字串＝放棄原因
const LOGIN_WAIT_MS = 5 * 60e3, LOGIN_POLL_MS = 2000;
async function waitLogin(h, id) {
  const url = scheduleUrl(h);
  let self = null;
  try { self = await chrome.tabs.getCurrent(); } catch (e) { /* 拿不到就不切回來 */ }
  try {
    const t = await chrome.tabs.update(id, { active: true });
    if (t && t.windowId >= 0) await chrome.windows.update(t.windowId, { focused: true });
  } catch (e) { return "登入分頁已被關掉"; }
  say(`請在剛跳出的分頁登入${HOSPS[h].name}院內系統，登入後會自動回來繼續抓名單（最多等 ${LOGIN_WAIT_MS / 60e3} 分鐘）。`);
  for (let i = 0; i < LOGIN_WAIT_MS / LOGIN_POLL_MS; i++) {
    await sleep(LOGIN_POLL_MS);
    let t;
    try { t = await chrome.tabs.get(id); } catch (e) { return "登入分頁已被關掉"; }
    // 還在 SSO（換網域就讀不到網址）或還在載入，繼續等
    if (t.status !== "complete" || !t.url || origin(t.url) !== origin(url)) continue;
    let r;
    try { [r] = await chrome.scripting.executeScript({ target: { tabId: id }, func: pageIsLogin }); } catch (e) { continue; }
    if (!r || r.result !== false) continue;
    const ok = await reopen(id, url);
    if (self && self.id != null) { try { await chrome.tabs.update(self.id, { active: true }); } catch (e) { /* 查詢頁被關了就算了 */ } }
    return ok ? null : "登入後仍開不了排程系統";
  }
  return "等候登入逾時";
}

// 在同一分頁重開網址，載完確認不是登入頁
async function reopen(id, url) {
  let wake = null, fired = false;
  const onUpd = (tid, info) => { if (tid === id && info.status === "complete") { fired = true; if (wake) wake(true); } };
  chrome.tabs.onUpdated.addListener(onUpd);
  try {
    await chrome.tabs.update(id, { url, active: false });
    const loaded = fired || await new Promise((res) => { wake = res; setTimeout(() => res(false), CHART_LOAD_MS); });
    if (!loaded) return false;
    await sleep(SETTLE_MS);
    const t = await chrome.tabs.get(id);
    if (!t.url || origin(t.url) !== origin(url)) return false;
    const [r] = await chrome.scripting.executeScript({ target: { tabId: id }, func: pageIsLogin });
    return !!r && r.result === false;
  } catch (e) {
    return false;
  } finally { chrome.tabs.onUpdated.removeListener(onUpd); }
}

// 名單給的 MRN_URL 若在院內網域就直接用，否則照細胞學外掛用 GetMRNUrl 取病歷網址
async function runOne(h, chartno, staff, mrnUrl) {
  let url = mrnUrl;
  if (!/^https?:\/\//i.test(url || "") || origin(url) !== origin(HOSPS[h].base)) {
    const u = await inHosp(h, getChartUrl, [apiUrl(h), chartno, staff]);
    if (u.stage !== "url") return u;
    url = u.url;
  }
  const { id, fail } = await openChart(h, url);
  try {
    if (fail) return fail;
    // 病歷頁已跟報告頁同網域（openChart 擋過），就在剛開的病歷分頁裡讀報告，用的是同一份 cookie／session
    const [r] = await chrome.scripting.executeScript({ target: { tabId: id }, args: [examUrl(h), chartno], func: readExam });
    return (r && r.result) || { stage: "error", detail: "讀不到報告頁" };
  } catch (e) {
    return { stage: "error", detail: "讀不到報告頁" };
  } finally { if (id != null) await closeChartTab(id); }
}

// 查詢中關掉這個頁面，也把還開著的分頁收掉
addEventListener("pagehide", () => { for (const id of [...chartTabs]) closeChartTab(id); });

function cell(tr, text, cls) { const td = document.createElement("td"); td.textContent = text; if (cls) td.className = cls; tr.appendChild(td); return td; }

function addRow(i, r) {
  const tr = document.createElement("tr");
  if (r.grade) tr.className = "g-" + r.grade; // atypia／suspicious／malignant 整列底色
  cell(tr, String(i + 1));
  cell(tr, r.chartno);
  cell(tr, r.echo || "");
  cell(tr, r.site || "");
  const st = cell(tr, r.status, r.status.startsWith("查詢失敗") ? "fail" : r.status.startsWith("有報告") ? "" : "none");
  if (r.note) { const d = document.createElement("div"); d.className = "note"; d.textContent = r.note; st.appendChild(d); }
  cell(tr, r.grade || "");
  cell(tr, r.count ? String(r.count) : "");
  for (const k of ["date", "name", "specimen", "diagnosis", "adequacy"]) cell(tr, r[k]);
  const td = cell(tr, "");
  if (r.full) {
    const d = document.createElement("details"), s = document.createElement("summary"), p = document.createElement("pre");
    s.textContent = "展開"; p.textContent = r.full; d.appendChild(s); d.appendChild(p); td.appendChild(d);
  }
  $("tb").appendChild(tr);
}

// ---- 日期與時段（可複選）
let dates = [], people = [], confirmedOver = false;

function renderDates() {
  const box = $("dates"); box.textContent = "";
  for (const d of dates) {
    const b = document.createElement("span"); b.className = "chip"; b.textContent = d.replace(/-/g, "/") + " ✕"; b.title = "點一下移除";
    b.addEventListener("click", () => { dates = dates.filter((x) => x !== d); renderDates(); });
    box.appendChild(b);
  }
  $("dcount").textContent = dates.length ? `已選 ${dates.length} 天` : "尚未選日期";
}

function addDates() {
  const from = $("from").value, to = $("to").value || from;
  const wd = [...document.querySelectorAll("input[name=wd]:checked")].map((x) => +x.value);
  const add = expandDates(from, to, wd);
  if (!add.length) { say("請選起訖日期，並至少勾一個星期。", "err"); return; }
  const merged = [...new Set([...dates, ...add])].sort();
  if (merged.length > MAX_DATES) { say(`日期最多 ${MAX_DATES} 天，目前會變成 ${merged.length} 天。`, "err"); return; }
  dates = merged; renderDates(); say("");
}

function noonsChecked() { return [...document.querySelectorAll("input[name=noon]:checked")].map((x) => x.value); }

// ---- 第一步：抓名單（在背景開排程系統頁，讓登入流程跑完，再在那個分頁裡查）
async function loadList() {
  const h = $("hosp").value, dept = ($("dept").value || "").trim() || "0160", noons = noonsChecked(); // 空白就用預設 0160
  if (!dates.length) { say("請先加入日期。", "err"); return; }
  if (!noons.length) { say("請至少勾一個時段。", "err"); return; }
  if (!/^\w{1,10}$/.test(dept)) { say("科別代碼格式不對。", "err"); return; }
  people = []; confirmedOver = false; results = []; $("tb").textContent = ""; $("tbl").hidden = true;
  $("load").disabled = true; $("run").disabled = true; $("csv").disabled = true;
  say(`開啟${HOSPS[h].name}檢查排程系統…`);
  let { id, fail } = await openChart(h, scheduleUrl(h));
  const lists = [], errs = [];
  try {
    if (fail && fail.stage === "login" && id != null) {
      const why = await waitLogin(h, id);
      // 逾時就把登入分頁留給使用者，不關
      if (why === "等候登入逾時") { chartTabs.delete(id); id = null; }
      if (why) { say(`${why}，沒有抓名單。${why === "等候登入逾時" ? "登入分頁還開著，可以直接在那裡登入，" : ""}登入後再按一次「抓名單」。`, "err"); return; }
      fail = null;
    }
    if (fail) { say(fail.stage === "login" ? `排程系統要先登入：請在 Chrome 打開一次${HOSPS[h].name}院內系統（或檢查排程系統），登入後再按「抓名單」。` : "開不了排程系統：" + (fail.detail || ""), "err"); return; }
    const today = ymdOf(new Date());
    let n = 0;
    for (const d of dates) for (const noon of noons) {
      n++; say(`抓名單中：${d.replace(/-/g, "/")} ${NOONS[noon]}（${n} / ${dates.length * noons.length}）…`);
      const [r] = await chrome.scripting.executeScript({ target: { tabId: id }, args: [HOSPS[h].base, dept, noon, d, examStatus(d, today)], func: fetchExamList });
      const res = (r && r.result) || { stage: "error", detail: "沒有回應" };
      if (res.stage === "login") { say("排程系統連線過期或被導向登入頁，已停止。請重新登入後再抓。", "err"); return; }
      if (res.stage !== "ok") errs.push(`${d} ${NOONS[noon]}：${res.stage === "http" ? "院內系統回應 " + res.status : res.stage === "format" ? "回傳格式不符" : res.detail || "失敗"}`);
      else lists.push({ ymd: d, noon, rows: res.rows });
    }
  } catch (e) {
    say("抓名單失敗：" + (e && e.message ? e.message : "未知錯誤"), "err"); return;
  } finally {
    if (id != null) await closeChartTab(id);
    $("load").disabled = false;
  }
  people = mergeLists(lists);
  const total = lists.reduce((a, L) => a + L.rows.length, 0);
  const future = dates.some((d) => examStatus(d, ymdOf(new Date())) === "N");
  say(`名單：${total} 筆檢查，合併後 ${people.length} 位病人${errs.length ? `；${errs.length} 個時段失敗（${errs.join("；")}）` : ""}${future ? "。（含未來日期，那幾天抓的是已排檢未執行）" : ""}${people.length > CONFIRM_OVER ? `。超過 ${CONFIRM_OVER} 位，按「抓報告」前請確認。` : ""}`, errs.length ? "err" : "ok");
  for (const p of people) { const r = { chartno: p.chartno, echo: p.echoes.join("、"), status: "待查", count: 0 }; results.push(r); }
  $("tbl").hidden = !people.length; results.forEach((r, i) => addRow(i, r));
  $("run").disabled = !people.length; $("csv").disabled = !people.length;
}

// ---- 第二步：逐位抓報告（沿用細胞學外掛）
async function fetchReports() {
  const h = $("hosp").value, staff = $("staff").value.trim();
  const gap = Math.min(60, Math.max(2, +$("gap").value || 5));
  if (!people.length) return;
  if (!staff) { say("請先填入職編（名單沒有病歷網址時要用）。", "err"); $("staff").focus(); return; }
  if (people.length > CONFIRM_OVER && !confirmedOver) {
    confirmedOver = true;
    say(`名單有 ${people.length} 位，每位約隔 ${gap} 秒，大約要 ${Math.ceil(people.length * (gap + 5) / 60)} 分鐘。確定要全部查，請再按一次「抓報告」。`, "err");
    return;
  }
  results = []; stopping = false; $("tb").textContent = ""; $("tbl").hidden = false;
  $("load").disabled = true; $("run").disabled = true; $("stop").disabled = false; $("csv").disabled = true;
  let fails = 0;
  for (let i = 0; i < people.length; i++) {
    if (stopping) break;
    const p = people[i];
    say(`抓報告中（${HOSPS[h].name}）：第 ${i + 1} / ${people.length} 位…`);
    const rs = summarizeRows(p.chartno, await runOne(h, p.chartno, staff, p.mrnUrl)).map((x) => ({ ...x, echo: p.echoes.join("、") }));
    for (const x of rs) { results.push(x); addRow(results.length - 1, x); }
    if (rs.some((x) => x.status.startsWith("查詢失敗"))) fails++;
    // 連線過期就停：後面每一位都會失敗，不要一直打院內系統
    if (/連線過期|連不到/.test(rs[0].status)) {
      for (const q of people.slice(i + 1)) { const x = { chartno: q.chartno, echo: q.echoes.join("、"), status: "未查詢（前一位連線失敗已停止）", count: 0 }; results.push(x); addRow(results.length - 1, x); }
      say(`第 ${i + 1} 位連線失敗，已停止。請先在 Chrome 打開${HOSPS[h].name}院內系統確認可用，再重查。`, "err");
      break;
    }
    if (i < people.length - 1) await sleep((gap + Math.random() * 3) * 1000);
  }
  if (!/已停止/.test($("msg").textContent)) {
    // 一位病人可能有甲狀腺、淋巴結兩列，以病歷號計人數
    const cnt = (f) => new Set(results.filter(f).map((r) => r.chartno)).size;
    const got = cnt((r) => r.status.startsWith("有報告")), unv = cnt((r) => r.status.includes("未能核對"));
    say(`${stopping ? "已手動停止" : "查詢結束"}：有報告 ${got} 位${unv ? `（其中 ${unv} 位未能核對病歷號，請抽查）` : ""}，查詢失敗 ${fails} 位，共 ${results.length} 列。`, fails ? "err" : "ok");
  }
  $("load").disabled = false; $("run").disabled = false; $("stop").disabled = true; $("csv").disabled = !results.length;
}

function download() {
  const d = new Date(), ymd = d.getFullYear() + String(d.getMonth() + 1).padStart(2, "0") + String(d.getDate()).padStart(2, "0");
  const a = document.createElement("a");
  a.href = URL.createObjectURL(new Blob([toCSV(results)], { type: "text/csv;charset=utf-8" }));
  a.download = `甲狀腺超音波病理_${HOSPS[$("hosp").value].name}_${ymd}.csv`;
  document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(a.href), 5000);
}

(async function init() {
  for (const [k, v] of Object.entries(HOSPS)) {
    const o = document.createElement("option"); o.value = k; o.textContent = v.name; $("hosp").appendChild(o);
  }
  const s = await chrome.storage.local.get(["hosp", "staff", "dept"]); // 只記院區、職編、科別代碼；名單與結果都不存
  if (s.hosp && HOSPS[s.hosp]) $("hosp").value = s.hosp;
  if (s.staff) $("staff").value = s.staff;
  if (s.dept) $("dept").value = s.dept;
  const t = ymdOf(new Date()); $("from").value = t; $("to").value = t;
  $("hosp").addEventListener("change", () => chrome.storage.local.set({ hosp: $("hosp").value }));
  $("staff").addEventListener("change", () => chrome.storage.local.set({ staff: $("staff").value.trim() }));
  $("dept").addEventListener("change", () => chrome.storage.local.set({ dept: $("dept").value.trim() }));
  $("add").addEventListener("click", addDates);
  $("clear").addEventListener("click", () => { dates = []; renderDates(); });
  $("load").addEventListener("click", loadList);
  $("run").addEventListener("click", fetchReports);
  $("stop").addEventListener("click", () => { stopping = true; $("stop").disabled = true; say("會在目前這位查完後停止…"); });
  $("csv").addEventListener("click", download);
  renderDates();
})();
