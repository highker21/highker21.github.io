(() => {
  if (window.top !== window || document.getElementById("kmugh-ereport-phrases")) return;

  const categoryPriority = [
    "Diagnosis", "備註", "ABI", "眼底", "診斷書", "死亡",
    "MBD(含急診)", "MBD(含加護病房)", "放射碘", "CV-MI(MBD)"
  ];
  const STORAGE_KEY = "customPhrasesV1";
  const POSITION_KEY = "panelPositionV1";
  const DRAG_THRESHOLD = 4;
  let phrases = [];
  let activeCategory = "";
  let editingId = null;
  let lastFocusedField = null;

  const panel = document.createElement("section");
  panel.id = "kmugh-ereport-phrases";
  panel.innerHTML = `
    <header title="拖曳可移動位置；雙擊回到預設位置">
      <span>eReport 自訂片語</span>
      <button type="button" data-action="toggle" title="縮小">−</button>
    </header>
    <div class="kep-body">
      <div class="kep-target">請先點選要插入的報告欄位</div>
      <input class="kep-search" type="search" placeholder="搜尋分類或片語…" autocomplete="off">
      <div class="kep-toolbar"><button type="button" data-action="add">＋新增片語</button><button type="button" data-action="defaults" title="把內建片語加進來，已有的相同片語不會重複">載入內建片語</button><button type="button" data-action="export" title="下載目前全部片語（JSON）">匯出</button><button type="button" data-action="import" title="從 JSON 檔加入片語，已有的相同片語不會重複">匯入</button><input class="kep-import-file" type="file" accept=".json,application/json" hidden></div>
      <nav class="kep-tabs" aria-label="片語群組"></nav>
      <form class="kep-editor" hidden>
        <label>群組／頁簽名稱<input class="kep-edit-category" type="text" required></label>
        <label>標題（選填，只顯示在清單、不會插入報告）<input class="kep-edit-title" type="text"></label>
        <label>片語內容<textarea class="kep-edit-text" rows="6" required></textarea></label>
        <div><button type="submit" data-action="save">儲存</button><button type="button" data-action="cancel">取消</button></div>
      </form>
      <div class="kep-list"></div>
      <p class="kep-note">片語只保存在此 Chrome。工具不會暫存或送出報告。</p>
    </div>`;
  document.body.appendChild(panel);

  const targetStatus = panel.querySelector(".kep-target");
  const search = panel.querySelector(".kep-search");
  const tabs = panel.querySelector(".kep-tabs");
  const editorForm = panel.querySelector(".kep-editor");
  const editCategory = panel.querySelector(".kep-edit-category");
  const editTitle = panel.querySelector(".kep-edit-title");
  const editText = panel.querySelector(".kep-edit-text");
  const list = panel.querySelector(".kep-list");
  const importFile = panel.querySelector(".kep-import-file");

  panel.addEventListener("click", async (event) => {
    const button = event.target.closest("[data-action]");
    if (!button) return;
    if (button.dataset.action === "toggle") {
      panel.classList.toggle("collapsed");
      button.textContent = panel.classList.contains("collapsed") ? "+" : "−";
      if (panel.style.left) placePanel(parseFloat(panel.style.left), parseFloat(panel.style.top));
      return;
    }
    if (button.dataset.action === "insert") {
      const phrase = phrases.find((item) => item.id === button.dataset.id);
      if (phrase) insertAtCaret(phrase.text);
      return;
    }
    if (button.dataset.action === "tab") {
      activeCategory = button.dataset.category || "";
      renderTabs();
      render();
      return;
    }
    if (button.dataset.action === "add") {
      openEditor();
      return;
    }
    if (button.dataset.action === "edit") {
      openEditor(phrases.find((item) => item.id === button.dataset.id));
      return;
    }
    if (button.dataset.action === "delete") {
      await deletePhrase(button.dataset.id);
      return;
    }
    if (button.dataset.action === "defaults") {
      await loadDefaults();
      return;
    }
    if (button.dataset.action === "export") {
      exportPhrases();
      return;
    }
    if (button.dataset.action === "import") {
      importFile.click();
      return;
    }
    if (button.dataset.action === "cancel") {
      closeEditor();
    }
  });
  editorForm.addEventListener("submit", saveEditor);
  importFile.addEventListener("change", importPhrases);
  search.addEventListener("input", render);

  const header = panel.querySelector("header");
  let drag = null;
  header.addEventListener("pointerdown", (event) => {
    if (event.button !== 0 || event.target.closest("button")) return;
    const rect = panel.getBoundingClientRect();
    drag = { id: event.pointerId, x: event.clientX, y: event.clientY, left: rect.left, top: rect.top, moved: false };
    header.setPointerCapture(event.pointerId);
    event.preventDefault();
  });
  header.addEventListener("pointermove", (event) => {
    if (!drag || event.pointerId !== drag.id) return;
    const dx = event.clientX - drag.x;
    const dy = event.clientY - drag.y;
    if (!drag.moved && Math.hypot(dx, dy) < DRAG_THRESHOLD) return;
    drag.moved = true;
    panel.classList.add("dragging");
    placePanel(drag.left + dx, drag.top + dy);
  });
  const endDrag = (event) => {
    if (!drag || event.pointerId !== drag.id) return;
    const moved = drag.moved;
    drag = null;
    panel.classList.remove("dragging");
    if (header.hasPointerCapture(event.pointerId)) header.releasePointerCapture(event.pointerId);
    if (moved) savePosition();
  };
  header.addEventListener("pointerup", endDrag);
  header.addEventListener("pointercancel", endDrag);
  header.addEventListener("dblclick", (event) => {
    if (event.target.closest("button")) return;
    resetPosition();
  });
  window.addEventListener("resize", () => {
    if (panel.style.left) placePanel(parseFloat(panel.style.left), parseFloat(panel.style.top));
  });

  loadPosition();
  loadPhrases();
  attachToReportFrame();
  new MutationObserver(attachToReportFrame).observe(document.documentElement, {
    childList: true,
    subtree: true
  });

  async function loadPhrases() {
    try {
      const stored = await chrome.storage.local.get(STORAGE_KEY);
      if (Array.isArray(stored[STORAGE_KEY])) {
        phrases = stored[STORAGE_KEY];
      } else {
        // 第一次安裝才自動放入內建片語；已有資料（含刻意清空）不動
        phrases = [];
        mergePhrases(KEP_DEFAULT_PHRASES);
        await persistPhrases();
      }
      sortPhrases();
      renderTabs();
      render();
    } catch (error) {
      targetStatus.textContent = `片語載入失敗：${error.message}`;
      targetStatus.classList.add("error");
    }
  }

  // 標題列至少留在畫面內，避免拖出視窗後找不回來
  function placePanel(left, top) {
    const width = panel.offsetWidth;
    const headerHeight = header.offsetHeight || 40;
    const x = Math.min(Math.max(left, 0), Math.max(window.innerWidth - width, 0));
    const y = Math.min(Math.max(top, 0), Math.max(window.innerHeight - headerHeight, 0));
    panel.style.left = `${x}px`;
    panel.style.top = `${y}px`;
    panel.style.right = "auto";
    panel.style.maxHeight = `${Math.max(window.innerHeight - y - 20, headerHeight)}px`;
  }

  async function loadPosition() {
    try {
      const stored = await chrome.storage.local.get(POSITION_KEY);
      const pos = stored[POSITION_KEY];
      if (pos && Number.isFinite(pos.left) && Number.isFinite(pos.top)) placePanel(pos.left, pos.top);
    } catch (_error) {
      // 位置讀不到就維持預設位置
    }
  }

  async function savePosition() {
    try {
      await chrome.storage.local.set({
        [POSITION_KEY]: { left: parseFloat(panel.style.left), top: parseFloat(panel.style.top) }
      });
    } catch (_error) {
      // 位置存不了不影響片語功能
    }
  }

  async function resetPosition() {
    for (const prop of ["left", "top", "right", "maxHeight"]) panel.style[prop] = "";
    try {
      await chrome.storage.local.remove(POSITION_KEY);
    } catch (_error) {
      // 同上
    }
  }

  function rank(category) {
    const index = categoryPriority.indexOf(category);
    return index < 0 ? Number.MAX_SAFE_INTEGER : index;
  }

  function sortPhrases() {
    phrases.sort((a, b) => rank(a.category) - rank(b.category) || a.category.localeCompare(b.category));
  }

  async function persistPhrases() {
    await chrome.storage.local.set({ [STORAGE_KEY]: phrases });
  }

  // 分類與內容都相同才算重複（標題不算）；回傳實際新增筆數
  function mergePhrases(items) {
    const seen = new Set(phrases.map((item) => `${item.category}\u0000${item.text}`));
    let added = 0;
    for (const item of items) {
      if (!item || typeof item.category !== "string" || typeof item.text !== "string") continue;
      if (item.title !== undefined && typeof item.title !== "string") continue;
      const category = item.category.trim();
      const text = item.text;
      const title = (item.title || "").trim();
      if (!category || !text.trim()) continue;
      const key = `${category}\u0000${text}`;
      if (seen.has(key)) continue;
      seen.add(key);
      phrases.push({ id: crypto.randomUUID(), category, text, ...(title && { title }) });
      added += 1;
    }
    return added;
  }

  async function addPhrases(items, source) {
    const added = mergePhrases(items);
    if (added) {
      await persistPhrases();
      sortPhrases();
      renderTabs();
      render();
    }
    alert(`${source}：新增 ${added} 筆，略過 ${items.length - added} 筆（已存在或格式不符）。`);
  }

  async function loadDefaults() {
    if (!confirm(`要把 ${KEP_DEFAULT_PHRASES.length} 筆內建片語加進來嗎？\n已有的相同片語不會重複，也不會刪掉你自己建的片語。`)) return;
    await addPhrases(KEP_DEFAULT_PHRASES, "載入內建片語");
  }

  function exportPhrases() {
    const data = phrases.map(({ category, title, text }) => ({ category, ...(title && { title }), text }));
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = `ereport-phrases-${new Date().toLocaleDateString("sv-SE")}.json`;
    document.body.append(link);
    link.click();
    link.remove();
    setTimeout(() => URL.revokeObjectURL(link.href), 1000);
  }

  async function importPhrases() {
    const file = importFile.files[0];
    importFile.value = "";
    if (!file) return;
    try {
      if (file.size > 2 * 1024 * 1024) throw new Error("檔案超過 2 MB");
      const data = JSON.parse(await file.text());
      if (!Array.isArray(data)) throw new Error("內容不是片語清單");
      await addPhrases(data, `匯入 ${file.name}`);
    } catch (error) {
      alert(`匯入失敗：${error.message}`);
    }
  }

  function attachToReportFrame() {
    const frame = document.querySelector("#formsIframe");
    if (!frame || frame.dataset.kepAttached === "true") return;
    frame.dataset.kepAttached = "true";
    frame.addEventListener("load", () => {
      frame.dataset.kepDocumentAttached = "";
      attachFrameDocument(frame);
    });
    attachFrameDocument(frame);
  }

  function attachFrameDocument(frame) {
    try {
      const frameDocument = frame.contentDocument;
      if (!frameDocument || frame.dataset.kepDocumentAttached === "true") return;
      frame.dataset.kepDocumentAttached = "true";
      frameDocument.addEventListener("focusin", (event) => {
        const field = event.target;
        if (!isEditableTextField(field)) return;
        lastFocusedField = field;
        targetStatus.classList.remove("error");
        targetStatus.textContent = `插入目標：${field.name || field.id || field.tagName}`;
      }, true);
    } catch (_error) {
      targetStatus.textContent = "無法存取報告 iframe";
      targetStatus.classList.add("error");
    }
  }

  function isEditableTextField(field) {
    if (!field || field.disabled || field.readOnly) return false;
    if (field.tagName === "TEXTAREA") return true;
    return field.tagName === "INPUT" && ["text", "search", ""].includes(field.type);
  }

  function render() {
    const query = search.value.trim().toLocaleLowerCase();
    const matches = phrases
      .filter((phrase) => !activeCategory || phrase.category === activeCategory)
      .filter((phrase) => !query || `${phrase.category}\n${phrase.title || ""}\n${phrase.text}`.toLocaleLowerCase().includes(query))
      .slice(0, 60);
    list.replaceChildren();
    for (const phrase of matches) {
      const item = document.createElement("div");
      item.className = "kep-item";
      const button = document.createElement("button");
      button.type = "button";
      button.className = "kep-insert";
      button.dataset.action = "insert";
      button.dataset.id = phrase.id;
      const label = document.createElement("strong");
      label.textContent = phrase.title ? `${phrase.category}｜${phrase.title}` : phrase.category;
      const preview = document.createElement("span");
      preview.textContent = phrase.text.replace(/\s+/g, " ").slice(0, 150);
      button.append(label, preview);
      const actions = document.createElement("div");
      actions.className = "kep-item-actions";
      for (const [action, text] of [["edit", "編輯"], ["delete", "刪除"]]) {
        const actionButton = document.createElement("button");
        actionButton.type = "button";
        actionButton.dataset.action = action;
        actionButton.dataset.id = phrase.id;
        actionButton.textContent = text;
        actions.append(actionButton);
      }
      item.append(button, actions);
      list.append(item);
    }
    if (!matches.length) {
      list.textContent = phrases.length
        ? "找不到符合的片語"
        : "尚無片語，請點「＋新增片語」開始建立。";
    }
  }

  function renderTabs() {
    const categories = [...new Set(phrases.map((item) => item.category).filter(Boolean))];
    if (activeCategory && !categories.includes(activeCategory)) activeCategory = "";
    tabs.replaceChildren();
    for (const category of ["", ...categories]) {
      const button = document.createElement("button");
      button.type = "button";
      button.dataset.action = "tab";
      button.dataset.category = category;
      button.textContent = category || "全部";
      button.classList.toggle("active", category === activeCategory);
      tabs.append(button);
    }
  }

  function openEditor(phrase = null) {
    editingId = phrase?.id || null;
    editCategory.value = phrase?.category || activeCategory || "";
    editTitle.value = phrase?.title || "";
    editText.value = phrase?.text || "";
    editorForm.hidden = false;
    editCategory.focus();
  }

  function closeEditor() {
    editingId = null;
    editorForm.reset();
    editorForm.hidden = true;
  }

  async function saveEditor(event) {
    event.preventDefault();
    const category = editCategory.value.trim();
    const title = editTitle.value.trim();
    const text = editText.value.trim();
    if (!category || !text) return;
    if (editingId) {
      const phrase = phrases.find((item) => item.id === editingId);
      if (phrase) {
        Object.assign(phrase, { category, text });
        if (title) phrase.title = title;
        else delete phrase.title;
      }
    } else {
      phrases.push({ id: crypto.randomUUID(), category, text, ...(title && { title }) });
    }
    await persistPhrases();
    sortPhrases();
    activeCategory = category;
    closeEditor();
    renderTabs();
    render();
  }

  async function deletePhrase(id) {
    const phrase = phrases.find((item) => item.id === id);
    if (!phrase || !confirm(`確定刪除此片語？\n\n${phrase.text.slice(0, 120)}`)) return;
    phrases = phrases.filter((item) => item.id !== id);
    await persistPhrases();
    renderTabs();
    render();
  }

  function chooseFallbackField() {
    try {
      const frameDocument = document.querySelector("#formsIframe")?.contentDocument;
      const fields = [...(frameDocument?.querySelectorAll("textarea,input[type='text']") || [])]
        .filter((field) => isEditableTextField(field) && (field.offsetWidth || field.offsetHeight));
      const textareas = fields.filter((field) => field.tagName === "TEXTAREA");
      return (textareas.length ? textareas : fields)
        .sort((a, b) => (b.offsetWidth * b.offsetHeight) - (a.offsetWidth * a.offsetHeight))[0] || null;
    } catch (_error) {
      return null;
    }
  }

  function insertAtCaret(rawText) {
    let field = lastFocusedField;
    if (!field?.isConnected || !isEditableTextField(field)) field = chooseFallbackField();
    if (!field) {
      targetStatus.textContent = "找不到可插入的報告欄位";
      targetStatus.classList.add("error");
      return;
    }

    const isTextarea = field.tagName === "TEXTAREA";
    const text = isTextarea ? rawText : rawText.replace(/\r?\n/g, " ");
    const start = Number.isInteger(field.selectionStart) ? field.selectionStart : field.value.length;
    const end = Number.isInteger(field.selectionEnd) ? field.selectionEnd : start;
    const nextValue = field.value.slice(0, start) + text + field.value.slice(end);
    const frameWindow = field.ownerDocument.defaultView;
    const prototype = isTextarea
      ? frameWindow.HTMLTextAreaElement.prototype
      : frameWindow.HTMLInputElement.prototype;
    const setter = Object.getOwnPropertyDescriptor(prototype, "value")?.set;
    if (setter) setter.call(field, nextValue);
    else field.value = nextValue;

    field.dispatchEvent(new frameWindow.Event("input", { bubbles: true }));
    field.dispatchEvent(new frameWindow.Event("change", { bubbles: true }));
    field.focus();
    const caret = start + text.length;
    field.setSelectionRange?.(caret, caret);
    lastFocusedField = field;
    targetStatus.classList.remove("error");
    targetStatus.textContent = `已插入：${field.name || field.id || field.tagName}`;
  }
})();
